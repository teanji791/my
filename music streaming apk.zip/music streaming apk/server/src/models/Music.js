const mongoose = require('mongoose');

const musicSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Title is required'],
    trim: true,
    maxlength: [100, 'Title cannot be more than 100 characters']
  },
  artist: {
    type: String,
    required: [true, 'Artist is required'],
    trim: true,
    maxlength: [100, 'Artist name cannot be more than 100 characters']
  },
  album: {
    type: String,
    trim: true,
    maxlength: [100, 'Album name cannot be more than 100 characters']
  },
  genre: {
    type: String,
    trim: true
  },
  duration: {
    type: Number,
    required: [true, 'Duration is required']
  },
  audioFile: {
    url: {
      type: String,
      required: [true, 'Audio file URL is required']
    },
    key: String
  },
  coverImage: {
    url: {
      type: String,
      default: '/default-cover.jpg'
    },
    key: String
  },
  spotifyId: {
    type: String,
    unique: true,
    sparse: true
  },
  plays: {
    type: Number,
    default: 0
  },
  addedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});

// Index for search functionality
musicSchema.index({
  title: 'text',
  artist: 'text',
  album: 'text',
  genre: 'text'
});

const Music = mongoose.model('Music', musicSchema);

module.exports = Music;
