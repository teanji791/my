const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: [true, 'Username is required'],
    unique: true,
    trim: true,
    minlength: [3, 'Username must be at least 3 characters long'],
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    trim: true,
    lowercase: true,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email'],
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [6, 'Password must be at least 6 characters long'],
    select: false, // Don't return password in queries by default
  },
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user',
  },
  profile: {
    firstName: String,
    lastName: String,
    avatar: String,
    bio: String,
  },
  favorites: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Music',
  }],
  playlists: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Playlist',
  }],
  recentlyPlayed: [{
    music: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Music',
    },
    playedAt: {
      type: Date,
      default: Date.now,
    },
  }],
  settings: {
    theme: {
      type: String,
      enum: ['light', 'dark'],
      default: 'light',
    },
    quality: {
      type: String,
      enum: ['low', 'medium', 'high'],
      default: 'high',
    },
    notifications: {
      type: Boolean,
      default: true,
    },
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  lastLogin: {
    type: Date,
    default: Date.now,
  },
}, {
  timestamps: true,
});

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Method to compare password for login
userSchema.methods.comparePassword = async function(candidatePassword) {
  try {
    return await bcrypt.compare(candidatePassword, this.password);
  } catch (error) {
    throw new Error(error);
  }
};

// Method to update last login
userSchema.methods.updateLastLogin = function() {
  this.lastLogin = Date.now();
  return this.save();
};

// Method to add a song to favorites
userSchema.methods.toggleFavorite = async function(musicId) {
  const index = this.favorites.indexOf(musicId);
  if (index === -1) {
    this.favorites.push(musicId);
  } else {
    this.favorites.splice(index, 1);
  }
  return this.save();
};

// Method to add recently played
userSchema.methods.addToRecentlyPlayed = async function(musicId) {
  this.recentlyPlayed.unshift({ music: musicId });
  // Keep only last 50 songs
  if (this.recentlyPlayed.length > 50) {
    this.recentlyPlayed = this.recentlyPlayed.slice(0, 50);
  }
  return this.save();
};

const User = mongoose.model('User', userSchema);

module.exports = User;
