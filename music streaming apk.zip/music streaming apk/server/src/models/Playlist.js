const mongoose = require('mongoose');

const playlistSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Playlist name is required'],
    trim: true,
    maxlength: [100, 'Playlist name cannot be more than 100 characters'],
  },
  description: {
    type: String,
    trim: true,
    maxlength: [500, 'Description cannot be more than 500 characters'],
  },
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  coverImage: {
    type: String,
    default: '/default-playlist-cover.jpg',
  },
  tracks: [{
    music: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Music',
      required: true,
    },
    addedAt: {
      type: Date,
      default: Date.now,
    },
    addedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    order: {
      type: Number,
      required: true,
    },
  }],
  type: {
    type: String,
    enum: ['public', 'private', 'collaborative'],
    default: 'private',
  },
  collaborators: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    role: {
      type: String,
      enum: ['editor', 'viewer'],
      default: 'editor',
    },
    addedAt: {
      type: Date,
      default: Date.now,
    },
  }],
  stats: {
    totalDuration: {
      type: Number,
      default: 0,
    },
    followers: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    }],
    plays: {
      type: Number,
      default: 0,
    },
    lastPlayed: Date,
  },
  tags: [{
    type: String,
    trim: true,
  }],
  isActive: {
    type: Boolean,
    default: true,
  },
}, {
  timestamps: true,
});

// Index for search functionality
playlistSchema.index({
  name: 'text',
  description: 'text',
  tags: 'text',
});

// Pre-save middleware to update total duration
playlistSchema.pre('save', async function(next) {
  if (this.isModified('tracks')) {
    try {
      let totalDuration = 0;
      const populatedTracks = await mongoose.model('Music').find({
        '_id': { $in: this.tracks.map(track => track.music) }
      });
      
      populatedTracks.forEach(track => {
        totalDuration += track.duration;
      });
      
      this.stats.totalDuration = totalDuration;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

// Method to add track to playlist
playlistSchema.methods.addTrack = async function(musicId, userId) {
  const maxOrder = this.tracks.length > 0 
    ? Math.max(...this.tracks.map(t => t.order))
    : -1;
    
  this.tracks.push({
    music: musicId,
    addedBy: userId,
    order: maxOrder + 1,
  });
  
  return this.save();
};

// Method to remove track from playlist
playlistSchema.methods.removeTrack = async function(musicId) {
  const index = this.tracks.findIndex(track => track.music.toString() === musicId.toString());
  if (index !== -1) {
    this.tracks.splice(index, 1);
    // Reorder remaining tracks
    this.tracks.forEach((track, idx) => {
      track.order = idx;
    });
    return this.save();
  }
  return this;
};

// Method to reorder tracks
playlistSchema.methods.reorderTracks = async function(trackId, newOrder) {
  const track = this.tracks.find(t => t.music.toString() === trackId.toString());
  if (!track) return this;

  const oldOrder = track.order;
  if (oldOrder === newOrder) return this;

  // Update orders of affected tracks
  this.tracks.forEach(t => {
    if (oldOrder < newOrder) {
      if (t.order > oldOrder && t.order <= newOrder) {
        t.order--;
      }
    } else {
      if (t.order >= newOrder && t.order < oldOrder) {
        t.order++;
      }
    }
  });
  track.order = newOrder;

  return this.save();
};

// Method to toggle follower
playlistSchema.methods.toggleFollower = async function(userId) {
  const index = this.stats.followers.indexOf(userId);
  if (index === -1) {
    this.stats.followers.push(userId);
  } else {
    this.stats.followers.splice(index, 1);
  }
  return this.save();
};

// Static method to find popular playlists
playlistSchema.statics.findPopular = function(limit = 10) {
  return this.find({ type: 'public' })
    .sort({ 'stats.followers': -1 })
    .limit(limit)
    .populate('owner', 'username')
    .populate('tracks.music');
};

// Virtual for formatted duration
playlistSchema.virtual('formattedDuration').get(function() {
  const hours = Math.floor(this.stats.totalDuration / 3600);
  const minutes = Math.floor((this.stats.totalDuration % 3600) / 60);
  const seconds = this.stats.totalDuration % 60;
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
});

const Playlist = mongoose.model('Playlist', playlistSchema);

module.exports = Playlist;
