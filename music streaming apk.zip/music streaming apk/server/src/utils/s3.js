const AWS = require('aws-sdk');
const { s3: s3Config } = require('../config/keys');

let s3;

// Only configure AWS if credentials are provided
if (s3Config && s3Config.accessKeyId && s3Config.secretAccessKey) {
  AWS.config.update({
    accessKeyId: s3Config.accessKeyId,
    secretAccessKey: s3Config.secretAccessKey,
    region: s3Config.region || 'us-east-1'
  });

  s3 = new AWS.S3();
}

// Helper function to check if S3 is configured
const isS3Configured = () => {
  if (!s3) {
    throw new Error('S3 is not configured. Please check your environment variables.');
  }
  return true;
};

/**
 * Upload a file to S3
 * @param {Buffer} fileData - The file data buffer
 * @param {string} fileName - The name to give the file in S3
 * @param {string} mimeType - The MIME type of the file
 * @returns {Promise<string>} - The URL of the uploaded file
 */
exports.uploadToS3 = async (fileData, fileName, mimeType) => {
  try {
    isS3Configured();
    const params = {
      Bucket: s3Config.bucket,
      Key: fileName,
      Body: fileData,
      ContentType: mimeType,
      ACL: 'public-read'
    };

    const result = await s3.upload(params).promise();
    return result.Location;
  } catch (error) {
    console.error('S3 Upload Error:', error);
    throw new Error('Error uploading file to S3');
  }
};

/**
 * Delete a file from S3
 * @param {string} fileUrl - The URL of the file to delete
 * @returns {Promise<void>}
 */
exports.deleteFromS3 = async (fileUrl) => {
  try {
    isS3Configured();
    const key = fileUrl.split('/').pop();

    const params = {
      Bucket: s3Config.bucket,
      Key: key
    };

    await s3.deleteObject(params).promise();
  } catch (error) {
    console.error('S3 Delete Error:', error);
    throw new Error('Error deleting file from S3');
  }
};

/**
 * Check if S3 is properly configured
 * @returns {boolean}
 */
exports.isS3Available = () => {
  return !!s3;
};
