const axios = require('axios');

class SpotifyAPI {
  constructor() {
    this.baseURL = 'https://api.spotify.com/v1';
    this.clientId = process.env.SPOTIFY_CLIENT_ID;
    this.clientSecret = process.env.SPOTIFY_CLIENT_SECRET;
    this.redirectUri = process.env.SPOTIFY_REDIRECT_URI;
  }

  async getAccessToken(code) {
    try {
      const response = await axios.post('https://accounts.spotify.com/api/token', 
        new URLSearchParams({
          grant_type: 'authorization_code',
          code,
          redirect_uri: this.redirectUri,
        }), {
        headers: {
          'Authorization': 'Basic ' + Buffer.from(this.clientId + ':' + this.clientSecret).toString('base64'),
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });

      return response.data;
    } catch (error) {
      console.error('Error getting Spotify access token:', error);
      throw error;
    }
  }

  async getUserPlaylists(accessToken) {
    try {
      const response = await axios.get(`${this.baseURL}/me/playlists`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error getting user playlists:', error);
      throw error;
    }
  }

  async getPlaylistTracks(accessToken, playlistId) {
    try {
      const response = await axios.get(`${this.baseURL}/playlists/${playlistId}/tracks`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error getting playlist tracks:', error);
      throw error;
    }
  }

  async importPlaylist(accessToken, playlistId) {
    try {
      // Get playlist details
      const playlistResponse = await axios.get(`${this.baseURL}/playlists/${playlistId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });

      const playlist = playlistResponse.data;
      const tracks = await this.getPlaylistTracks(accessToken, playlistId);

      // Format the data for our database
      return {
        name: playlist.name,
        description: playlist.description,
        coverImage: playlist.images[0]?.url,
        tracks: tracks.items.map((item, index) => ({
          music: {
            title: item.track.name,
            artist: item.track.artists.map(artist => artist.name).join(', '),
            album: item.track.album.name,
            duration: Math.floor(item.track.duration_ms / 1000),
            coverImage: {
              url: item.track.album.images[0]?.url
            },
            spotifyId: item.track.id
          },
          order: index
        }))
      };
    } catch (error) {
      console.error('Error importing playlist:', error);
      throw error;
    }
  }
}

module.exports = new SpotifyAPI();
