const Music = require('../models/Music');
const User = require('../models/User');
const path = require('path');
const fs = require('fs').promises;
const { uploadToS3, deleteFromS3 } = require('../utils/s3');

// @desc    Upload new music
// @route   POST /api/music/upload
// @access  Private
exports.uploadMusic = async (req, res) => {
  try {
    const {
      title,
      artist,
      album,
      genre,
      year,
      featuredArtists,
      lyrics,
      isPublic
    } = req.body;

    if (!req.files || !req.files.audioFile) {
      return res.status(400).json({
        success: false,
        message: 'Please upload an audio file'
      });
    }

    const audioFile = req.files.audioFile;
    const coverImage = req.files.coverImage;

    // Validate audio file
    if (!audioFile.mimetype.startsWith('audio')) {
      return res.status(400).json({
        success: false,
        message: 'Please upload an audio file'
      });
    }

    // Check audio file size
    if (audioFile.size > process.env.MAX_AUDIO_UPLOAD) {
      return res.status(400).json({
        success: false,
        message: `Please upload an audio file less than ${process.env.MAX_AUDIO_UPLOAD}`
      });
    }

    // Generate unique filename
    const audioFileName = `${Date.now()}_${path.parse(audioFile.name).name}${path.parse(audioFile.name).ext}`;
    let coverImageUrl = '/default-album-cover.jpg';

    // Upload to S3 if configured, otherwise save locally
    let audioFileUrl;
    if (process.env.USE_S3 === 'true') {
      audioFileUrl = await uploadToS3(audioFile.data, audioFileName, audioFile.mimetype);
      if (coverImage) {
        coverImageUrl = await uploadToS3(coverImage.data, `cover_${audioFileName}`, coverImage.mimetype);
      }
    } else {
      await audioFile.mv(`${process.env.MUSIC_UPLOAD_PATH}/${audioFileName}`);
      audioFileUrl = `/uploads/music/${audioFileName}`;
      if (coverImage) {
        await coverImage.mv(`${process.env.COVER_UPLOAD_PATH}/cover_${audioFileName}`);
        coverImageUrl = `/uploads/covers/cover_${audioFileName}`;
      }
    }

    // Create music entry in database
    const music = await Music.create({
      title,
      artist,
      album,
      genre,
      year,
      featuredArtists: featuredArtists ? JSON.parse(featuredArtists) : [],
      lyrics,
      isPublic: isPublic === 'true',
      coverImage: coverImageUrl,
      audioFile: {
        url: audioFileUrl,
        format: path.parse(audioFile.name).ext.substring(1),
        quality: 'high'
      },
      metadata: {
        bitrate: 320, // Example value
        sampleRate: 44100, // Example value
        channels: 2 // Example value
      },
      uploadedBy: req.user.id
    });

    res.status(201).json({
      success: true,
      data: music
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error uploading music',
      error: error.message
    });
  }
};

// @desc    Get all music
// @route   GET /api/music
// @access  Public
exports.getAllMusic = async (req, res) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const total = await Music.countDocuments({ isPublic: true });

    const query = Music.find({ isPublic: true })
      .populate('uploadedBy', 'username')
      .skip(startIndex)
      .limit(limit)
      .sort({ createdAt: -1 });

    // Add filters if provided
    if (req.query.genre) {
      query.where('genre').equals(req.query.genre);
    }
    if (req.query.artist) {
      query.where('artist').equals(new RegExp(req.query.artist, 'i'));
    }

    const music = await query;

    // Pagination result
    const pagination = {};
    if (endIndex < total) {
      pagination.next = {
        page: page + 1,
        limit
      };
    }
    if (startIndex > 0) {
      pagination.prev = {
        page: page - 1,
        limit
      };
    }

    res.status(200).json({
      success: true,
      count: music.length,
      pagination,
      data: music
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching music',
      error: error.message
    });
  }
};

// @desc    Get single music
// @route   GET /api/music/:id
// @access  Public
exports.getMusic = async (req, res) => {
  try {
    const music = await Music.findById(req.params.id)
      .populate('uploadedBy', 'username')
      .populate({
        path: 'stats.likes',
        select: 'username profile.avatar'
      });

    if (!music) {
      return res.status(404).json({
        success: false,
        message: 'Music not found'
      });
    }

    res.status(200).json({
      success: true,
      data: music
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching music',
      error: error.message
    });
  }
};

// @desc    Update music
// @route   PUT /api/music/:id
// @access  Private
exports.updateMusic = async (req, res) => {
  try {
    let music = await Music.findById(req.params.id);

    if (!music) {
      return res.status(404).json({
        success: false,
        message: 'Music not found'
      });
    }

    // Make sure user is music owner or admin
    if (music.uploadedBy.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized to update this music'
      });
    }

    music = await Music.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({
      success: true,
      data: music
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating music',
      error: error.message
    });
  }
};

// @desc    Delete music
// @route   DELETE /api/music/:id
// @access  Private
exports.deleteMusic = async (req, res) => {
  try {
    const music = await Music.findById(req.params.id);

    if (!music) {
      return res.status(404).json({
        success: false,
        message: 'Music not found'
      });
    }

    // Make sure user is music owner or admin
    if (music.uploadedBy.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({
        success: false,
        message: 'Not authorized to delete this music'
      });
    }

    // Delete file from storage
    if (process.env.USE_S3 === 'true') {
      await deleteFromS3(music.audioFile.url);
      if (music.coverImage !== '/default-album-cover.jpg') {
        await deleteFromS3(music.coverImage);
      }
    } else {
      await fs.unlink(`${process.env.MUSIC_UPLOAD_PATH}/${path.basename(music.audioFile.url)}`);
      if (music.coverImage !== '/default-album-cover.jpg') {
        await fs.unlink(`${process.env.COVER_UPLOAD_PATH}/${path.basename(music.coverImage)}`);
      }
    }

    await music.remove();

    res.status(200).json({
      success: true,
      message: 'Music deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting music',
      error: error.message
    });
  }
};

// @desc    Search music
// @route   GET /api/music/search
// @access  Public
exports.searchMusic = async (req, res) => {
  try {
    const searchQuery = req.query.q;
    if (!searchQuery) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a search query'
      });
    }

    const music = await Music.find({
      $and: [
        { isPublic: true },
        {
          $or: [
            { title: new RegExp(searchQuery, 'i') },
            { artist: new RegExp(searchQuery, 'i') },
            { album: new RegExp(searchQuery, 'i') },
            { genre: new RegExp(searchQuery, 'i') },
            { tags: new RegExp(searchQuery, 'i') }
          ]
        }
      ]
    })
      .populate('uploadedBy', 'username')
      .limit(20);

    res.status(200).json({
      success: true,
      count: music.length,
      data: music
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error searching music',
      error: error.message
    });
  }
};

// @desc    Toggle like music
// @route   PUT /api/music/:id/like
// @access  Private
exports.toggleLike = async (req, res) => {
  try {
    const music = await Music.findById(req.params.id);
    if (!music) {
      return res.status(404).json({
        success: false,
        message: 'Music not found'
      });
    }

    const user = await User.findById(req.user.id);
    await user.toggleFavorite(music._id);
    await music.updateLikes(user.favorites.includes(music._id));

    res.status(200).json({
      success: true,
      liked: user.favorites.includes(music._id)
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error toggling like',
      error: error.message
    });
  }
};

// @desc    Stream music
// @route   GET /api/music/:id/stream
// @access  Public
exports.streamMusic = async (req, res) => {
  try {
    const music = await Music.findById(req.params.id);
    if (!music) {
      return res.status(404).json({
        success: false,
        message: 'Music not found'
      });
    }

    // Update play count
    await music.incrementPlays();

    // If using S3, redirect to signed URL
    if (process.env.USE_S3 === 'true') {
      const signedUrl = await getSignedUrl(music.audioFile.url);
      return res.redirect(signedUrl);
    }

    // Stream from local storage
    const filePath = path.join(process.env.MUSIC_UPLOAD_PATH, path.basename(music.audioFile.url));
    const stat = await fs.stat(filePath);
    const fileSize = stat.size;
    const range = req.headers.range;

    if (range) {
      const parts = range.replace(/bytes=/, "").split("-");
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunksize = (end - start) + 1;
      const file = fs.createReadStream(filePath, { start, end });
      const head = {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunksize,
        'Content-Type': 'audio/mpeg',
      };
      res.writeHead(206, head);
      file.pipe(res);
    } else {
      const head = {
        'Content-Length': fileSize,
        'Content-Type': 'audio/mpeg',
      };
      res.writeHead(200, head);
      fs.createReadStream(filePath).pipe(res);
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error streaming music',
      error: error.message
    });
  }
};
