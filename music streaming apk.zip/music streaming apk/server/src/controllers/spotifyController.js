const spotify = require('../utils/spotify');
const Playlist = require('../models/Playlist');
const Music = require('../models/Music');

exports.authorizeSpotify = (req, res) => {
  const scopes = [
    'playlist-read-private',
    'playlist-read-collaborative',
    'user-library-read'
  ];

  const spotifyAuthUrl = `https://accounts.spotify.com/authorize?client_id=${process.env.SPOTIFY_CLIENT_ID}&response_type=code&redirect_uri=${encodeURIComponent(process.env.SPOTIFY_REDIRECT_URI)}&scope=${encodeURIComponent(scopes.join(' '))}`;
  
  res.json({ url: spotifyAuthUrl });
};

exports.handleCallback = async (req, res) => {
  try {
    const { code } = req.query;
    const tokenData = await spotify.getAccessToken(code);
    
    // Store the token in the user's session or send it to the client
    req.session.spotifyToken = tokenData.access_token;
    
    res.redirect('/playlists/import'); // Redirect to the import page
  } catch (error) {
    console.error('Spotify callback error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to authenticate with Spotify'
    });
  }
};

exports.getUserPlaylists = async (req, res) => {
  try {
    const accessToken = req.session.spotifyToken;
    if (!accessToken) {
      return res.status(401).json({
        success: false,
        message: 'Spotify authentication required'
      });
    }

    const playlists = await spotify.getUserPlaylists(accessToken);
    res.json({
      success: true,
      data: playlists
    });
  } catch (error) {
    console.error('Error fetching Spotify playlists:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch Spotify playlists'
    });
  }
};

exports.importPlaylist = async (req, res) => {
  try {
    const { playlistId } = req.params;
    const accessToken = req.session.spotifyToken;
    const userId = req.user._id; // Assuming you have user data in req.user

    if (!accessToken) {
      return res.status(401).json({
        success: false,
        message: 'Spotify authentication required'
      });
    }

    // Get playlist data from Spotify
    const playlistData = await spotify.importPlaylist(accessToken, playlistId);

    // Create tracks in our database
    const tracks = await Promise.all(playlistData.tracks.map(async (trackData) => {
      const music = await Music.findOneAndUpdate(
        { spotifyId: trackData.music.spotifyId },
        trackData.music,
        { upsert: true, new: true }
      );
      return {
        music: music._id,
        order: trackData.order,
        addedBy: userId
      };
    }));

    // Create the playlist
    const playlist = await Playlist.create({
      name: playlistData.name,
      description: playlistData.description,
      coverImage: playlistData.coverImage,
      owner: userId,
      tracks,
      type: 'private'
    });

    res.json({
      success: true,
      data: playlist
    });
  } catch (error) {
    console.error('Error importing Spotify playlist:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to import Spotify playlist'
    });
  }
};
