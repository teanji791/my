// Mock music data for development
const mockMusic = [
  {
    _id: '1',
    title: 'Guitar Instrumental',
    artist: 'Test Artist 1',
    album: 'Test Album 1',
    genre: 'Pop',
    duration: 180,
    audioFile: {
      url: 'https://cdn.pixabay.com/download/audio/2022/02/22/audio_d1718ab41b.mp3'
    },
    coverImage: {
      url: 'https://picsum.photos/seed/song1/300'
    }
  },
  {
    _id: '2',
    title: 'Electronic Beat',
    artist: 'Test Artist 2',
    album: 'Test Album 2',
    genre: 'Electronic',
    duration: 240,
    audioFile: {
      url: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8f0c302.mp3'
    },
    coverImage: {
      url: 'https://picsum.photos/seed/song2/300'
    }
  },
  {
    _id: '3',
    title: 'Ambient Music',
    artist: 'Test Artist 3',
    album: 'Test Album 3',
    genre: 'Ambient',
    duration: 200,
    audioFile: {
      url: 'https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0c6bf3c0e.mp3'
    },
    coverImage: {
      url: 'https://picsum.photos/seed/song3/300'
    }
  }
];

// Get all music
exports.getAllMusic = (req, res) => {
  res.json({
    success: true,
    count: mockMusic.length,
    data: mockMusic
  });
};

// Get single music
exports.getMusic = (req, res) => {
  const music = mockMusic.find(m => m._id === req.params.id);
  
  if (!music) {
    return res.status(404).json({
      success: false,
      message: 'Music not found'
    });
  }

  res.json({
    success: true,
    data: music
  });
};

// Search music
exports.searchMusic = (req, res) => {
  const { q } = req.query;
  const results = mockMusic.filter(music => 
    music.title.toLowerCase().includes(q.toLowerCase()) ||
    music.artist.toLowerCase().includes(q.toLowerCase()) ||
    music.album.toLowerCase().includes(q.toLowerCase())
  );

  res.json({
    success: true,
    count: results.length,
    data: results
  });
};

// Get music by genre
exports.getMusicByGenre = (req, res) => {
  const { genre } = req.params;
  const results = mockMusic.filter(music => 
    music.genre.toLowerCase() === genre.toLowerCase()
  );

  res.json({
    success: true,
    count: results.length,
    data: results
  });
};
