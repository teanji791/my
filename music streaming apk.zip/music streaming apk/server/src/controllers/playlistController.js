const Playlist = require('../models/Playlist');
const Music = require('../models/Music');
const User = require('../models/User');

// @desc    Create new playlist
// @route   POST /api/playlists
// @access  Private
exports.createPlaylist = async (req, res) => {
  try {
    const { name, description, type, tracks } = req.body;

    const playlist = await Playlist.create({
      name,
      description,
      type: type || 'private',
      owner: req.user.id,
      tracks: tracks ? tracks.map((track, index) => ({
        music: track,
        addedBy: req.user.id,
        order: index
      })) : []
    });

    // Add playlist to user's playlists
    await User.findByIdAndUpdate(
      req.user.id,
      { $push: { playlists: playlist._id } }
    );

    res.status(201).json({
      success: true,
      data: playlist
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error creating playlist',
      error: error.message
    });
  }
};

// @desc    Get all public playlists
// @route   GET /api/playlists
// @access  Public
exports.getPlaylists = async (req, res) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const total = await Playlist.countDocuments({ type: 'public' });

    const query = Playlist.find({ type: 'public' })
      .populate('owner', 'username profile.avatar')
      .populate({
        path: 'tracks.music',
        select: 'title artist duration coverImage'
      })
      .skip(startIndex)
      .limit(limit)
      .sort({ 'stats.followers': -1 });

    const playlists = await query;

    // Pagination result
    const pagination = {};
    if (endIndex < total) {
      pagination.next = {
        page: page + 1,
        limit
      };
    }
    if (startIndex > 0) {
      pagination.prev = {
        page: page - 1,
        limit
      };
    }

    res.status(200).json({
      success: true,
      count: playlists.length,
      pagination,
      data: playlists
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching playlists',
      error: error.message
    });
  }
};

// @desc    Get user's playlists
// @route   GET /api/playlists/me
// @access  Private
exports.getUserPlaylists = async (req, res) => {
  try {
    const playlists = await Playlist.find({
      $or: [
        { owner: req.user.id },
        { 'collaborators.user': req.user.id },
        { type: 'public', 'stats.followers': req.user.id }
      ]
    })
      .populate('owner', 'username profile.avatar')
      .populate({
        path: 'tracks.music',
        select: 'title artist duration coverImage'
      })
      .populate('collaborators.user', 'username profile.avatar');

    res.status(200).json({
      success: true,
      count: playlists.length,
      data: playlists
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching user playlists',
      error: error.message
    });
  }
};

// @desc    Get single playlist
// @route   GET /api/playlists/:id
// @access  Public/Private
exports.getPlaylist = async (req, res) => {
  try {
    const playlist = await Playlist.findById(req.params.id)
      .populate('owner', 'username profile.avatar')
      .populate({
        path: 'tracks.music',
        select: 'title artist duration coverImage audioFile.url'
      })
      .populate('collaborators.user', 'username profile.avatar')
      .populate('stats.followers', 'username profile.avatar');

    if (!playlist) {
      return res.status(404).json({
        success: false,
        message: 'Playlist not found'
      });
    }

    // Check if private playlist is accessible
    if (playlist.type === 'private' && 
        playlist.owner.toString() !== req.user?.id &&
        !playlist.collaborators.some(collab => collab.user._id.toString() === req.user?.id)) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to access this playlist'
      });
    }

    res.status(200).json({
      success: true,
      data: playlist
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching playlist',
      error: error.message
    });
  }
};

// @desc    Update playlist
// @route   PUT /api/playlists/:id
// @access  Private
exports.updatePlaylist = async (req, res) => {
  try {
    let playlist = await Playlist.findById(req.params.id);

    if (!playlist) {
      return res.status(404).json({
        success: false,
        message: 'Playlist not found'
      });
    }

    // Check ownership or collaboration rights
    if (playlist.owner.toString() !== req.user.id &&
        !playlist.collaborators.some(collab => 
          collab.user.toString() === req.user.id && 
          collab.role === 'editor'
        )) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this playlist'
      });
    }

    // Update basic info
    if (req.body.name) playlist.name = req.body.name;
    if (req.body.description) playlist.description = req.body.description;
    if (req.body.type && playlist.owner.toString() === req.user.id) {
      playlist.type = req.body.type;
    }

    await playlist.save();

    res.status(200).json({
      success: true,
      data: playlist
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating playlist',
      error: error.message
    });
  }
};

// @desc    Delete playlist
// @route   DELETE /api/playlists/:id
// @access  Private
exports.deletePlaylist = async (req, res) => {
  try {
    const playlist = await Playlist.findById(req.params.id);

    if (!playlist) {
      return res.status(404).json({
        success: false,
        message: 'Playlist not found'
      });
    }

    // Check ownership
    if (playlist.owner.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this playlist'
      });
    }

    // Remove playlist from user's playlists
    await User.findByIdAndUpdate(
      req.user.id,
      { $pull: { playlists: playlist._id } }
    );

    await playlist.remove();

    res.status(200).json({
      success: true,
      message: 'Playlist deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting playlist',
      error: error.message
    });
  }
};

// @desc    Add track to playlist
// @route   POST /api/playlists/:id/tracks
// @access  Private
exports.addTrack = async (req, res) => {
  try {
    const { musicId } = req.body;
    const playlist = await Playlist.findById(req.params.id);

    if (!playlist) {
      return res.status(404).json({
        success: false,
        message: 'Playlist not found'
      });
    }

    // Check permissions
    if (playlist.owner.toString() !== req.user.id &&
        !playlist.collaborators.some(collab => 
          collab.user.toString() === req.user.id && 
          collab.role === 'editor'
        )) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to modify this playlist'
      });
    }

    // Check if track exists
    const music = await Music.findById(musicId);
    if (!music) {
      return res.status(404).json({
        success: false,
        message: 'Track not found'
      });
    }

    // Add track
    await playlist.addTrack(musicId, req.user.id);

    res.status(200).json({
      success: true,
      message: 'Track added successfully',
      data: playlist
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error adding track',
      error: error.message
    });
  }
};

// @desc    Remove track from playlist
// @route   DELETE /api/playlists/:id/tracks/:trackId
// @access  Private
exports.removeTrack = async (req, res) => {
  try {
    const playlist = await Playlist.findById(req.params.id);

    if (!playlist) {
      return res.status(404).json({
        success: false,
        message: 'Playlist not found'
      });
    }

    // Check permissions
    if (playlist.owner.toString() !== req.user.id &&
        !playlist.collaborators.some(collab => 
          collab.user.toString() === req.user.id && 
          collab.role === 'editor'
        )) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to modify this playlist'
      });
    }

    await playlist.removeTrack(req.params.trackId);

    res.status(200).json({
      success: true,
      message: 'Track removed successfully',
      data: playlist
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error removing track',
      error: error.message
    });
  }
};

// @desc    Reorder tracks in playlist
// @route   PUT /api/playlists/:id/tracks/reorder
// @access  Private
exports.reorderTracks = async (req, res) => {
  try {
    const { trackId, newOrder } = req.body;
    const playlist = await Playlist.findById(req.params.id);

    if (!playlist) {
      return res.status(404).json({
        success: false,
        message: 'Playlist not found'
      });
    }

    // Check permissions
    if (playlist.owner.toString() !== req.user.id &&
        !playlist.collaborators.some(collab => 
          collab.user.toString() === req.user.id && 
          collab.role === 'editor'
        )) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to modify this playlist'
      });
    }

    await playlist.reorderTracks(trackId, newOrder);

    res.status(200).json({
      success: true,
      message: 'Tracks reordered successfully',
      data: playlist
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error reordering tracks',
      error: error.message
    });
  }
};

// @desc    Toggle follow playlist
// @route   PUT /api/playlists/:id/follow
// @access  Private
exports.toggleFollow = async (req, res) => {
  try {
    const playlist = await Playlist.findById(req.params.id);

    if (!playlist) {
      return res.status(404).json({
        success: false,
        message: 'Playlist not found'
      });
    }

    if (playlist.type === 'private' && 
        playlist.owner.toString() !== req.user.id &&
        !playlist.collaborators.some(collab => collab.user.toString() === req.user.id)) {
      return res.status(403).json({
        success: false,
        message: 'Cannot follow private playlist'
      });
    }

    await playlist.toggleFollower(req.user.id);

    res.status(200).json({
      success: true,
      message: 'Playlist follow status updated',
      following: playlist.stats.followers.includes(req.user.id)
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error toggling follow status',
      error: error.message
    });
  }
};

// @desc    Add collaborator to playlist
// @route   POST /api/playlists/:id/collaborators
// @access  Private
exports.addCollaborator = async (req, res) => {
  try {
    const { userId, role } = req.body;
    const playlist = await Playlist.findById(req.params.id);

    if (!playlist) {
      return res.status(404).json({
        success: false,
        message: 'Playlist not found'
      });
    }

    // Check ownership
    if (playlist.owner.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to add collaborators'
      });
    }

    // Check if user exists
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Check if already a collaborator
    if (playlist.collaborators.some(collab => collab.user.toString() === userId)) {
      return res.status(400).json({
        success: false,
        message: 'User is already a collaborator'
      });
    }

    playlist.collaborators.push({
      user: userId,
      role: role || 'editor'
    });

    await playlist.save();

    res.status(200).json({
      success: true,
      message: 'Collaborator added successfully',
      data: playlist
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error adding collaborator',
      error: error.message
    });
  }
};

// @desc    Remove collaborator from playlist
// @route   DELETE /api/playlists/:id/collaborators/:userId
// @access  Private
exports.removeCollaborator = async (req, res) => {
  try {
    const playlist = await Playlist.findById(req.params.id);

    if (!playlist) {
      return res.status(404).json({
        success: false,
        message: 'Playlist not found'
      });
    }

    // Check ownership
    if (playlist.owner.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to remove collaborators'
      });
    }

    playlist.collaborators = playlist.collaborators.filter(
      collab => collab.user.toString() !== req.params.userId
    );

    await playlist.save();

    res.status(200).json({
      success: true,
      message: 'Collaborator removed successfully',
      data: playlist
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error removing collaborator',
      error: error.message
    });
  }
};

module.exports = exports;
