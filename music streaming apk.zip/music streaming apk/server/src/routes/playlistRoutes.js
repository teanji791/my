const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
  createPlaylist,
  getPlaylists,
  getUserPlaylists,
  getPlaylist,
  updatePlaylist,
  deletePlaylist,
  addTrack,
  removeTrack,
  reorderTracks,
  toggleFollow,
  addCollaborator,
  removeCollaborator
} = require('../controllers/playlistController');

// Public routes (no authentication required)
router.get('/', getPlaylists); // Get all public playlists
router.get('/:id', getPlaylist); // Get single playlist (checks access rights in controller)

// Protected routes (require authentication)
router.use(protect); // All routes below this will require authentication

// User playlist routes
router.get('/me', getUserPlaylists);
router.post('/', createPlaylist);

// Playlist interaction routes
router.put('/:id/follow', toggleFollow);

// Playlist management routes (requires ownership or collaboration rights)
router.route('/:id')
  .put(authorize('owner', 'collaborator'), updatePlaylist)
  .delete(authorize('owner'), deletePlaylist);

// Track management routes
router.route('/:id/tracks')
  .post(authorize('owner', 'collaborator'), addTrack);

router.route('/:id/tracks/:trackId')
  .delete(authorize('owner', 'collaborator'), removeTrack);

router.put('/:id/tracks/reorder', authorize('owner', 'collaborator'), reorderTracks);

// Collaborator management routes (requires ownership)
router.route('/:id/collaborators')
  .post(authorize('owner'), addCollaborator);

router.route('/:id/collaborators/:userId')
  .delete(authorize('owner'), removeCollaborator);

// Admin routes
router.use(authorize('admin')); // All routes below this will require admin role

// Add any admin-specific playlist routes here
// For example:
// router.get('/stats/all', getPlaylistStats);
// router.delete('/batch/:ids', batchDeletePlaylists);

module.exports = router;
