const express = require('express');
const { register, login, logout, getMe, updateDetails, updatePassword, deleteAccount, uploadAvatar } = require('../controllers/authController');
const { devAuth, devLogin, devRegister } = require('../middleware/devAuth');

const router = express.Router();

// Development routes
router.post('/dev/login', devLogin);
router.post('/dev/register', devRegister);

// Protected routes
router.route('/register').post(register);
router.route('/login').post(login);
router.route('/logout').get(devAuth, logout);
router.route('/me').get(devAuth, getMe);
router.route('/updatedetails').put(devAuth, updateDetails);
router.route('/updatepassword').put(devAuth, updatePassword);
router.route('/deleteaccount').delete(devAuth, deleteAccount);
router.route('/uploadavatar').put(devAuth, uploadAvatar);

module.exports = router;
