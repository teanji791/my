const express = require('express');
const { getAllMusic, getMusic, searchMusic, getMusicByGenre } = require('../controllers/mockMusicController');
const { devAuth } = require('../middleware/devAuth');

const router = express.Router();

// Public routes
router.get('/search', searchMusic);
router.get('/genre/:genre', getMusicByGenre);

// Protected routes
router.get('/', devAuth, getAllMusic);
router.get('/:id', devAuth, getMusic);

module.exports = router;
