const express = require('express');
const { authorizeSpotify, handleCallback, getUserPlaylists, importPlaylist } = require('../controllers/spotifyController');
const { protect } = require('../middleware/auth');

const router = express.Router();

// Spotify authentication routes
router.get('/auth', protect, authorizeSpotify);
router.get('/callback', handleCallback);

// Spotify playlist routes (protected)
router.get('/playlists', protect, getUserPlaylists);
router.post('/playlists/:playlistId/import', protect, importPlaylist);

module.exports = router;
