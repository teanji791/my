const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../config/keys');
const User = require('../models/User');

// Protect routes
exports.protect = async (req, res, next) => {
  try {
    let token;

    // Get token from header or cookies
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    } else if (req.cookies.token) {
      token = req.cookies.token;
    }

    // Check if token exists
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Not authorized to access this route'
      });
    }

    try {
      // Verify token
      const decoded = jwt.verify(token, jwtSecret);

      // Get user from token
      req.user = await User.findById(decoded.id);

      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'User not found'
        });
      }

      if (!req.user.isActive) {
        return res.status(401).json({
          success: false,
          message: 'User account is deactivated'
        });
      }

      next();
    } catch (err) {
      return res.status(401).json({
        success: false,
        message: 'Not authorized to access this route'
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error authenticating user',
      error: error.message
    });
  }
};

// Grant access to specific roles
exports.authorize = (...roles) => {
  return async (req, res, next) => {
    try {
      // For routes requiring ownership or collaboration rights
      if (roles.includes('owner') || roles.includes('collaborator')) {
        const resourceId = req.params.id;
        const resourceType = req.baseUrl.split('/')[2]; // e.g., 'music', 'playlists'

        let resource;
        switch (resourceType) {
          case 'music':
            resource = await require('../models/Music').findById(resourceId);
            if (roles.includes('owner') && resource?.uploadedBy.toString() === req.user.id) {
              return next();
            }
            break;

          case 'playlists':
            resource = await require('../models/Playlist').findById(resourceId);
            if (roles.includes('owner') && resource?.owner.toString() === req.user.id) {
              return next();
            }
            if (roles.includes('collaborator') && 
                resource?.collaborators.some(collab => 
                  collab.user.toString() === req.user.id && 
                  collab.role === 'editor'
                )) {
              return next();
            }
            break;

          default:
            return res.status(403).json({
              success: false,
              message: 'Resource type not supported'
            });
        }
      }

      // For admin role
      if (roles.includes('admin') && req.user.role === 'admin') {
        return next();
      }

      // If none of the above conditions are met
      return res.status(403).json({
        success: false,
        message: 'Not authorized to perform this action'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Error checking authorization',
        error: error.message
      });
    }
  };
};

// Track request activity
exports.trackActivity = async (req, res, next) => {
  try {
    if (req.user) {
      // Update last activity timestamp
      await User.findByIdAndUpdate(req.user.id, {
        lastLogin: Date.now()
      });
    }
    next();
  } catch (error) {
    console.error('Error tracking activity:', error);
    next(); // Continue even if tracking fails
  }
};

// Rate limiting middleware
exports.rateLimit = (limit, windowMs) => {
  const requests = new Map();

  return (req, res, next) => {
    const ip = req.ip;
    const now = Date.now();
    const windowStart = now - windowMs;

    // Clean up old requests
    requests.forEach((timestamp, key) => {
      if (timestamp < windowStart) {
        requests.delete(key);
      }
    });

    // Count requests in current window
    const requestCount = Array.from(requests.values())
      .filter(timestamp => timestamp > windowStart)
      .length;

    if (requestCount >= limit) {
      return res.status(429).json({
        success: false,
        message: 'Too many requests, please try again later'
      });
    }

    // Add current request
    requests.set(now, now);

    next();
  };
};

// Validate user session
exports.validateSession = async (req, res, next) => {
  try {
    if (!req.user) {
      return next();
    }

    // Check if user's session is still valid
    const user = await User.findById(req.user.id);
    if (!user || !user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Session expired, please login again'
      });
    }

    // Update user's session data
    req.user = user;
    next();
  } catch (error) {
    console.error('Error validating session:', error);
    next(); // Continue even if validation fails
  }
};

// Error handler for authentication errors
exports.handleAuthError = (err, req, res, next) => {
  if (err.name === 'JsonWebTokenError') {
    return res.status(401).json({
      success: false,
      message: 'Invalid token'
    });
  }

  if (err.name === 'TokenExpiredError') {
    return res.status(401).json({
      success: false,
      message: 'Token expired'
    });
  }

  next(err);
};
