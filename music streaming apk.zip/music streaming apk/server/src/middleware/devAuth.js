// Mock user for development
const mockUser = {
  _id: '123456789',
  username: 'testuser',
  email: 'test@example.com',
  role: 'user',
  profile: {
    firstName: 'Test',
    lastName: 'User'
  }
};

// Mock authentication middleware for development
exports.devAuth = (req, res, next) => {
  if (process.env.NODE_ENV === 'development') {
    req.user = mockUser;
    next();
  } else {
    next();
  }
};

// Mock login handler for development
exports.devLogin = (req, res) => {
  const { email, password } = req.body;
  
  // Accept any email/password in development
  if (process.env.NODE_ENV === 'development') {
    res.json({
      success: true,
      token: 'dev-token',
      user: mockUser
    });
  } else {
    res.status(500).json({
      success: false,
      message: 'Development mode only'
    });
  }
};

// Mock register handler for development
exports.devRegister = (req, res) => {
  if (process.env.NODE_ENV === 'development') {
    res.json({
      success: true,
      token: 'dev-token',
      user: {
        ...mockUser,
        ...req.body
      }
    });
  } else {
    res.status(500).json({
      success: false,
      message: 'Development mode only'
    });
  }
};
