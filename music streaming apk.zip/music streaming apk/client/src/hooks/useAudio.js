import { useState, useEffect, useRef, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { showErrorSnackbar } from '../store/slices/uiSlice';
import { 
  setCurrentTime as setPlayerTime,
  setDuration as setPlayerDuration,
  pause as pausePlayer
} from '../store/slices/playerSlice';

const useAudio = (initialTrack = null) => {
  const dispatch = useDispatch();
  const audioRef = useRef(new Audio());
  const [track, setTrack] = useState(initialTrack);
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  // Initialize audio element
  useEffect(() => {
    const audio = audioRef.current;

    // Set initial volume and playback rate
    audio.volume = volume;

    // Add error recovery attempt
    const handleStalled = () => {
      console.log('Playback stalled, attempting recovery...');
      const currentTime = audio.currentTime;
      audio.load();
      audio.currentTime = currentTime;
      if (isPlaying) {
        audio.play().catch(error => {
          console.error('Recovery failed:', error);
          setError('Playback recovery failed');
          dispatch(showErrorSnackbar('Playback recovery failed'));
          dispatch(pausePlayer());
        });
      }
    };

    audio.addEventListener('stalled', handleStalled);

    // Cleanup
    return () => {
      audio.removeEventListener('stalled', handleStalled);
      audio.pause();
      audio.src = '';
    };
  }, [volume, isPlaying, dispatch]);

  // Handle track changes
  useEffect(() => {
    if (!track) return;

    const audio = audioRef.current;
    setIsLoading(true);
    setError(null);

    // Update audio source
    audio.src = track.audioFile.url;
    
    // Auto-play when track changes
    audio.load();
    if (isPlaying) {
      audio.play()
        .then(() => {
          setIsLoading(false);
        })
        .catch((error) => {
          console.error('Playback error:', error);
          setError('Error playing track');
          setIsPlaying(false);
          setIsLoading(false);
          dispatch(showErrorSnackbar('Error playing track'));
        });
    } else {
      setIsLoading(false);
    }
  }, [track, isPlaying, dispatch]);

  // Add audio event listeners
  useEffect(() => {
    const audio = audioRef.current;

    const handleLoadedMetadata = () => {
      setDuration(audio.duration);
      dispatch(setPlayerDuration(audio.duration));
      setIsLoading(false);
    };

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      dispatch(setPlayerTime(audio.currentTime));
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    const handleError = (e) => {
      console.error('Audio error:', e);
      const errorMessage = e.target.error?.message || 'Error playing audio';
      setError(errorMessage);
      setIsPlaying(false);
      setIsLoading(false);
      dispatch(showErrorSnackbar(errorMessage));
      dispatch(pausePlayer());

      // Attempt to recover from network errors
      if (e.target.error?.code === 2) { // MEDIA_ERR_NETWORK
        setTimeout(() => {
          console.log('Attempting to recover from network error...');
          audio.load();
          if (track) {
            audio.src = track.audioFile.url;
          }
        }, 2000);
      }
    };

    const handleLoadStart = () => {
      setIsLoading(true);
    };

    const handleCanPlay = () => {
      setIsLoading(false);
    };

    // Add event listeners
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);
    audio.addEventListener('loadstart', handleLoadStart);
    audio.addEventListener('canplay', handleCanPlay);

    // Cleanup
    return () => {
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
      audio.removeEventListener('loadstart', handleLoadStart);
      audio.removeEventListener('canplay', handleCanPlay);
    };
  }, [dispatch]);

  // Play/Pause controls
  const play = useCallback(async () => {
    try {
      setError(null);
      await audioRef.current.play();
      setIsPlaying(true);
    } catch (error) {
      console.error('Play error:', error);
      setError('Error playing audio');
      setIsPlaying(false);
      dispatch(showErrorSnackbar('Error playing audio'));
    }
  }, [dispatch]);

  const pause = useCallback(() => {
    audioRef.current.pause();
    setIsPlaying(false);
  }, []);

  const togglePlay = useCallback(() => {
    if (isPlaying) {
      pause();
    } else {
      play();
    }
  }, [isPlaying, play, pause]);

  // Seek control
  const seek = useCallback((time) => {
    if (time >= 0 && time <= duration) {
      audioRef.current.currentTime = time;
      setCurrentTime(time);
    }
  }, [duration]);

  // Volume controls
  const setAudioVolume = useCallback((value) => {
    const newVolume = Math.max(0, Math.min(1, value));
    audioRef.current.volume = newVolume;
    setVolume(newVolume);
  }, []);

  const toggleMute = useCallback(() => {
    audioRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  }, [isMuted]);

  // Load new track
  const loadTrack = useCallback((newTrack, autoPlay = false) => {
    setTrack(newTrack);
    if (autoPlay) {
      setIsPlaying(true);
    }
  }, []);

  // Format time helper
  const formatTime = useCallback((timeInSeconds) => {
    if (!timeInSeconds) return '0:00';
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }, []);

  return {
    audioRef,
    track,
    isPlaying,
    duration,
    currentTime,
    volume,
    isMuted,
    isLoading,
    error,
    play,
    pause,
    togglePlay,
    seek,
    setVolume: setAudioVolume,
    toggleMute,
    loadTrack,
    formatTime,
  };
};

export default useAudio;
