import { useState, useCallback, useEffect, useRef } from 'react';
import { usePlayer } from '../contexts/PlayerContext';
import { useCache } from './useCache';

/**
 * Waveform visualization types
 */
const WaveformTypes = {
  BAR: 'bar',
  LINE: 'line',
  CURVE: 'curve',
};

/**
 * Hook for handling audio waveform generation and display
 * @param {Object} options - Waveform options
 * @returns {Object} - Waveform state and functions
 */
const useWaveform = (options = {}) => {
  const { audioRef } = usePlayer();
  const cache = useCache({
    persistKey: 'waveform_cache',
    ttl: 24 * 60 * 60 * 1000, // 24 hours
  });

  const {
    width = 800,
    height = 200,
    resolution = 2,
    type = WaveformTypes.BAR,
    barWidth = 2,
    barGap = 1,
    barRadius = 0,
    lineWidth = 2,
    curveSmoothing = 0.5,
    color = '#1DB954',
    progressColor = '#1ED760',
    backgroundColor = 'transparent',
    responsive = true,
    cacheWaveform = true,
  } = options;

  const [peaks, setPeaks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);

  // Generate waveform data from audio buffer
  const generateWaveform = useCallback(async (audioBuffer) => {
    try {
      const channelData = audioBuffer.getChannelData(0);
      const samplesPerPeak = Math.floor(channelData.length / width);
      const peaks = [];

      for (let i = 0; i < width; i++) {
        const start = i * samplesPerPeak;
        const end = start + samplesPerPeak;
        let max = 0;

        for (let j = start; j < end; j++) {
          const absolute = Math.abs(channelData[j]);
          if (absolute > max) {
            max = absolute;
          }
        }

        peaks.push(max);
      }

      return peaks;
    } catch (error) {
      console.error('Waveform generation error:', error);
      throw error;
    }
  }, [width]);

  // Load audio file and generate waveform
  const loadWaveform = useCallback(async (file) => {
    try {
      setLoading(true);
      setError(null);

      // Check cache first
      if (cacheWaveform) {
        const cachedPeaks = cache.get(file.name);
        if (cachedPeaks) {
          setPeaks(cachedPeaks);
          return cachedPeaks;
        }
      }

      // Read file
      const arrayBuffer = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsArrayBuffer(file);
      });

      // Decode audio data
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
      
      // Generate peaks
      const peaks = await generateWaveform(audioBuffer);
      setPeaks(peaks);

      // Cache waveform
      if (cacheWaveform) {
        cache.set(file.name, peaks);
      }

      return peaks;
    } catch (error) {
      console.error('Waveform loading error:', error);
      setError(error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  }, [generateWaveform, cacheWaveform, cache]);

  // Draw waveform on canvas
  const drawWaveform = useCallback((progress = 0) => {
    if (!canvasRef.current || peaks.length === 0) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;

    // Scale canvas for retina displays
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.scale(dpr, dpr);

    // Clear canvas
    ctx.fillStyle = backgroundColor;
    ctx.fillRect(0, 0, width, height);

    const centerY = height / 2;
    const progressWidth = Math.floor(width * (progress / 100));

    switch (type) {
      case WaveformTypes.BAR:
        peaks.forEach((peak, index) => {
          const x = index * (barWidth + barGap);
          const barHeight = peak * height;
          
          // Draw bar
          ctx.beginPath();
          ctx.roundRect(
            x,
            centerY - barHeight / 2,
            barWidth,
            barHeight,
            barRadius
          );
          ctx.fillStyle = index < progressWidth ? progressColor : color;
          ctx.fill();
        });
        break;

      case WaveformTypes.LINE:
        ctx.beginPath();
        ctx.moveTo(0, centerY);
        peaks.forEach((peak, index) => {
          const x = index * resolution;
          const y = centerY + (peak * height / 2);
          ctx.lineTo(x, y);
        });
        ctx.lineTo(width, centerY);
        ctx.lineWidth = lineWidth;
        ctx.strokeStyle = color;
        ctx.stroke();

        // Draw progress
        if (progress > 0) {
          ctx.beginPath();
          ctx.moveTo(0, centerY);
          peaks.forEach((peak, index) => {
            if (index * resolution <= progressWidth) {
              const x = index * resolution;
              const y = centerY + (peak * height / 2);
              ctx.lineTo(x, y);
            }
          });
          ctx.lineWidth = lineWidth;
          ctx.strokeStyle = progressColor;
          ctx.stroke();
        }
        break;

      case WaveformTypes.CURVE:
        ctx.beginPath();
        ctx.moveTo(0, centerY);
        
        // Draw curved line using bezier curves
        for (let i = 0; i < peaks.length - 1; i++) {
          const x = i * resolution;
          const nextX = (i + 1) * resolution;
          const y = centerY + (peaks[i] * height / 2);
          const nextY = centerY + (peaks[i + 1] * height / 2);
          const controlX = x + (nextX - x) * curveSmoothing;
          
          ctx.quadraticCurveTo(controlX, y, nextX, nextY);
        }
        
        ctx.lineWidth = lineWidth;
        ctx.strokeStyle = color;
        ctx.stroke();
        break;

      default:
        break;
    }
  }, [
    peaks,
    width,
    height,
    type,
    barWidth,
    barGap,
    barRadius,
    lineWidth,
    curveSmoothing,
    color,
    progressColor,
    backgroundColor,
    resolution,
  ]);

  // Handle window resize
  useEffect(() => {
    if (!responsive) return;

    const handleResize = () => {
      if (canvasRef.current) {
        drawWaveform();
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [responsive, drawWaveform]);

  return {
    peaks,
    loading,
    error,
    canvasRef,
    loadWaveform,
    drawWaveform,
    WaveformTypes,
  };
};

/**
 * Hook for handling real-time waveform visualization
 */
export const useRealtimeWaveform = (options = {}) => {
  const waveform = useWaveform({
    width: 400,
    height: 100,
    type: WaveformTypes.BAR,
    ...options,
  });

  const { audioRef } = usePlayer();
  const analyserRef = useRef(null);
  const dataArrayRef = useRef(null);
  const animationRef = useRef(null);

  // Initialize audio analyzer
  const initializeAnalyzer = useCallback(() => {
    if (!audioRef.current) return false;

    try {
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const analyser = audioContext.createAnalyser();
      const source = audioContext.createMediaElementSource(audioRef.current);

      analyser.fftSize = 2048;
      source.connect(analyser);
      analyser.connect(audioContext.destination);

      analyserRef.current = analyser;
      dataArrayRef.current = new Uint8Array(analyser.frequencyBinCount);

      return true;
    } catch (error) {
      console.error('Analyzer initialization error:', error);
      return false;
    }
  }, [audioRef]);

  // Draw real-time waveform
  const draw = useCallback(() => {
    if (!analyserRef.current || !dataArrayRef.current) return;

    analyserRef.current.getByteTimeDomainData(dataArrayRef.current);
    const peaks = Array.from(dataArrayRef.current).map(value => (value - 128) / 128);
    waveform.drawWaveform(peaks);

    animationRef.current = requestAnimationFrame(draw);
  }, [waveform]);

  // Start visualization
  const start = useCallback(() => {
    if (!analyserRef.current && !initializeAnalyzer()) {
      return false;
    }
    draw();
    return true;
  }, [initializeAnalyzer, draw]);

  // Stop visualization
  const stop = useCallback(() => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
  }, []);

  // Cleanup
  useEffect(() => {
    return () => {
      stop();
      if (analyserRef.current) {
        analyserRef.current.disconnect();
      }
    };
  }, [stop]);

  return {
    ...waveform,
    start,
    stop,
  };
};

export default useWaveform;
