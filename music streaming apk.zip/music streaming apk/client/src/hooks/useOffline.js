import { useState, useCallback, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useDownload } from './useDownload';
import { useCache } from './useCache';
import { useAnalytics } from './useAnalytics';
import { showSnackbar } from '../store/slices/uiSlice';

/**
 * Offline content types
 */
const ContentTypes = {
  TRACKS: 'tracks',
  PLAYLISTS: 'playlists',
  ALBUMS: 'albums',
  METADATA: 'metadata',
  IMAGES: 'images',
};

/**
 * Sync status types
 */
const SyncStatus = {
  IDLE: 'idle',
  SYNCING: 'syncing',
  COMPLETED: 'completed',
  ERROR: 'error',
};

/**
 * Hook for managing offline functionality
 * @param {Object} options - Offline options
 * @returns {Object} - Offline state and functions
 */
const useOffline = (options = {}) => {
  const dispatch = useDispatch();
  const download = useDownload();
  const cache = useCache();
  const analytics = useAnalytics();

  const {
    autoSync = true,
    syncInterval = 24 * 60 * 60 * 1000, // 24 hours
    maxOfflineItems = 1000,
    prefetchMetadata = true,
    cacheImages = true,
    persistOfflineState = true,
  } = options;

  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [offlineContent, setOfflineContent] = useState(new Map());
  const [syncStatus, setSyncStatus] = useState(SyncStatus.IDLE);
  const [lastSynced, setLastSynced] = useState(null);

  // Check network status
  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      dispatch(showSnackbar({
        message: 'Back online',
        severity: 'success',
      }));
      if (autoSync) {
        syncOfflineContent();
      }
    };

    const handleOffline = () => {
      setIsOffline(true);
      dispatch(showSnackbar({
        message: 'You are offline',
        severity: 'warning',
      }));
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [autoSync, dispatch]);

  // Load persisted offline state
  useEffect(() => {
    if (persistOfflineState) {
      const loadOfflineState = async () => {
        try {
          const state = await localStorage.getItem('offlineState');
          if (state) {
            const { content, synced } = JSON.parse(state);
            setOfflineContent(new Map(content));
            setLastSynced(synced);
          }
        } catch (error) {
          console.error('Error loading offline state:', error);
        }
      };

      loadOfflineState();
    }
  }, [persistOfflineState]);

  // Save offline state
  useEffect(() => {
    if (persistOfflineState) {
      const saveOfflineState = async () => {
        try {
          const state = {
            content: Array.from(offlineContent.entries()),
            synced: lastSynced,
          };
          await localStorage.setItem('offlineState', JSON.stringify(state));
        } catch (error) {
          console.error('Error saving offline state:', error);
        }
      };

      saveOfflineState();
    }
  }, [persistOfflineState, offlineContent, lastSynced]);

  // Make content available offline
  const makeOffline = useCallback(async (content, type = ContentTypes.TRACKS) => {
    try {
      if (offlineContent.size >= maxOfflineItems) {
        throw new Error('Maximum offline items limit reached');
      }

      // Download content
      let result;
      switch (type) {
        case ContentTypes.TRACKS:
          result = await download.startDownload(content);
          break;
        case ContentTypes.PLAYLISTS:
          result = await download.downloadPlaylist(content);
          break;
        case ContentTypes.ALBUMS:
          result = await Promise.all(
            content.tracks.map(track => download.startDownload(track))
          );
          break;
        default:
          throw new Error('Unsupported content type');
      }

      if (result) {
        // Cache metadata
        if (prefetchMetadata) {
          await cache.set(`${type}_${content.id}`, content);
        }

        // Cache images
        if (cacheImages && content.coverImage) {
          await cacheImage(content.coverImage);
        }

        // Update offline content
        setOfflineContent(prev => new Map(prev).set(content.id, {
          content,
          type,
          addedAt: Date.now(),
        }));

        analytics.trackEvent('content_made_offline', {
          contentId: content.id,
          type,
        });

        return true;
      }
      return false;
    } catch (error) {
      console.error('Make offline error:', error);
      dispatch(showSnackbar({
        message: error.message || 'Error making content available offline',
        severity: 'error',
      }));
      return false;
    }
  }, [
    offlineContent,
    maxOfflineItems,
    prefetchMetadata,
    cacheImages,
    download,
    cache,
    analytics,
    dispatch,
  ]);

  // Remove offline content
  const removeOffline = useCallback(async (contentId) => {
    try {
      const item = offlineContent.get(contentId);
      if (!item) return false;

      // Remove downloads
      switch (item.type) {
        case ContentTypes.TRACKS:
          await download.removeDownload(contentId);
          break;
        case ContentTypes.PLAYLISTS:
        case ContentTypes.ALBUMS:
          await Promise.all(
            item.content.tracks.map(track => download.removeDownload(track.id))
          );
          break;
      }

      // Remove from cache
      await cache.remove(`${item.type}_${contentId}`);

      // Update offline content
      setOfflineContent(prev => {
        const next = new Map(prev);
        next.delete(contentId);
        return next;
      });

      analytics.trackEvent('content_removed_offline', {
        contentId,
        type: item.type,
      });

      return true;
    } catch (error) {
      console.error('Remove offline error:', error);
      dispatch(showSnackbar({
        message: 'Error removing offline content',
        severity: 'error',
      }));
      return false;
    }
  }, [offlineContent, download, cache, analytics, dispatch]);

  // Sync offline content
  const syncOfflineContent = useCallback(async () => {
    if (isOffline || syncStatus === SyncStatus.SYNCING) return false;

    try {
      setSyncStatus(SyncStatus.SYNCING);

      // Update metadata for all offline content
      const updates = await Promise.all(
        Array.from(offlineContent.entries()).map(async ([id, item]) => {
          try {
            const response = await fetch(`/api/${item.type}/${id}`);
            const updated = await response.json();
            return [id, { ...item, content: updated }];
          } catch (error) {
            console.error(`Error updating ${item.type} ${id}:`, error);
            return [id, item];
          }
        })
      );

      // Update offline content
      setOfflineContent(new Map(updates));
      setLastSynced(Date.now());
      setSyncStatus(SyncStatus.COMPLETED);

      analytics.trackEvent('offline_content_synced', {
        itemCount: updates.length,
      });

      return true;
    } catch (error) {
      console.error('Sync error:', error);
      setSyncStatus(SyncStatus.ERROR);
      dispatch(showSnackbar({
        message: 'Error syncing offline content',
        severity: 'error',
      }));
      return false;
    }
  }, [isOffline, syncStatus, offlineContent, analytics, dispatch]);

  // Auto sync
  useEffect(() => {
    if (!autoSync || isOffline) return;

    const shouldSync = !lastSynced || 
      (Date.now() - lastSynced) >= syncInterval;

    if (shouldSync) {
      syncOfflineContent();
    }

    const interval = setInterval(syncOfflineContent, syncInterval);
    return () => clearInterval(interval);
  }, [autoSync, isOffline, lastSynced, syncInterval, syncOfflineContent]);

  // Cache image helper
  const cacheImage = async (url) => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      await cache.set(`image_${url}`, blob);
      return true;
    } catch (error) {
      console.error('Image cache error:', error);
      return false;
    }
  };

  return {
    isOffline,
    offlineContent,
    syncStatus,
    lastSynced,
    makeOffline,
    removeOffline,
    syncOfflineContent,
    ContentTypes,
    SyncStatus,
  };
};

/**
 * Hook for handling offline playlists
 */
export const useOfflinePlaylists = (options = {}) => {
  const offline = useOffline({
    ...options,
    prefetchMetadata: true,
    cacheImages: true,
  });

  const makePlaylistOffline = useCallback((playlist) => {
    return offline.makeOffline(playlist, ContentTypes.PLAYLISTS);
  }, [offline]);

  return {
    ...offline,
    makePlaylistOffline,
  };
};

export default useOffline;
