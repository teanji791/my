import { useState, useCallback, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useSocket } from '../contexts/SocketContext';
import { useAnalytics } from './useAnalytics';
import { useCache } from './useCache';
import api from '../utils/api';

/**
 * Activity types configuration
 */
const ActivityTypes = {
  PLAY: 'play',
  LIKE: 'like',
  PLAYLIST_CREATE: 'playlist_create',
  PLAYLIST_UPDATE: 'playlist_update',
  FOLLOW_USER: 'follow_user',
  FOLLOW_ARTIST: 'follow_artist',
  FOLLOW_PLAYLIST: 'follow_playlist',
  SHARE: 'share',
  COMMENT: 'comment',
};

/**
 * Activity visibility types
 */
const VisibilityTypes = {
  PUBLIC: 'public',
  FRIENDS: 'friends',
  PRIVATE: 'private',
};

/**
 * Hook for handling user activity
 * @param {Object} options - Activity options
 * @returns {Object} - Activity state and functions
 */
const useActivity = (options = {}) => {
  const user = useSelector(state => state.auth.user);
  const socket = useSocket();
  const analytics = useAnalytics();
  const cache = useCache({
    persistKey: 'activity_cache',
    ttl: 5 * 60 * 1000, // 5 minutes
  });

  const {
    autoSync = true,
    syncInterval = 60 * 1000, // 1 minute
    cacheActivities = true,
    defaultVisibility = VisibilityTypes.FRIENDS,
    batchUpdates = true,
    batchInterval = 5000, // 5 seconds
  } = options;

  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [lastSynced, setLastSynced] = useState(null);
  const [pendingActivities, setPendingActivities] = useState([]);

  // Get user activities
  const getActivities = useCallback(async (userId = user?.id, limit = 20, offset = 0) => {
    if (!userId) return [];

    try {
      // Check cache first
      if (cacheActivities) {
        const cacheKey = `activities_${userId}_${limit}_${offset}`;
        const cachedActivities = cache.get(cacheKey);
        if (cachedActivities) {
          return cachedActivities;
        }
      }

      const response = await api.get('/activities', {
        params: { userId, limit, offset },
      });

      const activityData = response.data;

      // Cache activities
      if (cacheActivities) {
        cache.set(`activities_${userId}_${limit}_${offset}`, activityData);
      }

      return activityData;
    } catch (error) {
      console.error('Get activities error:', error);
      throw error;
    }
  }, [user, cacheActivities, cache]);

  // Track activity
  const trackActivity = useCallback(async (type, data, visibility = defaultVisibility) => {
    if (!user) return null;

    const activity = {
      type,
      data,
      visibility,
      timestamp: Date.now(),
    };

    if (batchUpdates) {
      // Add to pending activities
      setPendingActivities(prev => [...prev, activity]);
    } else {
      try {
        const response = await api.post('/activities', activity);
        
        // Update local state
        setActivities(prev => [response.data, ...prev]);

        // Emit socket event
        if (visibility !== VisibilityTypes.PRIVATE) {
          socket.emit('activity', response.data);
        }

        // Track analytics
        analytics.trackEvent('activity_created', {
          type,
          visibility,
        });

        return response.data;
      } catch (error) {
        console.error('Track activity error:', error);
        throw error;
      }
    }
  }, [
    user,
    defaultVisibility,
    batchUpdates,
    socket,
    analytics,
  ]);

  // Delete activity
  const deleteActivity = useCallback(async (activityId) => {
    try {
      await api.delete(`/activities/${activityId}`);
      
      // Update local state
      setActivities(prev => prev.filter(activity => activity.id !== activityId));

      // Track analytics
      analytics.trackEvent('activity_deleted', { activityId });

      return true;
    } catch (error) {
      console.error('Delete activity error:', error);
      return false;
    }
  }, [analytics]);

  // Update activity visibility
  const updateVisibility = useCallback(async (activityId, visibility) => {
    try {
      const response = await api.put(`/activities/${activityId}/visibility`, {
        visibility,
      });

      // Update local state
      setActivities(prev => prev.map(activity =>
        activity.id === activityId ? response.data : activity
      ));

      return true;
    } catch (error) {
      console.error('Update visibility error:', error);
      return false;
    }
  }, []);

  // Get friend activities
  const getFriendActivities = useCallback(async (limit = 20, offset = 0) => {
    try {
      const response = await api.get('/activities/friends', {
        params: { limit, offset },
      });
      return response.data;
    } catch (error) {
      console.error('Get friend activities error:', error);
      return [];
    }
  }, []);

  // Get activity feed
  const getActivityFeed = useCallback(async (limit = 20, offset = 0) => {
    try {
      const response = await api.get('/activities/feed', {
        params: { limit, offset },
      });
      return response.data;
    } catch (error) {
      console.error('Get activity feed error:', error);
      return [];
    }
  }, []);

  // Process pending activities
  useEffect(() => {
    if (!batchUpdates || pendingActivities.length === 0) return;

    const processBatch = async () => {
      try {
        const response = await api.post('/activities/batch', {
          activities: pendingActivities,
        });

        // Update local state
        setActivities(prev => [...response.data, ...prev]);

        // Emit socket events
        response.data.forEach(activity => {
          if (activity.visibility !== VisibilityTypes.PRIVATE) {
            socket.emit('activity', activity);
          }
        });

        // Track analytics
        analytics.trackEvent('activities_batch_created', {
          count: response.data.length,
        });

        // Clear pending activities
        setPendingActivities([]);
      } catch (error) {
        console.error('Process batch error:', error);
      }
    };

    const timeout = setTimeout(processBatch, batchInterval);
    return () => clearTimeout(timeout);
  }, [
    batchUpdates,
    batchInterval,
    pendingActivities,
    socket,
    analytics,
  ]);

  // Auto sync activities
  useEffect(() => {
    if (!autoSync || !user) return;

    const syncActivities = async () => {
      try {
        const newActivities = await getActivities();
        setActivities(newActivities);
        setLastSynced(Date.now());
      } catch (error) {
        console.error('Sync activities error:', error);
      }
    };

    const shouldSync = !lastSynced || 
      (Date.now() - lastSynced) >= syncInterval;

    if (shouldSync) {
      syncActivities();
    }

    const interval = setInterval(syncActivities, syncInterval);
    return () => clearInterval(interval);
  }, [autoSync, user, lastSynced, syncInterval, getActivities]);

  // Listen for real-time activities
  useEffect(() => {
    if (!socket) return;

    const handleActivity = (activity) => {
      setActivities(prev => [activity, ...prev]);
    };

    socket.on('activity', handleActivity);
    return () => socket.off('activity', handleActivity);
  }, [socket]);

  return {
    activities,
    loading,
    error,
    lastSynced,
    trackActivity,
    deleteActivity,
    updateVisibility,
    getActivities,
    getFriendActivities,
    getActivityFeed,
    ActivityTypes,
    VisibilityTypes,
  };
};

/**
 * Hook for handling social features
 */
export const useSocialActivity = (options = {}) => {
  const activity = useActivity({
    defaultVisibility: VisibilityTypes.PUBLIC,
    ...options,
  });

  const shareActivity = useCallback(async (content, type = 'music') => {
    return activity.trackActivity(ActivityTypes.SHARE, {
      content,
      type,
    });
  }, [activity]);

  const commentActivity = useCallback(async (activityId, comment) => {
    return activity.trackActivity(ActivityTypes.COMMENT, {
      activityId,
      comment,
    });
  }, [activity]);

  return {
    ...activity,
    shareActivity,
    commentActivity,
  };
};

export default useActivity;
