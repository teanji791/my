import { useState, useEffect, useCallback, useRef } from 'react';
import { usePlayer } from '../contexts/PlayerContext';

/**
 * Visualizer types configuration
 */
const VisualizerTypes = {
  BARS: 'bars',
  WAVE: 'wave',
  CIRCLE: 'circle',
  PARTICLES: 'particles',
  SPECTRUM: 'spectrum',
};

/**
 * Color schemes for visualizer
 */
const ColorSchemes = {
  RAINBOW: 'rainbow',
  MONOCHROME: 'monochrome',
  GRADIENT: 'gradient',
  REACTIVE: 'reactive',
};

/**
 * Hook for handling audio visualization
 * @param {Object} options - Visualizer options
 * @returns {Object} - Visualizer state and functions
 */
const useVisualizer = (options = {}) => {
  const { audioRef } = usePlayer();
  const canvasRef = useRef(null);
  const animationRef = useRef(null);
  const analyserRef = useRef(null);
  const dataArrayRef = useRef(null);

  const {
    type = VisualizerTypes.BARS,
    colorScheme = ColorSchemes.RAINBOW,
    fftSize = 2048,
    smoothingTimeConstant = 0.8,
    minDecibels = -90,
    maxDecibels = -10,
    barWidth = 2,
    barSpacing = 1,
    sensitivity = 1.5,
    responsive = true,
  } = options;

  const [isActive, setIsActive] = useState(false);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  // Initialize audio context and analyzer
  const initializeAnalyzer = useCallback(() => {
    try {
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const analyser = audioContext.createAnalyser();
      const source = audioContext.createMediaElementSource(audioRef.current);

      analyser.fftSize = fftSize;
      analyser.smoothingTimeConstant = smoothingTimeConstant;
      analyser.minDecibels = minDecibels;
      analyser.maxDecibels = maxDecibels;

      source.connect(analyser);
      analyser.connect(audioContext.destination);

      analyserRef.current = analyser;
      dataArrayRef.current = new Uint8Array(analyser.frequencyBinCount);

      return true;
    } catch (error) {
      console.error('Visualizer initialization error:', error);
      return false;
    }
  }, [audioRef, fftSize, smoothingTimeConstant, minDecibels, maxDecibels]);

  // Draw visualizer frame
  const draw = useCallback(() => {
    if (!canvasRef.current || !analyserRef.current || !isActive) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const analyser = analyserRef.current;
    const dataArray = dataArrayRef.current;

    analyser.getByteFrequencyData(dataArray);

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    switch (type) {
      case VisualizerTypes.BARS:
        drawBars(ctx, dataArray, canvas.width, canvas.height);
        break;
      case VisualizerTypes.WAVE:
        drawWave(ctx, dataArray, canvas.width, canvas.height);
        break;
      case VisualizerTypes.CIRCLE:
        drawCircle(ctx, dataArray, canvas.width, canvas.height);
        break;
      case VisualizerTypes.PARTICLES:
        drawParticles(ctx, dataArray, canvas.width, canvas.height);
        break;
      case VisualizerTypes.SPECTRUM:
        drawSpectrum(ctx, dataArray, canvas.width, canvas.height);
        break;
      default:
        drawBars(ctx, dataArray, canvas.width, canvas.height);
    }

    animationRef.current = requestAnimationFrame(draw);
  }, [type, isActive]);

  // Draw bars visualization
  const drawBars = (ctx, dataArray, width, height) => {
    const barCount = Math.floor(width / (barWidth + barSpacing));
    const frequencyStep = Math.floor(dataArray.length / barCount);

    for (let i = 0; i < barCount; i++) {
      const frequency = dataArray[i * frequencyStep];
      const barHeight = (frequency / 255) * height * sensitivity;
      const x = i * (barWidth + barSpacing);
      const y = height - barHeight;

      ctx.fillStyle = getColor(i, barCount);
      ctx.fillRect(x, y, barWidth, barHeight);
    }
  };

  // Draw wave visualization
  const drawWave = (ctx, dataArray, width, height) => {
    ctx.beginPath();
    ctx.strokeStyle = getColor(0, 1);
    ctx.lineWidth = 2;

    const sliceWidth = width / dataArray.length;
    let x = 0;

    for (let i = 0; i < dataArray.length; i++) {
      const v = dataArray[i] / 128.0;
      const y = (v * height) / 2;

      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }

      x += sliceWidth;
    }

    ctx.lineTo(width, height / 2);
    ctx.stroke();
  };

  // Draw circle visualization
  const drawCircle = (ctx, dataArray, width, height) => {
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) / 4;
    const segments = 32;
    const angleStep = (Math.PI * 2) / segments;

    ctx.beginPath();
    for (let i = 0; i < segments; i++) {
      const frequency = dataArray[i * Math.floor(dataArray.length / segments)];
      const r = radius + (frequency / 255) * radius * sensitivity;
      const angle = i * angleStep;
      const x = centerX + Math.cos(angle) * r;
      const y = centerY + Math.sin(angle) * r;

      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.closePath();
    ctx.strokeStyle = getColor(0, 1);
    ctx.stroke();
  };

  // Get color based on scheme
  const getColor = (index, total) => {
    switch (colorScheme) {
      case ColorSchemes.RAINBOW:
        return `hsl(${(index / total) * 360}, 100%, 50%)`;
      case ColorSchemes.MONOCHROME:
        return `rgb(${(index / total) * 255}, ${(index / total) * 255}, ${(index / total) * 255})`;
      case ColorSchemes.GRADIENT:
        return `linear-gradient(${(index / total) * 360}deg, #ff0000, #00ff00)`;
      case ColorSchemes.REACTIVE:
        const intensity = dataArrayRef.current[index] / 255;
        return `hsl(${intensity * 360}, 100%, 50%)`;
      default:
        return '#ffffff';
    }
  };

  // Start visualizer
  const start = useCallback(() => {
    if (!isActive && audioRef.current) {
      if (!analyserRef.current && !initializeAnalyzer()) {
        return false;
      }
      setIsActive(true);
      draw();
      return true;
    }
    return false;
  }, [isActive, audioRef, initializeAnalyzer, draw]);

  // Stop visualizer
  const stop = useCallback(() => {
    setIsActive(false);
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
  }, []);

  // Handle canvas resize
  useEffect(() => {
    if (!canvasRef.current || !responsive) return;

    const handleResize = () => {
      const canvas = canvasRef.current;
      const { width, height } = canvas.getBoundingClientRect();
      canvas.width = width;
      canvas.height = height;
      setDimensions({ width, height });
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [responsive]);

  // Cleanup
  useEffect(() => {
    return () => {
      stop();
      if (analyserRef.current) {
        analyserRef.current.disconnect();
      }
    };
  }, [stop]);

  return {
    canvasRef,
    isActive,
    dimensions,
    start,
    stop,
    VisualizerTypes,
    ColorSchemes,
  };
};

/**
 * Hook for spectrum analyzer
 */
export const useSpectrum = (options = {}) => {
  return useVisualizer({
    type: VisualizerTypes.SPECTRUM,
    fftSize: 8192,
    smoothingTimeConstant: 0.4,
    ...options,
  });
};

/**
 * Hook for waveform visualization
 */
export const useWaveform = (options = {}) => {
  return useVisualizer({
    type: VisualizerTypes.WAVE,
    fftSize: 2048,
    smoothingTimeConstant: 0.8,
    ...options,
  });
};

export default useVisualizer;
