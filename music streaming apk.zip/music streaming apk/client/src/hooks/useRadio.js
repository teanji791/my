import { useState, useCallback, useEffect, useRef } from 'react';
import { usePlayer } from '../contexts/PlayerContext';
import { useRecommendations } from './useRecommendations';
import { useAnalytics } from './useAnalytics';
import api from '../utils/api';

/**
 * Radio modes configuration
 */
const RadioModes = {
  ARTIST: 'artist',
  TRACK: 'track',
  GENRE: 'genre',
  MOOD: 'mood',
  MIX: 'mix',
  DISCOVERY: 'discovery',
};

/**
 * Hook for handling radio functionality
 * @param {Object} options - Radio options
 * @returns {Object} - Radio state and functions
 */
const useRadio = (options = {}) => {
  const { addToQueue, clearQueue } = usePlayer();
  const recommendations = useRecommendations();
  const analytics = useAnalytics();

  const {
    mode = RadioModes.MIX,
    preloadTracks = 5,
    minQueueSize = 3,
    maxQueueSize = 50,
    crossfadeDuration = 3,
    autoRefresh = true,
    refreshThreshold = 0.7, // Refresh queue when this portion is played
  } = options;

  const [active, setActive] = useState(false);
  const [currentSeed, setCurrentSeed] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const queueSize = useRef(0);
  const refreshTimeout = useRef(null);

  // Start radio based on seed
  const startRadio = useCallback(async (seed, seedType = mode) => {
    try {
      setLoading(true);
      setError(null);

      // Clear existing queue
      clearQueue();
      queueSize.current = 0;

      // Get initial tracks based on seed type
      let tracks;
      switch (seedType) {
        case RadioModes.ARTIST:
          tracks = await api.get(`/radio/artist/${seed}`);
          break;
        case RadioModes.TRACK:
          tracks = await recommendations.getSimilarTracks(seed);
          break;
        case RadioModes.GENRE:
          tracks = await recommendations.getGenreRecommendations([seed]);
          break;
        case RadioModes.MOOD:
          tracks = await recommendations.getMoodRecommendations(seed);
          break;
        case RadioModes.MIX:
          tracks = await recommendations.getPersonalizedRecommendations();
          break;
        case RadioModes.DISCOVERY:
          tracks = await recommendations.getWeeklyDiscovery();
          break;
        default:
          throw new Error('Invalid radio mode');
      }

      // Add tracks to queue
      if (tracks.length > 0) {
        tracks.slice(0, preloadTracks).forEach(track => {
          addToQueue(track);
          queueSize.current++;
        });

        setCurrentSeed(seed);
        setActive(true);

        // Track analytics
        analytics.trackEvent('radio_started', {
          mode: seedType,
          seed,
          initialTracks: tracks.length,
        });
      } else {
        throw new Error('No tracks found for radio');
      }

      return true;
    } catch (error) {
      console.error('Radio start error:', error);
      setError(error.message);
      setActive(false);
      return false;
    } finally {
      setLoading(false);
    }
  }, [
    mode,
    preloadTracks,
    clearQueue,
    addToQueue,
    recommendations,
    analytics,
  ]);

  // Stop radio
  const stopRadio = useCallback(() => {
    setActive(false);
    setCurrentSeed(null);
    clearQueue();
    queueSize.current = 0;

    if (refreshTimeout.current) {
      clearTimeout(refreshTimeout.current);
      refreshTimeout.current = null;
    }

    analytics.trackEvent('radio_stopped');
  }, [clearQueue, analytics]);

  // Refresh radio queue
  const refreshQueue = useCallback(async () => {
    if (!active || loading || queueSize.current >= maxQueueSize) return;

    try {
      setLoading(true);

      // Get more tracks based on current mode
      const tracks = await recommendations.getRecommendations({
        seed: currentSeed,
        type: mode,
        limit: preloadTracks,
      });

      // Add new tracks to queue
      tracks.forEach(track => {
        if (queueSize.current < maxQueueSize) {
          addToQueue(track);
          queueSize.current++;
        }
      });

      analytics.trackEvent('radio_queue_refreshed', {
        tracksAdded: tracks.length,
        queueSize: queueSize.current,
      });
    } catch (error) {
      console.error('Queue refresh error:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  }, [
    active,
    loading,
    currentSeed,
    mode,
    preloadTracks,
    maxQueueSize,
    addToQueue,
    recommendations,
    analytics,
  ]);

  // Skip current track
  const skipTrack = useCallback(() => {
    queueSize.current = Math.max(0, queueSize.current - 1);
    
    // Refresh queue if needed
    if (autoRefresh && queueSize.current < minQueueSize) {
      refreshQueue();
    }

    analytics.trackEvent('radio_track_skipped', {
      remainingTracks: queueSize.current,
    });
  }, [autoRefresh, minQueueSize, refreshQueue, analytics]);

  // Handle queue updates
  useEffect(() => {
    if (!active || !autoRefresh) return;

    // Check if queue needs refresh
    if (queueSize.current < minQueueSize) {
      refreshQueue();
    }

    // Schedule next refresh
    if (refreshTimeout.current) {
      clearTimeout(refreshTimeout.current);
    }

    refreshTimeout.current = setTimeout(() => {
      if (queueSize.current / maxQueueSize <= refreshThreshold) {
        refreshQueue();
      }
    }, 1000);

    return () => {
      if (refreshTimeout.current) {
        clearTimeout(refreshTimeout.current);
      }
    };
  }, [
    active,
    autoRefresh,
    minQueueSize,
    maxQueueSize,
    refreshThreshold,
    refreshQueue,
  ]);

  // Get radio info
  const getRadioInfo = useCallback(() => {
    return {
      active,
      mode,
      currentSeed,
      queueSize: queueSize.current,
      loading,
      error,
    };
  }, [active, mode, currentSeed, loading, error]);

  return {
    active,
    loading,
    error,
    startRadio,
    stopRadio,
    refreshQueue,
    skipTrack,
    getRadioInfo,
    RadioModes,
  };
};

/**
 * Hook for handling artist radio
 */
export const useArtistRadio = (options = {}) => {
  const radio = useRadio({
    mode: RadioModes.ARTIST,
    ...options,
  });

  // Start radio for artist
  const startArtistRadio = useCallback((artistId) => {
    return radio.startRadio(artistId, RadioModes.ARTIST);
  }, [radio]);

  return {
    ...radio,
    startArtistRadio,
  };
};

/**
 * Hook for handling genre radio
 */
export const useGenreRadio = (options = {}) => {
  const radio = useRadio({
    mode: RadioModes.GENRE,
    ...options,
  });

  // Start radio for genre
  const startGenreRadio = useCallback((genre) => {
    return radio.startRadio(genre, RadioModes.GENRE);
  }, [radio]);

  return {
    ...radio,
    startGenreRadio,
  };
};

export default useRadio;
