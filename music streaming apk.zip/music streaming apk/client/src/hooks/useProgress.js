import { useState, useCallback, useEffect, useRef } from 'react';
import { usePlayer } from '../contexts/PlayerContext';
import { useAnalytics } from './useAnalytics';

/**
 * Progress update modes
 */
const UpdateModes = {
  CONTINUOUS: 'continuous',
  ON_SEEK: 'on_seek',
  THROTTLED: 'throttled',
};

/**
 * Hook for handling playback progress
 * @param {Object} options - Progress options
 * @returns {Object} - Progress state and functions
 */
const useProgress = (options = {}) => {
  const { audioRef } = usePlayer();
  const analytics = useAnalytics();
  
  const {
    updateMode = UpdateModes.CONTINUOUS,
    updateInterval = 250,
    seekInterval = 5,
    bufferThreshold = 0.1,
    trackAnalytics = true,
  } = options;

  // State
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState([]);
  const [seeking, setSeeking] = useState(false);
  const [loading, setLoading] = useState(false);

  // Refs
  const progressInterval = useRef(null);
  const lastUpdateTime = useRef(0);
  const seekStartTime = useRef(null);

  // Calculate progress percentage
  const getProgress = useCallback(() => {
    if (!duration) return 0;
    return (currentTime / duration) * 100;
  }, [currentTime, duration]);

  // Format time for display
  const formatTime = useCallback((timeInSeconds) => {
    if (!timeInSeconds) return '0:00';

    const hours = Math.floor(timeInSeconds / 3600);
    const minutes = Math.floor((timeInSeconds % 3600) / 60);
    const seconds = Math.floor(timeInSeconds % 60);

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }, []);

  // Get buffered ranges
  const getBufferedRanges = useCallback(() => {
    if (!audioRef.current) return [];

    const ranges = [];
    const buffered = audioRef.current.buffered;

    for (let i = 0; i < buffered.length; i++) {
      ranges.push({
        start: buffered.start(i),
        end: buffered.end(i),
      });
    }

    return ranges;
  }, [audioRef]);

  // Check if time is buffered
  const isTimeBuffered = useCallback((time) => {
    return buffered.some(range => time >= range.start && time <= range.end);
  }, [buffered]);

  // Update progress
  const updateProgress = useCallback(() => {
    if (!audioRef.current || seeking) return;

    const audio = audioRef.current;
    const now = Date.now();

    // Update based on mode
    if (
      updateMode === UpdateModes.CONTINUOUS ||
      (updateMode === UpdateModes.THROTTLED && 
        now - lastUpdateTime.current >= updateInterval)
    ) {
      setCurrentTime(audio.currentTime);
      setDuration(audio.duration || 0);
      setBuffered(getBufferedRanges());
      lastUpdateTime.current = now;
    }
  }, [audioRef, seeking, updateMode, updateInterval, getBufferedRanges]);

  // Seek to specific time
  const seekTo = useCallback((time) => {
    if (!audioRef.current) return false;

    try {
      const audio = audioRef.current;
      const newTime = Math.max(0, Math.min(time, audio.duration));

      // Check if seek is possible
      if (!isTimeBuffered(newTime)) {
        setLoading(true);
      }

      audio.currentTime = newTime;
      setCurrentTime(newTime);

      if (trackAnalytics) {
        analytics.trackEvent('seek', {
          from: currentTime,
          to: newTime,
          duration,
        });
      }

      return true;
    } catch (error) {
      console.error('Seek error:', error);
      return false;
    }
  }, [audioRef, isTimeBuffered, currentTime, duration, trackAnalytics, analytics]);

  // Start seeking
  const startSeeking = useCallback(() => {
    setSeeking(true);
    seekStartTime.current = currentTime;
  }, [currentTime]);

  // End seeking
  const endSeeking = useCallback(() => {
    setSeeking(false);
    seekStartTime.current = null;
  }, []);

  // Seek forward
  const seekForward = useCallback(() => {
    return seekTo(currentTime + seekInterval);
  }, [currentTime, seekInterval, seekTo]);

  // Seek backward
  const seekBackward = useCallback(() => {
    return seekTo(currentTime - seekInterval);
  }, [currentTime, seekInterval, seekTo]);

  // Get remaining time
  const getRemainingTime = useCallback(() => {
    return Math.max(0, duration - currentTime);
  }, [duration, currentTime]);

  // Check if near end
  const isNearEnd = useCallback((threshold = 0.1) => {
    if (!duration) return false;
    return (duration - currentTime) <= (duration * threshold);
  }, [duration, currentTime]);

  // Set up progress interval
  useEffect(() => {
    if (updateMode === UpdateModes.CONTINUOUS || 
        updateMode === UpdateModes.THROTTLED) {
      progressInterval.current = setInterval(updateProgress, updateInterval);
    }

    return () => {
      if (progressInterval.current) {
        clearInterval(progressInterval.current);
      }
    };
  }, [updateMode, updateInterval, updateProgress]);

  // Handle audio events
  useEffect(() => {
    if (!audioRef.current) return;

    const audio = audioRef.current;

    const handleLoadStart = () => setLoading(true);
    const handleCanPlay = () => setLoading(false);
    const handleSeeking = () => setSeeking(true);
    const handleSeeked = () => {
      setSeeking(false);
      setLoading(false);
    };
    const handleProgress = () => {
      setBuffered(getBufferedRanges());
    };
    const handleDurationChange = () => {
      setDuration(audio.duration || 0);
    };
    const handleTimeUpdate = () => {
      if (updateMode === UpdateModes.ON_SEEK) {
        setCurrentTime(audio.currentTime);
      }
    };

    audio.addEventListener('loadstart', handleLoadStart);
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('seeking', handleSeeking);
    audio.addEventListener('seeked', handleSeeked);
    audio.addEventListener('progress', handleProgress);
    audio.addEventListener('durationchange', handleDurationChange);
    audio.addEventListener('timeupdate', handleTimeUpdate);

    return () => {
      audio.removeEventListener('loadstart', handleLoadStart);
      audio.removeEventListener('canplay', handleCanPlay);
      audio.removeEventListener('seeking', handleSeeking);
      audio.removeEventListener('seeked', handleSeeked);
      audio.removeEventListener('progress', handleProgress);
      audio.removeEventListener('durationchange', handleDurationChange);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
    };
  }, [audioRef, updateMode, getBufferedRanges]);

  return {
    currentTime,
    duration,
    buffered,
    seeking,
    loading,
    getProgress,
    formatTime,
    seekTo,
    startSeeking,
    endSeeking,
    seekForward,
    seekBackward,
    getRemainingTime,
    isNearEnd,
    isTimeBuffered,
    UpdateModes,
  };
};

/**
 * Hook for handling chapter-based progress
 */
export const useChapterProgress = (chapters = [], options = {}) => {
  const progress = useProgress(options);
  const [currentChapter, setCurrentChapter] = useState(null);

  // Find current chapter based on time
  useEffect(() => {
    const chapter = chapters.find(
      chapter => progress.currentTime >= chapter.startTime && 
                 progress.currentTime < (chapter.endTime || progress.duration)
    );
    setCurrentChapter(chapter || null);
  }, [progress.currentTime, progress.duration, chapters]);

  // Seek to chapter
  const seekToChapter = useCallback((chapterIndex) => {
    const chapter = chapters[chapterIndex];
    if (chapter) {
      return progress.seekTo(chapter.startTime);
    }
    return false;
  }, [chapters, progress.seekTo]);

  return {
    ...progress,
    currentChapter,
    seekToChapter,
  };
};

export default useProgress;
