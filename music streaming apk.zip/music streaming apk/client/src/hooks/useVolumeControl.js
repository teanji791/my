import { useState, useCallback, useEffect } from 'react';
import { usePlayer } from '../contexts/PlayerContext';
import { useLocalStorage } from './useLocalStorage';
import { useAnalytics } from './useAnalytics';

/**
 * Volume presets configuration
 */
const VolumePresets = {
  MUTE: 0,
  LOW: 0.25,
  MEDIUM: 0.5,
  HIGH: 0.75,
  MAX: 1,
};

/**
 * Hook for handling volume control
 * @param {Object} options - Volume control options
 * @returns {Object} - Volume control state and functions
 */
const useVolumeControl = (options = {}) => {
  const { audioRef } = usePlayer();
  const analytics = useAnalytics();

  const {
    defaultVolume = 1,
    minVolume = 0,
    maxVolume = 1,
    step = 0.05,
    rememberVolume = true,
    fadeTransitions = true,
    fadeTime = 200,
  } = options;

  // Initialize state
  const [storedVolume, setStoredVolume] = useLocalStorage('volume_level', defaultVolume);
  const [volume, setVolume] = useState(rememberVolume ? storedVolume : defaultVolume);
  const [previousVolume, setPreviousVolume] = useState(volume);
  const [isMuted, setIsMuted] = useState(false);
  const [isFading, setIsFading] = useState(false);

  // Update audio element volume
  const updateVolume = useCallback(async (newVolume, fade = fadeTransitions) => {
    if (!audioRef.current) return false;

    try {
      // Ensure volume is within bounds
      const clampedVolume = Math.max(minVolume, Math.min(maxVolume, newVolume));
      
      // Round to nearest step
      const roundedVolume = Math.round(clampedVolume / step) * step;

      if (fade && !isFading) {
        setIsFading(true);
        const startVolume = audioRef.current.volume;
        const volumeDiff = roundedVolume - startVolume;
        const steps = 20;
        const stepTime = fadeTime / steps;

        for (let i = 1; i <= steps; i++) {
          await new Promise(resolve => setTimeout(resolve, stepTime));
          const intermediateVolume = startVolume + (volumeDiff * (i / steps));
          audioRef.current.volume = intermediateVolume;
        }
        setIsFading(false);
      } else {
        audioRef.current.volume = roundedVolume;
      }

      // Update state
      setVolume(roundedVolume);
      if (rememberVolume) {
        setStoredVolume(roundedVolume);
      }

      // Track analytics
      analytics.trackEvent('volume_change', {
        previousVolume: volume,
        newVolume: roundedVolume,
        isMuted,
      });

      return true;
    } catch (error) {
      console.error('Error updating volume:', error);
      return false;
    }
  }, [
    audioRef,
    minVolume,
    maxVolume,
    step,
    fadeTransitions,
    fadeTime,
    isFading,
    rememberVolume,
    volume,
    isMuted,
    setStoredVolume,
    analytics,
  ]);

  // Increase volume
  const increaseVolume = useCallback(() => {
    const newVolume = volume + step;
    return updateVolume(newVolume);
  }, [volume, step, updateVolume]);

  // Decrease volume
  const decreaseVolume = useCallback(() => {
    const newVolume = volume - step;
    return updateVolume(newVolume);
  }, [volume, step, updateVolume]);

  // Toggle mute
  const toggleMute = useCallback(() => {
    if (!audioRef.current) return false;

    try {
      if (isMuted) {
        // Unmute
        updateVolume(previousVolume);
        setIsMuted(false);
      } else {
        // Mute
        setPreviousVolume(volume);
        updateVolume(0);
        setIsMuted(true);
      }

      analytics.trackEvent('mute_toggle', {
        isMuted: !isMuted,
        previousVolume,
        volume,
      });

      return true;
    } catch (error) {
      console.error('Error toggling mute:', error);
      return false;
    }
  }, [audioRef, isMuted, previousVolume, volume, updateVolume, analytics]);

  // Set volume to preset
  const setPreset = useCallback((preset) => {
    const presetVolume = VolumePresets[preset];
    if (presetVolume !== undefined) {
      return updateVolume(presetVolume);
    }
    return false;
  }, [updateVolume]);

  // Get volume percentage
  const getVolumePercentage = useCallback(() => {
    return Math.round((volume / maxVolume) * 100);
  }, [volume, maxVolume]);

  // Format volume for display
  const formatVolume = useCallback((value = volume) => {
    const percentage = Math.round((value / maxVolume) * 100);
    return `${percentage}%`;
  }, [volume, maxVolume]);

  // Initialize volume when audio element changes
  useEffect(() => {
    if (audioRef.current) {
      updateVolume(volume, false);
    }
  }, [audioRef, volume, updateVolume]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (event) => {
      // Only handle if target is body (not input elements)
      if (event.target.tagName === 'BODY') {
        switch (event.key) {
          case 'ArrowUp':
            if (event.ctrlKey || event.metaKey) {
              increaseVolume();
            }
            break;
          case 'ArrowDown':
            if (event.ctrlKey || event.metaKey) {
              decreaseVolume();
            }
            break;
          case 'm':
          case 'M':
            toggleMute();
            break;
          default:
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [increaseVolume, decreaseVolume, toggleMute]);

  return {
    volume,
    isMuted,
    isFading,
    updateVolume,
    increaseVolume,
    decreaseVolume,
    toggleMute,
    setPreset,
    getVolumePercentage,
    formatVolume,
    VolumePresets,
    minVolume,
    maxVolume,
    step,
  };
};

/**
 * Hook for handling advanced volume control
 */
export const useAdvancedVolumeControl = (options = {}) => {
  const volumeControl = useVolumeControl({
    step: 0.01,
    fadeTransitions: true,
    fadeTime: 500,
    ...options,
  });

  // Additional methods for fine-grained control
  const setExactVolume = useCallback((volume) => {
    return volumeControl.updateVolume(volume);
  }, [volumeControl]);

  const adjustVolume = useCallback((adjustment) => {
    const newVolume = volumeControl.volume + adjustment;
    return volumeControl.updateVolume(newVolume);
  }, [volumeControl]);

  // Fade volume over time
  const fadeVolume = useCallback(async (targetVolume, duration = 1000) => {
    const startVolume = volumeControl.volume;
    const steps = 50;
    const stepTime = duration / steps;
    const volumeDiff = targetVolume - startVolume;

    for (let i = 1; i <= steps; i++) {
      await new Promise(resolve => setTimeout(resolve, stepTime));
      const intermediateVolume = startVolume + (volumeDiff * (i / steps));
      await setExactVolume(intermediateVolume);
    }
  }, [volumeControl.volume, setExactVolume]);

  return {
    ...volumeControl,
    setExactVolume,
    adjustVolume,
    fadeVolume,
  };
};

export default useVolumeControl;
