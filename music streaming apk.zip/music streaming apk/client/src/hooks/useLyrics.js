import { useState, useCallback, useEffect, useRef } from 'react';
import { usePlayer } from '../contexts/PlayerContext';
import { useCache } from './useCache';
import api from '../utils/api';

/**
 * Lyrics format types
 */
const LyricsFormats = {
  LRC: 'lrc',
  PLAIN: 'plain',
  ENHANCED: 'enhanced',
};

/**
 * Hook for handling lyrics synchronization and display
 * @param {Object} options - Lyrics options
 * @returns {Object} - Lyrics state and functions
 */
const useLyrics = (options = {}) => {
  const { audioRef } = usePlayer();
  const cache = useCache({
    persistKey: 'lyrics_cache',
    ttl: 24 * 60 * 60 * 1000, // 24 hours
  });

  const {
    format = LyricsFormats.LRC,
    autoSync = true,
    cacheLyrics = true,
    highlightColor = '#1DB954',
    fontSize = 16,
    lineHeight = 1.5,
    offset = 0,
  } = options;

  const [lyrics, setLyrics] = useState([]);
  const [currentLine, setCurrentLine] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const syncInterval = useRef(null);

  // Parse LRC format lyrics
  const parseLRC = useCallback((lrcContent) => {
    const lines = lrcContent.split('\n');
    const timeRegex = /\[(\d{2}):(\d{2})\.(\d{2,3})\]/;
    const parsedLyrics = [];

    lines.forEach(line => {
      const match = timeRegex.exec(line);
      if (match) {
        const minutes = parseInt(match[1]);
        const seconds = parseInt(match[2]);
        const milliseconds = parseInt(match[3]);
        const time = (minutes * 60 + seconds) + (milliseconds / 1000);
        const text = line.replace(timeRegex, '').trim();

        if (text) {
          parsedLyrics.push({
            time,
            text,
            translation: '',
            enhanced: {},
          });
        }
      }
    });

    return parsedLyrics.sort((a, b) => a.time - b.time);
  }, []);

  // Parse enhanced lyrics format
  const parseEnhanced = useCallback((enhancedContent) => {
    try {
      const parsed = JSON.parse(enhancedContent);
      return parsed.lines.map(line => ({
        time: line.time,
        text: line.text,
        translation: line.translation || '',
        enhanced: {
          words: line.words || [],
          notes: line.notes || [],
          chords: line.chords || [],
        },
      }));
    } catch (error) {
      console.error('Enhanced lyrics parsing error:', error);
      return [];
    }
  }, []);

  // Load lyrics from different sources
  const loadLyrics = useCallback(async (source) => {
    try {
      setLoading(true);
      setError(null);

      // Check cache first
      if (cacheLyrics) {
        const cachedLyrics = cache.get(source.id || source);
        if (cachedLyrics) {
          setLyrics(cachedLyrics);
          return cachedLyrics;
        }
      }

      let content;
      if (typeof source === 'string') {
        // Load from URL or file path
        const response = await api.get(source);
        content = response.data;
      } else if (source instanceof File) {
        // Load from File object
        content = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = reject;
          reader.readAsText(source);
        });
      } else {
        // Load from track object
        const response = await api.get(`/tracks/${source.id}/lyrics`);
        content = response.data;
      }

      // Parse lyrics based on format
      let parsedLyrics;
      switch (format) {
        case LyricsFormats.LRC:
          parsedLyrics = parseLRC(content);
          break;
        case LyricsFormats.ENHANCED:
          parsedLyrics = parseEnhanced(content);
          break;
        case LyricsFormats.PLAIN:
          parsedLyrics = content.split('\n').map((text, index) => ({
            time: index * 5, // Approximate timing
            text: text.trim(),
            translation: '',
            enhanced: {},
          }));
          break;
        default:
          throw new Error('Unsupported lyrics format');
      }

      // Cache lyrics
      if (cacheLyrics) {
        cache.set(source.id || source, parsedLyrics);
      }

      setLyrics(parsedLyrics);
      return parsedLyrics;
    } catch (error) {
      console.error('Lyrics loading error:', error);
      setError(error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  }, [format, cacheLyrics, cache, parseLRC, parseEnhanced]);

  // Find current lyrics line based on time
  const findCurrentLine = useCallback((time) => {
    const adjustedTime = time + offset;
    
    for (let i = lyrics.length - 1; i >= 0; i--) {
      if (lyrics[i].time <= adjustedTime) {
        return lyrics[i];
      }
    }
    return null;
  }, [lyrics, offset]);

  // Sync lyrics with audio
  const syncLyrics = useCallback(() => {
    if (!audioRef.current) return;

    const currentTime = audioRef.current.currentTime;
    const line = findCurrentLine(currentTime);
    
    if (line !== currentLine) {
      setCurrentLine(line);
    }
  }, [audioRef, findCurrentLine, currentLine]);

  // Start lyrics sync
  const startSync = useCallback(() => {
    if (!autoSync) return;
    syncInterval.current = setInterval(syncLyrics, 100);
  }, [autoSync, syncLyrics]);

  // Stop lyrics sync
  const stopSync = useCallback(() => {
    if (syncInterval.current) {
      clearInterval(syncInterval.current);
      syncInterval.current = null;
    }
  }, []);

  // Get lyrics for specific time
  const getLyricsAtTime = useCallback((time) => {
    return findCurrentLine(time);
  }, [findCurrentLine]);

  // Search lyrics
  const searchLyrics = useCallback((query) => {
    const searchTerm = query.toLowerCase();
    return lyrics.filter(line => 
      line.text.toLowerCase().includes(searchTerm) ||
      line.translation.toLowerCase().includes(searchTerm)
    );
  }, [lyrics]);

  // Format lyrics for display
  const formatLyrics = useCallback((line) => {
    if (!line) return '';

    return {
      text: line.text,
      translation: line.translation,
      enhanced: line.enhanced,
      style: {
        fontSize: `${fontSize}px`,
        lineHeight: lineHeight,
        color: line === currentLine ? highlightColor : 'inherit',
      },
    };
  }, [fontSize, lineHeight, highlightColor, currentLine]);

  // Export lyrics to different formats
  const exportLyrics = useCallback((exportFormat = format) => {
    switch (exportFormat) {
      case LyricsFormats.LRC:
        return lyrics.map(line => {
          const time = new Date(line.time * 1000).toISOString().substr(14, 5);
          return `[${time}]${line.text}`;
        }).join('\n');
      
      case LyricsFormats.ENHANCED:
        return JSON.stringify({
          version: '1.0',
          lines: lyrics,
        }, null, 2);
      
      case LyricsFormats.PLAIN:
        return lyrics.map(line => line.text).join('\n');
      
      default:
        throw new Error('Unsupported export format');
    }
  }, [lyrics, format]);

  // Auto-sync with audio playback
  useEffect(() => {
    if (!audioRef.current) return;

    const audio = audioRef.current;
    audio.addEventListener('play', startSync);
    audio.addEventListener('pause', stopSync);
    audio.addEventListener('seeking', syncLyrics);

    return () => {
      audio.removeEventListener('play', startSync);
      audio.removeEventListener('pause', stopSync);
      audio.removeEventListener('seeking', syncLyrics);
      stopSync();
    };
  }, [audioRef, startSync, stopSync, syncLyrics]);

  return {
    lyrics,
    currentLine,
    loading,
    error,
    loadLyrics,
    getLyricsAtTime,
    searchLyrics,
    formatLyrics,
    exportLyrics,
    LyricsFormats,
  };
};

/**
 * Hook for handling karaoke-style lyrics
 */
export const useKaraokeLyrics = (options = {}) => {
  const lyrics = useLyrics({
    format: LyricsFormats.ENHANCED,
    ...options,
  });

  // Highlight current word
  const highlightWord = useCallback((line, currentTime) => {
    if (!line?.enhanced?.words) return line;

    const words = line.enhanced.words.map(word => ({
      ...word,
      highlighted: currentTime >= word.time && 
                  currentTime < (word.time + word.duration),
    }));

    return {
      ...line,
      enhanced: {
        ...line.enhanced,
        words,
      },
    };
  }, []);

  return {
    ...lyrics,
    highlightWord,
  };
};

export default useLyrics;
