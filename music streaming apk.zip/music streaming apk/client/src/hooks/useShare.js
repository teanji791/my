import { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useAnalytics } from './useAnalytics';
import { showSnackbar } from '../store/slices/uiSlice';
import api from '../utils/api';

/**
 * Share platforms configuration
 */
const SharePlatforms = {
  FACEBOOK: 'facebook',
  TWITTER: 'twitter',
  WHATSAPP: 'whatsapp',
  TELEGRAM: 'telegram',
  EMAIL: 'email',
  COPY: 'copy',
};

/**
 * Share types configuration
 */
const ShareTypes = {
  TRACK: 'track',
  PLAYLIST: 'playlist',
  ALBUM: 'album',
  ARTIST: 'artist',
  PROFILE: 'profile',
};

/**
 * Hook for handling sharing functionality
 * @param {Object} options - Share options
 * @returns {Object} - Share functions and state
 */
const useShare = (options = {}) => {
  const dispatch = useDispatch();
  const analytics = useAnalytics();
  
  const {
    baseUrl = process.env.REACT_APP_BASE_URL || window.location.origin,
    platforms = Object.values(SharePlatforms),
    trackAnalytics = true,
  } = options;

  // Generate share URL
  const generateShareUrl = useCallback((type, id) => {
    return `${baseUrl}/${type}/${id}`;
  }, [baseUrl]);

  // Generate share text
  const generateShareText = useCallback((item, type) => {
    switch (type) {
      case ShareTypes.TRACK:
        return `Check out "${item.title}" by ${item.artist} on our music app!`;
      case ShareTypes.PLAYLIST:
        return `Check out this playlist "${item.name}" on our music app!`;
      case ShareTypes.ALBUM:
        return `Check out "${item.name}" by ${item.artist} on our music app!`;
      case ShareTypes.ARTIST:
        return `Check out ${item.name} on our music app!`;
      case ShareTypes.PROFILE:
        return `Check out ${item.username}'s profile on our music app!`;
      default:
        return 'Check out this awesome music on our app!';
    }
  }, []);

  // Share to social media platforms
  const shareToSocial = useCallback(async (platform, url, text) => {
    const encodedUrl = encodeURIComponent(url);
    const encodedText = encodeURIComponent(text);

    let shareUrl;
    switch (platform) {
      case SharePlatforms.FACEBOOK:
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
        break;
      case SharePlatforms.TWITTER:
        shareUrl = `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedText}`;
        break;
      case SharePlatforms.WHATSAPP:
        shareUrl = `https://wa.me/?text=${encodedText}%20${encodedUrl}`;
        break;
      case SharePlatforms.TELEGRAM:
        shareUrl = `https://t.me/share/url?url=${encodedUrl}&text=${encodedText}`;
        break;
      case SharePlatforms.EMAIL:
        shareUrl = `mailto:?subject=${encodedText}&body=${encodedUrl}`;
        break;
      default:
        return false;
    }

    // Open share dialog
    window.open(shareUrl, '_blank', 'width=600,height=400');
    return true;
  }, []);

  // Copy to clipboard
  const copyToClipboard = useCallback(async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      dispatch(showSnackbar({
        message: 'Link copied to clipboard!',
        severity: 'success',
      }));
      return true;
    } catch (error) {
      console.error('Copy to clipboard error:', error);
      dispatch(showSnackbar({
        message: 'Failed to copy link',
        severity: 'error',
      }));
      return false;
    }
  }, [dispatch]);

  // Share content
  const share = useCallback(async (item, type, platform = SharePlatforms.COPY) => {
    try {
      const url = generateShareUrl(type, item.id);
      const text = generateShareText(item, type);
      let success = false;

      if (platform === SharePlatforms.COPY) {
        success = await copyToClipboard(`${text} ${url}`);
      } else {
        success = await shareToSocial(platform, url, text);
      }

      if (success && trackAnalytics) {
        analytics.trackShare(type, item.id, platform);
      }

      // Track share on backend
      try {
        await api.post('/share', {
          type,
          itemId: item.id,
          platform,
        });
      } catch (error) {
        console.error('Share tracking error:', error);
      }

      return success;
    } catch (error) {
      console.error('Share error:', error);
      dispatch(showSnackbar({
        message: 'Failed to share content',
        severity: 'error',
      }));
      return false;
    }
  }, [
    generateShareUrl,
    generateShareText,
    shareToSocial,
    copyToClipboard,
    trackAnalytics,
    analytics,
    dispatch,
  ]);

  // Share multiple items
  const shareMultiple = useCallback(async (items, type, platform = SharePlatforms.COPY) => {
    try {
      const urls = items.map(item => generateShareUrl(type, item.id));
      const text = `Check out these ${type}s on our music app!`;
      let success = false;

      if (platform === SharePlatforms.COPY) {
        success = await copyToClipboard(`${text}\n\n${urls.join('\n')}`);
      } else {
        success = await shareToSocial(platform, urls[0], `${text} (${items.length} items)`);
      }

      if (success && trackAnalytics) {
        items.forEach(item => {
          analytics.trackShare(type, item.id, platform);
        });
      }

      return success;
    } catch (error) {
      console.error('Share multiple error:', error);
      dispatch(showSnackbar({
        message: 'Failed to share content',
        severity: 'error',
      }));
      return false;
    }
  }, [
    generateShareUrl,
    shareToSocial,
    copyToClipboard,
    trackAnalytics,
    analytics,
    dispatch,
  ]);

  // Check if Web Share API is available
  const isNativeShareAvailable = useCallback(() => {
    return navigator.share !== undefined;
  }, []);

  // Share using native share dialog
  const nativeShare = useCallback(async (item, type) => {
    if (!isNativeShareAvailable()) return false;

    try {
      const url = generateShareUrl(type, item.id);
      const text = generateShareText(item, type);

      await navigator.share({
        title: item.title || item.name,
        text,
        url,
      });

      if (trackAnalytics) {
        analytics.trackShare(type, item.id, 'native');
      }

      return true;
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('Native share error:', error);
        dispatch(showSnackbar({
          message: 'Failed to share content',
          severity: 'error',
        }));
      }
      return false;
    }
  }, [
    isNativeShareAvailable,
    generateShareUrl,
    generateShareText,
    trackAnalytics,
    analytics,
    dispatch,
  ]);

  return {
    share,
    shareMultiple,
    nativeShare,
    isNativeShareAvailable,
    SharePlatforms,
    ShareTypes,
    platforms,
  };
};

/**
 * Hook for sharing tracks
 */
export const useTrackShare = (options = {}) => {
  const shareHook = useShare(options);
  
  return {
    ...shareHook,
    shareTrack: (track, platform) => shareHook.share(track, ShareTypes.TRACK, platform),
    shareMultipleTracks: (tracks, platform) => shareHook.shareMultiple(tracks, ShareTypes.TRACK, platform),
  };
};

/**
 * Hook for sharing playlists
 */
export const usePlaylistShare = (options = {}) => {
  const shareHook = useShare(options);
  
  return {
    ...shareHook,
    sharePlaylist: (playlist, platform) => shareHook.share(playlist, ShareTypes.PLAYLIST, platform),
    shareMultiplePlaylists: (playlists, platform) => shareHook.shareMultiple(playlists, ShareTypes.PLAYLIST, platform),
  };
};

export default useShare;
