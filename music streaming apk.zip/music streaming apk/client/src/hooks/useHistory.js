import { useState, useCallback, useEffect } from 'react';
import { useLocation, useHistory as useRouterHistory } from 'react-router-dom';
import { useLocalStorage } from './useLocalStorage';
import { useAnalytics } from './useAnalytics';

/**
 * History types configuration
 */
const HistoryTypes = {
  PLAYBACK: 'playback',
  NAVIGATION: 'navigation',
  SEARCH: 'search',
};

/**
 * Hook for managing history
 * @param {Object} options - History options
 * @returns {Object} - History state and functions
 */
const useHistory = (options = {}) => {
  const location = useLocation();
  const routerHistory = useRouterHistory();
  const analytics = useAnalytics();
  
  const {
    type = HistoryTypes.NAVIGATION,
    maxItems = 50,
    persistHistory = true,
    trackAnalytics = true,
  } = options;

  // Initialize history state
  const [historyState, setHistoryState] = useLocalStorage(`${type}_history`, []);
  const [currentIndex, setCurrentIndex] = useState(-1);
  const [future, setFuture] = useState([]);

  // Add item to history
  const addToHistory = useCallback((item) => {
    setHistoryState(prevHistory => {
      // Remove duplicates
      const filteredHistory = prevHistory.filter(
        historyItem => JSON.stringify(historyItem) !== JSON.stringify(item)
      );

      // Add new item
      const newHistory = [item, ...filteredHistory].slice(0, maxItems);

      // Track analytics
      if (trackAnalytics) {
        analytics.trackEvent(`${type}_history_add`, {
          item,
          historyLength: newHistory.length,
        });
      }

      return newHistory;
    });

    // Reset future history when adding new item
    setFuture([]);
    setCurrentIndex(0);
  }, [type, maxItems, trackAnalytics, analytics, setHistoryState]);

  // Remove item from history
  const removeFromHistory = useCallback((index) => {
    setHistoryState(prevHistory => {
      const newHistory = [...prevHistory];
      newHistory.splice(index, 1);
      return newHistory;
    });

    // Adjust current index if necessary
    if (index <= currentIndex) {
      setCurrentIndex(prev => Math.max(-1, prev - 1));
    }
  }, [currentIndex, setHistoryState]);

  // Clear history
  const clearHistory = useCallback(() => {
    setHistoryState([]);
    setFuture([]);
    setCurrentIndex(-1);

    if (trackAnalytics) {
      analytics.trackEvent(`${type}_history_clear`);
    }
  }, [type, trackAnalytics, analytics, setHistoryState]);

  // Navigate through history
  const goBack = useCallback(() => {
    if (currentIndex < historyState.length - 1) {
      const item = historyState[currentIndex + 1];
      setCurrentIndex(currentIndex + 1);
      setFuture(prev => [historyState[currentIndex], ...prev]);

      if (type === HistoryTypes.NAVIGATION) {
        routerHistory.push(item.path);
      }

      return item;
    }
    return null;
  }, [currentIndex, historyState, type, routerHistory]);

  const goForward = useCallback(() => {
    if (future.length > 0) {
      const [item, ...remainingFuture] = future;
      setCurrentIndex(currentIndex - 1);
      setFuture(remainingFuture);

      if (type === HistoryTypes.NAVIGATION) {
        routerHistory.push(item.path);
      }

      return item;
    }
    return null;
  }, [currentIndex, future, type, routerHistory]);

  // Jump to specific point in history
  const jumpToIndex = useCallback((index) => {
    if (index >= 0 && index < historyState.length) {
      const item = historyState[index];
      const newFuture = historyState.slice(0, index).reverse();
      
      setCurrentIndex(index);
      setFuture(newFuture);

      if (type === HistoryTypes.NAVIGATION) {
        routerHistory.push(item.path);
      }

      return item;
    }
    return null;
  }, [historyState, type, routerHistory]);

  // Track navigation history
  useEffect(() => {
    if (type === HistoryTypes.NAVIGATION) {
      const navigationItem = {
        path: location.pathname,
        search: location.search,
        timestamp: Date.now(),
      };

      // Only add to history if path changed
      if (historyState[0]?.path !== navigationItem.path) {
        addToHistory(navigationItem);
      }
    }
  }, [type, location, historyState, addToHistory]);

  // Get history stats
  const getStats = useCallback(() => {
    return {
      total: historyState.length,
      current: currentIndex,
      hasFuture: future.length > 0,
      hasBack: currentIndex < historyState.length - 1,
    };
  }, [historyState, currentIndex, future]);

  // Search history
  const searchHistory = useCallback((query) => {
    const searchTerm = query.toLowerCase();
    return historyState.filter(item => {
      const itemString = JSON.stringify(item).toLowerCase();
      return itemString.includes(searchTerm);
    });
  }, [historyState]);

  // Get recent items
  const getRecent = useCallback((limit = 10) => {
    return historyState.slice(0, limit);
  }, [historyState]);

  // Get most frequent items
  const getMostFrequent = useCallback((limit = 10) => {
    const frequency = historyState.reduce((acc, item) => {
      const key = JSON.stringify(item);
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {});

    return Object.entries(frequency)
      .sort(([, a], [, b]) => b - a)
      .slice(0, limit)
      .map(([item]) => JSON.parse(item));
  }, [historyState]);

  return {
    history: historyState,
    currentItem: historyState[currentIndex],
    currentIndex,
    future,
    addToHistory,
    removeFromHistory,
    clearHistory,
    goBack,
    goForward,
    jumpToIndex,
    getStats,
    searchHistory,
    getRecent,
    getMostFrequent,
    HistoryTypes,
  };
};

/**
 * Hook for managing playback history
 */
export const usePlaybackHistory = (options = {}) => {
  const historyHook = useHistory({
    type: HistoryTypes.PLAYBACK,
    ...options,
  });

  const addTrackToHistory = useCallback((track) => {
    historyHook.addToHistory({
      ...track,
      playedAt: Date.now(),
    });
  }, [historyHook]);

  return {
    ...historyHook,
    addTrackToHistory,
  };
};

/**
 * Hook for managing search history
 */
export const useSearchHistory = (options = {}) => {
  const historyHook = useHistory({
    type: HistoryTypes.SEARCH,
    ...options,
  });

  const addSearchToHistory = useCallback((query, results) => {
    historyHook.addToHistory({
      query,
      resultCount: results.length,
      timestamp: Date.now(),
    });
  }, [historyHook]);

  return {
    ...historyHook,
    addSearchToHistory,
  };
};

export default useHistory;
