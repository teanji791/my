import { useState, useEffect, useCallback, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { showErrorSnackbar } from '../store/slices/uiSlice';

/**
 * Cache configuration
 */
const defaultConfig = {
  maxSize: 100, // Maximum number of items in cache
  ttl: 5 * 60 * 1000, // Time to live (5 minutes)
  persistKey: 'app_cache', // localStorage key for persistence
  serialize: JSON.stringify,
  deserialize: JSON.parse,
  compression: false, // Enable/disable compression
};

/**
 * LRU Cache implementation
 */
class LRUCache {
  constructor(maxSize = 100) {
    this.maxSize = maxSize;
    this.cache = new Map();
  }

  get(key) {
    if (!this.cache.has(key)) return undefined;

    // Get item and refresh its position
    const item = this.cache.get(key);
    this.cache.delete(key);
    this.cache.set(key, item);
    return item;
  }

  set(key, value) {
    if (this.cache.has(key)) {
      this.cache.delete(key);
    } else if (this.cache.size >= this.maxSize) {
      // Remove least recently used item
      this.cache.delete(this.cache.keys().next().value);
    }
    this.cache.set(key, value);
  }

  delete(key) {
    this.cache.delete(key);
  }

  clear() {
    this.cache.clear();
  }

  has(key) {
    return this.cache.has(key);
  }

  size() {
    return this.cache.size;
  }

  keys() {
    return Array.from(this.cache.keys());
  }

  values() {
    return Array.from(this.cache.values());
  }

  entries() {
    return Array.from(this.cache.entries());
  }
}

/**
 * Hook for managing cache
 * @param {Object} config - Cache configuration
 * @returns {Object} - Cache functions and state
 */
const useCache = (config = {}) => {
  const dispatch = useDispatch();
  const {
    maxSize,
    ttl,
    persistKey,
    serialize,
    deserialize,
    compression,
  } = { ...defaultConfig, ...config };

  const cache = useRef(new LRUCache(maxSize));
  const [size, setSize] = useState(0);

  // Load persisted cache on mount
  useEffect(() => {
    try {
      const persistedCache = localStorage.getItem(persistKey);
      if (persistedCache) {
        const { entries, timestamp } = deserialize(persistedCache);
        
        // Check if cache has expired
        if (Date.now() - timestamp < ttl) {
          entries.forEach(([key, value]) => {
            cache.current.set(key, value);
          });
          setSize(cache.current.size());
        } else {
          localStorage.removeItem(persistKey);
        }
      }
    } catch (error) {
      console.error('Error loading cache:', error);
      dispatch(showErrorSnackbar('Error loading cache'));
    }
  }, [persistKey, ttl, deserialize, dispatch]);

  // Save cache to localStorage
  const persistCache = useCallback(() => {
    try {
      const data = {
        entries: cache.current.entries(),
        timestamp: Date.now(),
      };
      localStorage.setItem(persistKey, serialize(data));
    } catch (error) {
      console.error('Error persisting cache:', error);
      dispatch(showErrorSnackbar('Error saving cache'));
    }
  }, [persistKey, serialize, dispatch]);

  // Compress data if enabled
  const compressData = useCallback((data) => {
    if (!compression) return data;
    try {
      return btoa(serialize(data));
    } catch (error) {
      console.error('Error compressing data:', error);
      return data;
    }
  }, [compression, serialize]);

  // Decompress data if enabled
  const decompressData = useCallback((data) => {
    if (!compression) return data;
    try {
      return deserialize(atob(data));
    } catch (error) {
      console.error('Error decompressing data:', error);
      return data;
    }
  }, [compression, deserialize]);

  // Get item from cache
  const get = useCallback((key) => {
    const item = cache.current.get(key);
    if (!item) return undefined;

    const { value, timestamp } = item;
    
    // Check if item has expired
    if (Date.now() - timestamp > ttl) {
      cache.current.delete(key);
      setSize(cache.current.size());
      return undefined;
    }

    return decompressData(value);
  }, [ttl, decompressData]);

  // Set item in cache
  const set = useCallback((key, value) => {
    const item = {
      value: compressData(value),
      timestamp: Date.now(),
    };
    cache.current.set(key, item);
    setSize(cache.current.size());
    persistCache();
  }, [compressData, persistCache]);

  // Remove item from cache
  const remove = useCallback((key) => {
    cache.current.delete(key);
    setSize(cache.current.size());
    persistCache();
  }, [persistCache]);

  // Clear entire cache
  const clear = useCallback(() => {
    cache.current.clear();
    setSize(0);
    localStorage.removeItem(persistKey);
  }, [persistKey]);

  // Check if key exists in cache
  const has = useCallback((key) => {
    return cache.current.has(key);
  }, []);

  // Get all cache keys
  const keys = useCallback(() => {
    return cache.current.keys();
  }, []);

  // Get cache statistics
  const getStats = useCallback(() => {
    return {
      size,
      maxSize,
      usage: size / maxSize,
      keys: keys(),
    };
  }, [size, maxSize, keys]);

  // Prefetch data
  const prefetch = useCallback(async (key, fetchFn) => {
    if (has(key)) return;
    try {
      const data = await fetchFn();
      set(key, data);
    } catch (error) {
      console.error('Error prefetching data:', error);
    }
  }, [has, set]);

  // Get or fetch data
  const getOrFetch = useCallback(async (key, fetchFn) => {
    const cachedData = get(key);
    if (cachedData !== undefined) {
      return cachedData;
    }

    try {
      const data = await fetchFn();
      set(key, data);
      return data;
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  }, [get, set]);

  return {
    get,
    set,
    remove,
    clear,
    has,
    keys,
    size,
    getStats,
    prefetch,
    getOrFetch,
  };
};

/**
 * Hook for caching API responses
 */
export const useApiCache = (config = {}) => {
  const cache = useCache({
    persistKey: 'app_api_cache',
    ttl: 15 * 60 * 1000, // 15 minutes
    ...config,
  });

  const fetchWithCache = useCallback(async (key, fetchFn) => {
    return cache.getOrFetch(key, fetchFn);
  }, [cache]);

  return {
    ...cache,
    fetchWithCache,
  };
};

/**
 * Hook for caching music data
 */
export const useMusicCache = (config = {}) => {
  const cache = useCache({
    persistKey: 'app_music_cache',
    ttl: 60 * 60 * 1000, // 1 hour
    ...config,
  });

  const cacheTrack = useCallback((track) => {
    cache.set(`track_${track.id}`, track);
  }, [cache]);

  const getCachedTrack = useCallback((trackId) => {
    return cache.get(`track_${trackId}`);
  }, [cache]);

  return {
    ...cache,
    cacheTrack,
    getCachedTrack,
  };
};

export default useCache;
