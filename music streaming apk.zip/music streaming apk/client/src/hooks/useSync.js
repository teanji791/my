import { useState, useCallback, useEffect, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { useAuth } from '../contexts/AuthContext';
import { useAnalytics } from './useAnalytics';
import { showSnackbar } from '../store/slices/uiSlice';
import api from '../utils/api';

/**
 * Sync types configuration
 */
const SyncTypes = {
  PLAYLISTS: 'playlists',
  FAVORITES: 'favorites',
  SETTINGS: 'settings',
  HISTORY: 'history',
  QUEUE: 'queue',
  ALL: 'all',
};

/**
 * Sync status types
 */
const SyncStatus = {
  IDLE: 'idle',
  SYNCING: 'syncing',
  COMPLETED: 'completed',
  ERROR: 'error',
  CONFLICT: 'conflict',
};

/**
 * Hook for handling data synchronization
 * @param {Object} options - Sync options
 * @returns {Object} - Sync state and functions
 */
const useSync = (options = {}) => {
  const dispatch = useDispatch();
  const { user } = useAuth();
  const analytics = useAnalytics();

  const {
    autoSync = true,
    syncInterval = 5 * 60 * 1000, // 5 minutes
    retryAttempts = 3,
    retryDelay = 1000,
    conflictResolution = 'server', // 'server' or 'local' or 'manual'
    types = Object.values(SyncTypes),
  } = options;

  const [syncStatus, setSyncStatus] = useState(SyncStatus.IDLE);
  const [lastSynced, setLastSynced] = useState(null);
  const [conflicts, setConflicts] = useState(new Map());
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState(null);
  const syncTimeout = useRef(null);
  const retryCount = useRef(0);

  // Get sync timestamp
  const getSyncTimestamp = useCallback(async () => {
    try {
      const response = await api.get('/sync/timestamp');
      return response.data.timestamp;
    } catch (error) {
      console.error('Sync timestamp error:', error);
      return null;
    }
  }, []);

  // Check for changes
  const checkChanges = useCallback(async () => {
    if (!lastSynced) return true;

    try {
      const serverTimestamp = await getSyncTimestamp();
      return serverTimestamp > lastSynced;
    } catch (error) {
      console.error('Check changes error:', error);
      return true;
    }
  }, [lastSynced, getSyncTimestamp]);

  // Resolve conflicts
  const resolveConflicts = useCallback(async (localData, serverData, type) => {
    switch (conflictResolution) {
      case 'server':
        return serverData;
      case 'local':
        return localData;
      case 'manual':
        setConflicts(prev => new Map(prev).set(type, {
          local: localData,
          server: serverData,
        }));
        return null;
      default:
        return serverData;
    }
  }, [conflictResolution]);

  // Sync specific type
  const syncType = useCallback(async (type) => {
    try {
      // Get local data
      const localData = await localStorage.getItem(`sync_${type}`);
      const localVersion = JSON.parse(localData || '{}');

      // Get server data
      const response = await api.get(`/sync/${type}`);
      const serverVersion = response.data;

      // Check for conflicts
      if (localVersion.version && serverVersion.version) {
        if (localVersion.version !== serverVersion.version) {
          const resolved = await resolveConflicts(
            localVersion.data,
            serverVersion.data,
            type
          );

          if (!resolved) {
            return false; // Manual resolution needed
          }

          // Update with resolved data
          await api.put(`/sync/${type}`, {
            data: resolved,
            version: serverVersion.version + 1,
          });

          await localStorage.setItem(`sync_${type}`, JSON.stringify({
            data: resolved,
            version: serverVersion.version + 1,
          }));
        }
      } else {
        // Initial sync
        await localStorage.setItem(`sync_${type}`, JSON.stringify(serverVersion));
      }

      return true;
    } catch (error) {
      console.error(`Sync error for ${type}:`, error);
      throw error;
    }
  }, [resolveConflicts]);

  // Sync all data
  const sync = useCallback(async (forcedTypes = types) => {
    if (syncStatus === SyncStatus.SYNCING || !user) return false;

    try {
      // Check if sync is needed
      const hasChanges = await checkChanges();
      if (!hasChanges && !forcedTypes) {
        return true;
      }

      setSyncStatus(SyncStatus.SYNCING);
      setError(null);
      setProgress(0);

      const typesToSync = forcedTypes || types;
      let completed = 0;

      // Sync each type
      for (const type of typesToSync) {
        try {
          await syncType(type);
          completed++;
          setProgress((completed / typesToSync.length) * 100);
        } catch (error) {
          if (retryCount.current < retryAttempts) {
            retryCount.current++;
            await new Promise(resolve => setTimeout(resolve, retryDelay));
            // Retry this type
            await syncType(type);
          } else {
            throw error;
          }
        }
      }

      setLastSynced(Date.now());
      setSyncStatus(SyncStatus.COMPLETED);
      retryCount.current = 0;

      analytics.trackEvent('sync_completed', {
        types: typesToSync,
        duration: Date.now() - lastSynced,
      });

      return true;
    } catch (error) {
      console.error('Sync error:', error);
      setError(error.message);
      setSyncStatus(SyncStatus.ERROR);

      dispatch(showSnackbar({
        message: 'Error syncing data',
        severity: 'error',
      }));

      return false;
    }
  }, [
    user,
    syncStatus,
    types,
    checkChanges,
    syncType,
    retryAttempts,
    retryDelay,
    lastSynced,
    analytics,
    dispatch,
  ]);

  // Manual conflict resolution
  const resolveConflict = useCallback(async (type, resolution) => {
    try {
      const conflict = conflicts.get(type);
      if (!conflict) return false;

      const data = resolution === 'local' ? conflict.local : conflict.server;

      await api.put(`/sync/${type}`, {
        data,
        version: Date.now(),
      });

      await localStorage.setItem(`sync_${type}`, JSON.stringify({
        data,
        version: Date.now(),
      }));

      setConflicts(prev => {
        const next = new Map(prev);
        next.delete(type);
        return next;
      });

      return true;
    } catch (error) {
      console.error('Conflict resolution error:', error);
      return false;
    }
  }, [conflicts]);

  // Auto sync
  useEffect(() => {
    if (!autoSync || !user) return;

    const shouldSync = !lastSynced || 
      (Date.now() - lastSynced) >= syncInterval;

    if (shouldSync) {
      sync();
    }

    syncTimeout.current = setInterval(sync, syncInterval);

    return () => {
      if (syncTimeout.current) {
        clearInterval(syncTimeout.current);
      }
    };
  }, [autoSync, user, lastSynced, syncInterval, sync]);

  return {
    syncStatus,
    lastSynced,
    conflicts,
    progress,
    error,
    sync,
    resolveConflict,
    SyncTypes,
    SyncStatus,
  };
};

/**
 * Hook for handling playlist synchronization
 */
export const usePlaylistSync = (options = {}) => {
  const syncHook = useSync({
    types: [SyncTypes.PLAYLISTS],
    ...options,
  });

  const syncPlaylists = useCallback(() => {
    return syncHook.sync([SyncTypes.PLAYLISTS]);
  }, [syncHook]);

  return {
    ...syncHook,
    syncPlaylists,
  };
};

export default useSync;
