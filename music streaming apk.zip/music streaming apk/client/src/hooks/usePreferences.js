import { useState, useCallback, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useLocalStorage } from './useLocalStorage';
import { useAnalytics } from './useAnalytics';
import { useSync } from './useSync';
import { showSnackbar } from '../store/slices/uiSlice';
import api from '../utils/api';

/**
 * Preference categories
 */
const PreferenceCategories = {
  PLAYBACK: 'playback',
  AUDIO: 'audio',
  INTERFACE: 'interface',
  NOTIFICATIONS: 'notifications',
  PRIVACY: 'privacy',
  DOWNLOADS: 'downloads',
  SOCIAL: 'social',
  LANGUAGE: 'language',
};

/**
 * Default preferences configuration
 */
const defaultPreferences = {
  [PreferenceCategories.PLAYBACK]: {
    autoplay: true,
    crossfade: false,
    crossfadeDuration: 3,
    gapless: true,
    repeat: 'none',
    shuffle: false,
    normalizeVolume: true,
  },
  [PreferenceCategories.AUDIO]: {
    quality: 'high',
    equalizer: false,
    equalizerPreset: 'flat',
    spatialAudio: false,
    replayGain: 'album',
  },
  [PreferenceCategories.INTERFACE]: {
    theme: 'system',
    color: '#1DB954',
    fontSize: 'medium',
    showLyrics: true,
    showArtwork: true,
    miniPlayer: false,
  },
  [PreferenceCategories.NOTIFICATIONS]: {
    newReleases: true,
    playlistUpdates: true,
    friendActivity: true,
    sound: true,
    desktop: true,
  },
  [PreferenceCategories.PRIVACY]: {
    shareListening: 'friends',
    showRecentlyPlayed: true,
    allowRecommendations: true,
    collectAnalytics: true,
  },
  [PreferenceCategories.DOWNLOADS]: {
    autoDownload: false,
    downloadQuality: 'high',
    wifiOnly: true,
    storageLimit: 10 * 1024 * 1024 * 1024, // 10GB
  },
  [PreferenceCategories.SOCIAL]: {
    autoFollow: false,
    showActivity: true,
    allowMessages: 'friends',
    showPlaylists: true,
  },
  [PreferenceCategories.LANGUAGE]: {
    app: 'en',
    content: 'en',
    lyrics: 'original',
  },
};

/**
 * Hook for handling user preferences
 * @param {Object} options - Preferences options
 * @returns {Object} - Preferences state and functions
 */
const usePreferences = (options = {}) => {
  const dispatch = useDispatch();
  const analytics = useAnalytics();
  const sync = useSync();

  const {
    syncPreferences = true,
    persistLocally = true,
    validateChanges = true,
    applyImmediately = true,
  } = options;

  const [preferences, setPreferences] = useLocalStorage(
    'preferences',
    defaultPreferences
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [pendingChanges, setPendingChanges] = useState({});

  // Load preferences
  const loadPreferences = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await api.get('/preferences');
      const serverPreferences = response.data;

      // Merge with defaults
      const mergedPreferences = {};
      Object.keys(defaultPreferences).forEach(category => {
        mergedPreferences[category] = {
          ...defaultPreferences[category],
          ...(serverPreferences[category] || {}),
        };
      });

      setPreferences(mergedPreferences);

      analytics.trackEvent('preferences_loaded');

      return mergedPreferences;
    } catch (error) {
      console.error('Load preferences error:', error);
      setError(error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  }, [setPreferences, analytics]);

  // Update preference
  const updatePreference = useCallback(async (category, key, value) => {
    try {
      // Validate change
      if (validateChanges) {
        const validator = getPreferenceValidator(category, key);
        if (validator && !validator(value)) {
          throw new Error(`Invalid value for ${category}.${key}`);
        }
      }

      const update = {
        [category]: {
          ...preferences[category],
          [key]: value,
        },
      };

      if (applyImmediately) {
        // Update immediately
        setPreferences(prev => ({
          ...prev,
          ...update,
        }));

        if (syncPreferences) {
          await api.put('/preferences', update);
          sync.sync(['preferences']);
        }

        analytics.trackEvent('preference_updated', {
          category,
          key,
          value,
        });

        dispatch(showSnackbar({
          message: 'Preference updated',
          severity: 'success',
        }));
      } else {
        // Add to pending changes
        setPendingChanges(prev => ({
          ...prev,
          [category]: {
            ...(prev[category] || {}),
            [key]: value,
          },
        }));
      }

      return true;
    } catch (error) {
      console.error('Update preference error:', error);
      dispatch(showSnackbar({
        message: error.message || 'Error updating preference',
        severity: 'error',
      }));
      return false;
    }
  }, [
    preferences,
    validateChanges,
    applyImmediately,
    syncPreferences,
    setPreferences,
    sync,
    analytics,
    dispatch,
  ]);

  // Save pending changes
  const saveChanges = useCallback(async () => {
    if (Object.keys(pendingChanges).length === 0) return true;

    try {
      // Update local state
      setPreferences(prev => ({
        ...prev,
        ...pendingChanges,
      }));

      if (syncPreferences) {
        // Update server
        await api.put('/preferences', pendingChanges);
        sync.sync(['preferences']);
      }

      // Clear pending changes
      setPendingChanges({});

      analytics.trackEvent('preferences_saved', {
        changes: Object.keys(pendingChanges).length,
      });

      dispatch(showSnackbar({
        message: 'Preferences saved',
        severity: 'success',
      }));

      return true;
    } catch (error) {
      console.error('Save changes error:', error);
      dispatch(showSnackbar({
        message: 'Error saving preferences',
        severity: 'error',
      }));
      return false;
    }
  }, [
    pendingChanges,
    syncPreferences,
    setPreferences,
    sync,
    analytics,
    dispatch,
  ]);

  // Reset preferences
  const resetPreferences = useCallback(async (categories = Object.keys(defaultPreferences)) => {
    try {
      const resetValues = {};
      categories.forEach(category => {
        resetValues[category] = defaultPreferences[category];
      });

      setPreferences(prev => ({
        ...prev,
        ...resetValues,
      }));

      if (syncPreferences) {
        await api.put('/preferences', resetValues);
        sync.sync(['preferences']);
      }

      analytics.trackEvent('preferences_reset', {
        categories,
      });

      dispatch(showSnackbar({
        message: 'Preferences reset to default',
        severity: 'success',
      }));

      return true;
    } catch (error) {
      console.error('Reset preferences error:', error);
      dispatch(showSnackbar({
        message: 'Error resetting preferences',
        severity: 'error',
      }));
      return false;
    }
  }, [syncPreferences, setPreferences, sync, analytics, dispatch]);

  // Export preferences
  const exportPreferences = useCallback(async () => {
    try {
      const data = JSON.stringify(preferences, null, 2);
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'preferences.json';
      link.click();
      URL.revokeObjectURL(url);

      analytics.trackEvent('preferences_exported');
      return true;
    } catch (error) {
      console.error('Export preferences error:', error);
      return false;
    }
  }, [preferences, analytics]);

  // Import preferences
  const importPreferences = useCallback(async (file) => {
    try {
      const content = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.onerror = reject;
        reader.readAsText(file);
      });

      const importedPreferences = JSON.parse(content);
      await updatePreference(importedPreferences);

      analytics.trackEvent('preferences_imported');
      return true;
    } catch (error) {
      console.error('Import preferences error:', error);
      return false;
    }
  }, [updatePreference, analytics]);

  // Load preferences on mount
  useEffect(() => {
    loadPreferences();
  }, [loadPreferences]);

  return {
    preferences,
    pendingChanges,
    loading,
    error,
    updatePreference,
    saveChanges,
    resetPreferences,
    exportPreferences,
    importPreferences,
    PreferenceCategories,
  };
};

// Preference validators
const getPreferenceValidator = (category, key) => {
  const validators = {
    [PreferenceCategories.PLAYBACK]: {
      crossfadeDuration: value => value >= 0 && value <= 12,
    },
    [PreferenceCategories.AUDIO]: {
      quality: value => ['low', 'medium', 'high'].includes(value),
    },
    [PreferenceCategories.DOWNLOADS]: {
      storageLimit: value => value >= 0,
    },
  };

  return validators[category]?.[key];
};

/**
 * Hook for handling playback preferences
 */
export const usePlaybackPreferences = (options = {}) => {
  const preferences = usePreferences(options);

  const updatePlaybackPreference = useCallback((key, value) => {
    return preferences.updatePreference(PreferenceCategories.PLAYBACK, key, value);
  }, [preferences]);

  return {
    ...preferences,
    updatePlaybackPreference,
    playbackPreferences: preferences.preferences[PreferenceCategories.PLAYBACK],
  };
};

export default usePreferences;
