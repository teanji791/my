import { useState, useCallback, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { useLocalStorage } from './useLocalStorage';
import { showSnackbar } from '../store/slices/uiSlice';

/**
 * Hook for managing music queue
 * @param {Object} options - Queue options
 * @returns {Object} - Queue state and functions
 */
const useQueue = (options = {}) => {
  const dispatch = useDispatch();
  const {
    maxSize = 1000,
    persistQueue = true,
    shuffleOnAdd = false,
    autoplay = true,
  } = options;

  // Queue state
  const [queue, setQueue] = useLocalStorage('music_queue', []);
  const [history, setHistory] = useLocalStorage('music_history', []);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isShuffled, setIsShuffled] = useState(false);
  const originalQueue = useRef([]);
  const shuffledIndices = useRef([]);

  // Get current track
  const getCurrentTrack = useCallback(() => {
    return queue[currentIndex] || null;
  }, [queue, currentIndex]);

  // Add tracks to queue
  const addToQueue = useCallback((tracks, position = 'end') => {
    if (!Array.isArray(tracks)) {
      tracks = [tracks];
    }

    // Validate queue size
    if (queue.length + tracks.length > maxSize) {
      dispatch(showSnackbar({
        message: `Queue limit of ${maxSize} tracks reached`,
        severity: 'warning',
      }));
      return false;
    }

    setQueue(prevQueue => {
      let newQueue;
      switch (position) {
        case 'start':
          newQueue = [...tracks, ...prevQueue];
          setCurrentIndex(prevIndex => prevIndex + tracks.length);
          break;
        case 'next':
          newQueue = [
            ...prevQueue.slice(0, currentIndex + 1),
            ...tracks,
            ...prevQueue.slice(currentIndex + 1),
          ];
          break;
        case 'end':
        default:
          newQueue = [...prevQueue, ...tracks];
          break;
      }

      originalQueue.current = [...newQueue];
      
      if (shuffleOnAdd && isShuffled) {
        return shuffleQueue(newQueue);
      }
      
      return newQueue;
    });

    return true;
  }, [queue, maxSize, currentIndex, shuffleOnAdd, isShuffled, dispatch, setQueue]);

  // Remove tracks from queue
  const removeFromQueue = useCallback((indices) => {
    if (!Array.isArray(indices)) {
      indices = [indices];
    }

    setQueue(prevQueue => {
      const newQueue = prevQueue.filter((_, index) => !indices.includes(index));
      originalQueue.current = [...newQueue];
      
      // Adjust current index if necessary
      const removedBeforeCurrent = indices.filter(i => i < currentIndex).length;
      setCurrentIndex(prevIndex => Math.max(0, prevIndex - removedBeforeCurrent));
      
      return isShuffled ? shuffleQueue(newQueue) : newQueue;
    });
  }, [currentIndex, isShuffled, setQueue]);

  // Clear queue
  const clearQueue = useCallback(() => {
    setQueue([]);
    setCurrentIndex(0);
    originalQueue.current = [];
    shuffledIndices.current = [];
  }, [setQueue]);

  // Move track in queue
  const moveTrack = useCallback((fromIndex, toIndex) => {
    setQueue(prevQueue => {
      const newQueue = [...prevQueue];
      const [movedTrack] = newQueue.splice(fromIndex, 1);
      newQueue.splice(toIndex, 0, movedTrack);
      originalQueue.current = [...newQueue];

      // Adjust current index if necessary
      if (fromIndex === currentIndex) {
        setCurrentIndex(toIndex);
      } else if (
        fromIndex < currentIndex && toIndex >= currentIndex ||
        fromIndex > currentIndex && toIndex <= currentIndex
      ) {
        setCurrentIndex(prevIndex => 
          fromIndex < currentIndex ? prevIndex - 1 : prevIndex + 1
        );
      }

      return isShuffled ? shuffleQueue(newQueue) : newQueue;
    });
  }, [currentIndex, isShuffled, setQueue]);

  // Shuffle queue
  const shuffleQueue = useCallback((queueToShuffle = queue) => {
    const indices = Array.from({ length: queueToShuffle.length }, (_, i) => i);
    const currentTrack = queueToShuffle[currentIndex];

    // Remove current track from shuffle
    indices.splice(currentIndex, 1);

    // Shuffle remaining indices
    for (let i = indices.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [indices[i], indices[j]] = [indices[j], indices[i]];
    }

    // Put current track at current index
    indices.splice(currentIndex, 0, currentIndex);
    shuffledIndices.current = indices;

    return indices.map(i => queueToShuffle[i]);
  }, [queue, currentIndex]);

  // Toggle shuffle
  const toggleShuffle = useCallback(() => {
    setIsShuffled(prevShuffled => {
      const newShuffled = !prevShuffled;
      setQueue(prevQueue => 
        newShuffled ? shuffleQueue(prevQueue) : [...originalQueue.current]
      );
      return newShuffled;
    });
  }, [setQueue, shuffleQueue]);

  // Navigate queue
  const next = useCallback(() => {
    if (currentIndex < queue.length - 1) {
      setCurrentIndex(prevIndex => prevIndex + 1);
      return true;
    }
    return false;
  }, [queue, currentIndex]);

  const previous = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex(prevIndex => prevIndex - 1);
      return true;
    }
    return false;
  }, [currentIndex]);

  const jumpTo = useCallback((index) => {
    if (index >= 0 && index < queue.length) {
      setCurrentIndex(index);
      return true;
    }
    return false;
  }, [queue]);

  // Queue history management
  const addToHistory = useCallback((track) => {
    setHistory(prevHistory => {
      const newHistory = [track, ...prevHistory.slice(0, 49)]; // Keep last 50 tracks
      return newHistory;
    });
  }, [setHistory]);

  const clearHistory = useCallback(() => {
    setHistory([]);
  }, [setHistory]);

  // Get queue information
  const getQueueInfo = useCallback(() => {
    return {
      length: queue.length,
      currentIndex,
      currentTrack: getCurrentTrack(),
      isShuffled,
      hasNext: currentIndex < queue.length - 1,
      hasPrevious: currentIndex > 0,
    };
  }, [queue, currentIndex, getCurrentTrack, isShuffled]);

  return {
    queue,
    currentIndex,
    currentTrack: getCurrentTrack(),
    history,
    isShuffled,
    addToQueue,
    removeFromQueue,
    clearQueue,
    moveTrack,
    toggleShuffle,
    next,
    previous,
    jumpTo,
    addToHistory,
    clearHistory,
    getQueueInfo,
  };
};

export default useQueue;
