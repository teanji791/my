import { useState, useEffect, useMemo } from 'react';

/**
 * Predefined breakpoints that match Material-UI's default breakpoints
 */
export const breakpoints = {
  xs: '(max-width: 599px)',
  sm: '(min-width: 600px) and (max-width: 959px)',
  md: '(min-width: 960px) and (max-width: 1279px)',
  lg: '(min-width: 1280px) and (max-width: 1919px)',
  xl: '(min-width: 1920px)',
  mobile: '(max-width: 767px)',
  tablet: '(min-width: 768px) and (max-width: 1023px)',
  desktop: '(min-width: 1024px)',
  portrait: '(orientation: portrait)',
  landscape: '(orientation: landscape)',
  dark: '(prefers-color-scheme: dark)',
  light: '(prefers-color-scheme: light)',
  reducedMotion: '(prefers-reduced-motion: reduce)',
  retina: '(-webkit-min-device-pixel-ratio: 2), (min-resolution: 192dpi)',
};

/**
 * Hook to handle media queries
 * @param {string} query - The media query to check
 * @returns {boolean} - Whether the media query matches
 */
const useMediaQuery = (query) => {
  // Get the media query string
  const mediaQuery = useMemo(() => {
    // If it's a predefined breakpoint, use that
    if (breakpoints[query]) {
      return breakpoints[query];
    }
    // Otherwise use the raw query
    return query;
  }, [query]);

  // Initialize state with the current match
  const [matches, setMatches] = useState(() => {
    // Check for SSR
    if (typeof window === 'undefined') {
      return false;
    }
    return window.matchMedia(mediaQuery).matches;
  });

  useEffect(() => {
    // Check for SSR
    if (typeof window === 'undefined') {
      return undefined;
    }

    // Create media query list
    const mediaQueryList = window.matchMedia(mediaQuery);

    // Update state on change
    const updateMatches = (e) => {
      setMatches(e.matches);
    };

    // Add listener and set initial value
    mediaQueryList.addListener(updateMatches);
    setMatches(mediaQueryList.matches);

    // Cleanup
    return () => {
      mediaQueryList.removeListener(updateMatches);
    };
  }, [mediaQuery]);

  return matches;
};

/**
 * Hook to handle multiple media queries
 * @param {Object} queries - Object with query names and values
 * @returns {Object} - Object with query names and their match states
 */
export const useMediaQueries = (queries) => {
  const mediaQueries = {};

  Object.keys(queries).forEach((key) => {
    mediaQueries[key] = useMediaQuery(queries[key]);
  });

  return mediaQueries;
};

/**
 * Hook to handle responsive values based on breakpoints
 * @param {Object} values - Object with breakpoint values
 * @returns {*} - The value for the current breakpoint
 */
export const useResponsiveValue = (values) => {
  const queries = useMediaQueries({
    mobile: breakpoints.mobile,
    tablet: breakpoints.tablet,
    desktop: breakpoints.desktop,
  });

  if (queries.mobile && values.mobile !== undefined) {
    return values.mobile;
  }
  if (queries.tablet && values.tablet !== undefined) {
    return values.tablet;
  }
  if (queries.desktop && values.desktop !== undefined) {
    return values.desktop;
  }

  return values.default;
};

/**
 * Hook to handle device type detection
 * @returns {Object} - Object with device type information
 */
export const useDeviceType = () => {
  const isMobile = useMediaQuery(breakpoints.mobile);
  const isTablet = useMediaQuery(breakpoints.tablet);
  const isDesktop = useMediaQuery(breakpoints.desktop);
  const isPortrait = useMediaQuery(breakpoints.portrait);
  const isRetina = useMediaQuery(breakpoints.retina);

  return {
    isMobile,
    isTablet,
    isDesktop,
    isPortrait,
    isLandscape: !isPortrait,
    isRetina,
    deviceType: isMobile ? 'mobile' : isTablet ? 'tablet' : 'desktop',
  };
};

/**
 * Hook to handle color scheme preference
 * @returns {Object} - Object with color scheme information
 */
export const useColorScheme = () => {
  const prefersDark = useMediaQuery(breakpoints.dark);
  const prefersLight = useMediaQuery(breakpoints.light);

  return {
    prefersDark,
    prefersLight,
    colorScheme: prefersDark ? 'dark' : 'light',
  };
};

/**
 * Hook to handle reduced motion preference
 * @returns {boolean} - Whether reduced motion is preferred
 */
export const useReducedMotion = () => {
  return useMediaQuery(breakpoints.reducedMotion);
};

/**
 * Hook to handle window resize events with debouncing
 * @param {number} delay - Debounce delay in milliseconds
 * @returns {Object} - Object with window dimensions
 */
export const useWindowSize = (delay = 250) => {
  const [windowSize, setWindowSize] = useState({
    width: typeof window !== 'undefined' ? window.innerWidth : 0,
    height: typeof window !== 'undefined' ? window.innerHeight : 0,
  });

  useEffect(() => {
    if (typeof window === 'undefined') {
      return undefined;
    }

    let timeoutId = null;

    const handleResize = () => {
      clearTimeout(timeoutId);

      timeoutId = setTimeout(() => {
        setWindowSize({
          width: window.innerWidth,
          height: window.innerHeight,
        });
      }, delay);
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('resize', handleResize);
    };
  }, [delay]);

  return windowSize;
};

export default useMediaQuery;
