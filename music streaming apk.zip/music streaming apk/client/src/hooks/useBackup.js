import { useState, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { useAuth } from '../contexts/AuthContext';
import { useAnalytics } from './useAnalytics';
import { showSnackbar } from '../store/slices/uiSlice';
import api from '../utils/api';

/**
 * Backup types configuration
 */
const BackupTypes = {
  PLAYLISTS: 'playlists',
  FAVORITES: 'favorites',
  SETTINGS: 'settings',
  HISTORY: 'history',
  QUEUE: 'queue',
  ALL: 'all',
};

/**
 * Backup formats
 */
const BackupFormats = {
  JSON: 'json',
  CSV: 'csv',
  XML: 'xml',
};

/**
 * Hook for handling data backups
 * @param {Object} options - Backup options
 * @returns {Object} - Backup state and functions
 */
const useBackup = (options = {}) => {
  const dispatch = useDispatch();
  const { user } = useAuth();
  const analytics = useAnalytics();

  const {
    autoBackup = false,
    backupInterval = 7 * 24 * 60 * 60 * 1000, // 7 days
    maxBackups = 5,
    format = BackupFormats.JSON,
    compression = true,
    encryption = true,
    types = Object.values(BackupTypes),
  } = options;

  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState(null);

  // Create backup
  const createBackup = useCallback(async (selectedTypes = types) => {
    if (!user) return null;

    try {
      setLoading(true);
      setError(null);
      setProgress(0);

      // Collect data for backup
      const backupData = {};
      let completed = 0;

      for (const type of selectedTypes) {
        try {
          // Get data based on type
          let data;
          switch (type) {
            case BackupTypes.PLAYLISTS:
              data = await api.get('/playlists/me');
              break;
            case BackupTypes.FAVORITES:
              data = await api.get('/favorites');
              break;
            case BackupTypes.SETTINGS:
              data = await api.get('/settings');
              break;
            case BackupTypes.HISTORY:
              data = await api.get('/history');
              break;
            case BackupTypes.QUEUE:
              data = await api.get('/queue');
              break;
            default:
              continue;
          }

          backupData[type] = data.data;
          completed++;
          setProgress((completed / selectedTypes.length) * 100);
        } catch (error) {
          console.error(`Error backing up ${type}:`, error);
        }
      }

      // Format backup data
      let formattedData;
      switch (format) {
        case BackupFormats.CSV:
          formattedData = formatAsCSV(backupData);
          break;
        case BackupFormats.XML:
          formattedData = formatAsXML(backupData);
          break;
        default:
          formattedData = JSON.stringify(backupData, null, 2);
      }

      // Compress if enabled
      if (compression) {
        formattedData = await compressData(formattedData);
      }

      // Encrypt if enabled
      if (encryption) {
        formattedData = await encryptData(formattedData);
      }

      // Create backup on server
      const response = await api.post('/backups', {
        data: formattedData,
        format,
        compressed: compression,
        encrypted: encryption,
        types: selectedTypes,
        timestamp: Date.now(),
      });

      // Track analytics
      analytics.trackEvent('backup_created', {
        types: selectedTypes,
        format,
        size: formattedData.length,
      });

      return response.data;
    } catch (error) {
      console.error('Backup error:', error);
      setError(error.message);
      dispatch(showSnackbar({
        message: 'Error creating backup',
        severity: 'error',
      }));
      return null;
    } finally {
      setLoading(false);
    }
  }, [
    user,
    types,
    format,
    compression,
    encryption,
    analytics,
    dispatch,
  ]);

  // Restore from backup
  const restoreBackup = useCallback(async (backupId, selectedTypes = types) => {
    if (!user) return false;

    try {
      setLoading(true);
      setError(null);
      setProgress(0);

      // Get backup data
      const response = await api.get(`/backups/${backupId}`);
      let backupData = response.data.data;

      // Decrypt if encrypted
      if (response.data.encrypted) {
        backupData = await decryptData(backupData);
      }

      // Decompress if compressed
      if (response.data.compressed) {
        backupData = await decompressData(backupData);
      }

      // Parse data based on format
      let parsedData;
      switch (response.data.format) {
        case BackupFormats.CSV:
          parsedData = parseCSV(backupData);
          break;
        case BackupFormats.XML:
          parsedData = parseXML(backupData);
          break;
        default:
          parsedData = JSON.parse(backupData);
      }

      // Restore each selected type
      let completed = 0;
      for (const type of selectedTypes) {
        if (parsedData[type]) {
          try {
            await api.post(`/restore/${type}`, {
              data: parsedData[type],
            });
            completed++;
            setProgress((completed / selectedTypes.length) * 100);
          } catch (error) {
            console.error(`Error restoring ${type}:`, error);
          }
        }
      }

      // Track analytics
      analytics.trackEvent('backup_restored', {
        backupId,
        types: selectedTypes,
      });

      dispatch(showSnackbar({
        message: 'Backup restored successfully',
        severity: 'success',
      }));

      return true;
    } catch (error) {
      console.error('Restore error:', error);
      setError(error.message);
      dispatch(showSnackbar({
        message: 'Error restoring backup',
        severity: 'error',
      }));
      return false;
    } finally {
      setLoading(false);
    }
  }, [user, types, analytics, dispatch]);

  // Get backup list
  const getBackups = useCallback(async () => {
    if (!user) return [];

    try {
      const response = await api.get('/backups');
      return response.data;
    } catch (error) {
      console.error('Get backups error:', error);
      return [];
    }
  }, [user]);

  // Delete backup
  const deleteBackup = useCallback(async (backupId) => {
    try {
      await api.delete(`/backups/${backupId}`);
      analytics.trackEvent('backup_deleted', { backupId });
      return true;
    } catch (error) {
      console.error('Delete backup error:', error);
      return false;
    }
  }, [analytics]);

  // Helper functions for data formatting
  const formatAsCSV = (data) => {
    // Implementation for CSV formatting
    return '';
  };

  const formatAsXML = (data) => {
    // Implementation for XML formatting
    return '';
  };

  const parseCSV = (data) => {
    // Implementation for CSV parsing
    return {};
  };

  const parseXML = (data) => {
    // Implementation for XML parsing
    return {};
  };

  // Helper functions for compression
  const compressData = async (data) => {
    // Implementation for data compression
    return data;
  };

  const decompressData = async (data) => {
    // Implementation for data decompression
    return data;
  };

  // Helper functions for encryption
  const encryptData = async (data) => {
    // Implementation for data encryption
    return data;
  };

  const decryptData = async (data) => {
    // Implementation for data decryption
    return data;
  };

  return {
    loading,
    progress,
    error,
    createBackup,
    restoreBackup,
    getBackups,
    deleteBackup,
    BackupTypes,
    BackupFormats,
  };
};

/**
 * Hook for handling playlist backups
 */
export const usePlaylistBackup = (options = {}) => {
  const backup = useBackup({
    types: [BackupTypes.PLAYLISTS],
    ...options,
  });

  const backupPlaylists = useCallback(() => {
    return backup.createBackup([BackupTypes.PLAYLISTS]);
  }, [backup]);

  return {
    ...backup,
    backupPlaylists,
  };
};

export default useBackup;
