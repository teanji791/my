import { useState, useCallback, useEffect } from 'react';
import { usePlayer } from '../contexts/PlayerContext';
import { useLocalStorage } from './useLocalStorage';
import { useAnalytics } from './useAnalytics';

/**
 * Default playback rates configuration
 */
const DEFAULT_RATES = [
  { label: '0.25x', value: 0.25 },
  { label: '0.5x', value: 0.5 },
  { label: '0.75x', value: 0.75 },
  { label: 'Normal', value: 1 },
  { label: '1.25x', value: 1.25 },
  { label: '1.5x', value: 1.5 },
  { label: '1.75x', value: 1.75 },
  { label: '2x', value: 2 },
];

/**
 * Hook for handling playback rate
 * @param {Object} options - Playback rate options
 * @returns {Object} - Playback rate state and functions
 */
const usePlaybackRate = (options = {}) => {
  const { audioRef } = usePlayer();
  const analytics = useAnalytics();
  
  const {
    defaultRate = 1,
    minRate = 0.25,
    maxRate = 2,
    step = 0.25,
    preservesPitch = true,
    rememberLastRate = true,
    availableRates = DEFAULT_RATES,
  } = options;

  // Initialize state
  const [storedRate, setStoredRate] = useLocalStorage('playback_rate', defaultRate);
  const [rate, setRate] = useState(rememberLastRate ? storedRate : defaultRate);
  const [preservingPitch, setPreservingPitch] = useState(preservesPitch);

  // Update audio element playback rate
  const updatePlaybackRate = useCallback((newRate) => {
    if (!audioRef.current) return false;

    try {
      // Ensure rate is within bounds
      const clampedRate = Math.max(minRate, Math.min(maxRate, newRate));
      
      // Round to nearest step
      const roundedRate = Math.round(clampedRate / step) * step;
      
      // Update audio element
      audioRef.current.playbackRate = roundedRate;
      audioRef.current.preservesPitch = preservingPitch;
      
      // Update state
      setRate(roundedRate);
      if (rememberLastRate) {
        setStoredRate(roundedRate);
      }

      // Track analytics
      analytics.trackEvent('playback_rate_change', {
        previousRate: rate,
        newRate: roundedRate,
        preservingPitch,
      });

      return true;
    } catch (error) {
      console.error('Error updating playback rate:', error);
      return false;
    }
  }, [
    audioRef,
    minRate,
    maxRate,
    step,
    preservingPitch,
    rememberLastRate,
    rate,
    setStoredRate,
    analytics,
  ]);

  // Increase playback rate
  const increaseRate = useCallback(() => {
    const newRate = rate + step;
    return updatePlaybackRate(newRate);
  }, [rate, step, updatePlaybackRate]);

  // Decrease playback rate
  const decreaseRate = useCallback(() => {
    const newRate = rate - step;
    return updatePlaybackRate(newRate);
  }, [rate, step, updatePlaybackRate]);

  // Reset to default rate
  const resetRate = useCallback(() => {
    return updatePlaybackRate(defaultRate);
  }, [defaultRate, updatePlaybackRate]);

  // Toggle pitch preservation
  const togglePreservePitch = useCallback(() => {
    if (!audioRef.current) return false;

    try {
      const newValue = !preservingPitch;
      audioRef.current.preservesPitch = newValue;
      setPreservingPitch(newValue);

      analytics.trackEvent('preserve_pitch_toggle', {
        enabled: newValue,
      });

      return true;
    } catch (error) {
      console.error('Error toggling preserve pitch:', error);
      return false;
    }
  }, [audioRef, preservingPitch, analytics]);

  // Get available rates
  const getAvailableRates = useCallback(() => {
    return availableRates.filter(
      rateOption => rateOption.value >= minRate && rateOption.value <= maxRate
    );
  }, [availableRates, minRate, maxRate]);

  // Get nearest available rate
  const getNearestRate = useCallback((targetRate) => {
    const rates = getAvailableRates();
    return rates.reduce((prev, curr) => {
      return Math.abs(curr.value - targetRate) < Math.abs(prev.value - targetRate)
        ? curr
        : prev;
    });
  }, [getAvailableRates]);

  // Format rate for display
  const formatRate = useCallback((value) => {
    const rate = getNearestRate(value);
    return rate.label;
  }, [getNearestRate]);

  // Initialize playback rate when audio element changes
  useEffect(() => {
    if (audioRef.current) {
      updatePlaybackRate(rate);
    }
  }, [audioRef, rate, updatePlaybackRate]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (event) => {
      // Only handle if target is body (not input elements)
      if (event.target.tagName === 'BODY') {
        switch (event.key) {
          case '[':
            decreaseRate();
            break;
          case ']':
            increaseRate();
            break;
          case '\\':
            resetRate();
            break;
          default:
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [decreaseRate, increaseRate, resetRate]);

  return {
    rate,
    preservingPitch,
    updatePlaybackRate,
    increaseRate,
    decreaseRate,
    resetRate,
    togglePreservePitch,
    getAvailableRates,
    getNearestRate,
    formatRate,
    minRate,
    maxRate,
    step,
  };
};

/**
 * Hook for handling variable playback rate
 */
export const useVariablePlaybackRate = (options = {}) => {
  const playbackRate = usePlaybackRate({
    minRate: 0.1,
    maxRate: 4,
    step: 0.1,
    ...options,
  });

  // Additional methods for fine-grained control
  const setExactRate = useCallback((rate) => {
    return playbackRate.updatePlaybackRate(rate);
  }, [playbackRate]);

  const adjustRate = useCallback((adjustment) => {
    const newRate = playbackRate.rate + adjustment;
    return playbackRate.updatePlaybackRate(newRate);
  }, [playbackRate]);

  return {
    ...playbackRate,
    setExactRate,
    adjustRate,
  };
};

export default usePlaybackRate;
