import { useState, useCallback, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useCache } from './useCache';
import { useAnalytics } from './useAnalytics';
import api from '../utils/api';

/**
 * Recommendation types
 */
const RecommendationTypes = {
  SIMILAR_TRACKS: 'similar_tracks',
  BASED_ON_HISTORY: 'based_on_history',
  GENRE_BASED: 'genre_based',
  MOOD_BASED: 'mood_based',
  TRENDING: 'trending',
  NEW_RELEASES: 'new_releases',
  PERSONALIZED: 'personalized',
  COLLABORATIVE: 'collaborative',
};

/**
 * Hook for handling music recommendations
 * @param {Object} options - Recommendations options
 * @returns {Object} - Recommendations state and functions
 */
const useRecommendations = (options = {}) => {
  const user = useSelector(state => state.auth.user);
  const cache = useCache({
    persistKey: 'recommendations_cache',
    ttl: 6 * 60 * 60 * 1000, // 6 hours
  });
  const analytics = useAnalytics();

  const {
    type = RecommendationTypes.PERSONALIZED,
    limit = 20,
    cacheRecommendations = true,
    refreshInterval = 24 * 60 * 60 * 1000, // 24 hours
    includeMetadata = true,
    filterExplicit = false,
    diversity = 0.5, // 0-1, higher means more diverse recommendations
  } = options;

  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  // Get recommendations based on type
  const getRecommendations = useCallback(async (params = {}) => {
    try {
      setLoading(true);
      setError(null);

      // Check cache first
      if (cacheRecommendations) {
        const cacheKey = `${type}_${JSON.stringify(params)}`;
        const cachedRecommendations = cache.get(cacheKey);
        if (cachedRecommendations) {
          setRecommendations(cachedRecommendations);
          return cachedRecommendations;
        }
      }

      // Prepare request parameters
      const requestParams = {
        type,
        limit,
        include_metadata: includeMetadata,
        filter_explicit: filterExplicit,
        diversity,
        ...params,
      };

      // Get recommendations from API
      const response = await api.get('/recommendations', { params: requestParams });
      const newRecommendations = response.data.data;

      // Cache recommendations
      if (cacheRecommendations) {
        const cacheKey = `${type}_${JSON.stringify(params)}`;
        cache.set(cacheKey, newRecommendations);
      }

      setRecommendations(newRecommendations);
      setLastUpdated(Date.now());

      // Track analytics
      analytics.trackEvent('recommendations_fetched', {
        type,
        count: newRecommendations.length,
        params,
      });

      return newRecommendations;
    } catch (error) {
      console.error('Recommendations error:', error);
      setError(error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  }, [
    type,
    limit,
    includeMetadata,
    filterExplicit,
    diversity,
    cacheRecommendations,
    cache,
    analytics,
  ]);

  // Get similar tracks
  const getSimilarTracks = useCallback(async (trackId) => {
    return getRecommendations({
      seed_tracks: [trackId],
      type: RecommendationTypes.SIMILAR_TRACKS,
    });
  }, [getRecommendations]);

  // Get recommendations based on listening history
  const getHistoryBasedRecommendations = useCallback(async () => {
    return getRecommendations({
      type: RecommendationTypes.BASED_ON_HISTORY,
    });
  }, [getRecommendations]);

  // Get genre-based recommendations
  const getGenreRecommendations = useCallback(async (genres) => {
    return getRecommendations({
      seed_genres: genres,
      type: RecommendationTypes.GENRE_BASED,
    });
  }, [getRecommendations]);

  // Get mood-based recommendations
  const getMoodRecommendations = useCallback(async (mood) => {
    return getRecommendations({
      mood,
      type: RecommendationTypes.MOOD_BASED,
    });
  }, [getRecommendations]);

  // Get trending tracks
  const getTrendingTracks = useCallback(async () => {
    return getRecommendations({
      type: RecommendationTypes.TRENDING,
    });
  }, [getRecommendations]);

  // Get new releases
  const getNewReleases = useCallback(async () => {
    return getRecommendations({
      type: RecommendationTypes.NEW_RELEASES,
    });
  }, [getRecommendations]);

  // Get personalized recommendations
  const getPersonalizedRecommendations = useCallback(async () => {
    if (!user) return [];

    return getRecommendations({
      type: RecommendationTypes.PERSONALIZED,
      user_id: user.id,
    });
  }, [user, getRecommendations]);

  // Get collaborative recommendations
  const getCollaborativeRecommendations = useCallback(async () => {
    if (!user) return [];

    return getRecommendations({
      type: RecommendationTypes.COLLABORATIVE,
      user_id: user.id,
    });
  }, [user, getRecommendations]);

  // Rate recommendation
  const rateRecommendation = useCallback(async (trackId, rating) => {
    try {
      await api.post('/recommendations/feedback', {
        track_id: trackId,
        rating,
      });

      analytics.trackEvent('recommendation_rated', {
        trackId,
        rating,
      });

      return true;
    } catch (error) {
      console.error('Rating error:', error);
      return false;
    }
  }, [analytics]);

  // Refresh recommendations periodically
  useEffect(() => {
    if (!refreshInterval) return;

    const shouldRefresh = !lastUpdated || 
      (Date.now() - lastUpdated) >= refreshInterval;

    if (shouldRefresh) {
      getRecommendations();
    }

    const interval = setInterval(() => {
      getRecommendations();
    }, refreshInterval);

    return () => clearInterval(interval);
  }, [refreshInterval, lastUpdated, getRecommendations]);

  // Filter recommendations
  const filterRecommendations = useCallback((filters) => {
    return recommendations.filter(track => {
      if (filters.genre && track.genre !== filters.genre) return false;
      if (filters.year && track.year !== filters.year) return false;
      if (filters.explicit === false && track.explicit) return false;
      if (filters.minDuration && track.duration < filters.minDuration) return false;
      if (filters.maxDuration && track.duration > filters.maxDuration) return false;
      return true;
    });
  }, [recommendations]);

  // Sort recommendations
  const sortRecommendations = useCallback((sortBy = 'relevance') => {
    return [...recommendations].sort((a, b) => {
      switch (sortBy) {
        case 'popularity':
          return b.popularity - a.popularity;
        case 'release_date':
          return new Date(b.releaseDate) - new Date(a.releaseDate);
        case 'duration':
          return a.duration - b.duration;
        default:
          return b.score - a.score;
      }
    });
  }, [recommendations]);

  return {
    recommendations,
    loading,
    error,
    lastUpdated,
    getRecommendations,
    getSimilarTracks,
    getHistoryBasedRecommendations,
    getGenreRecommendations,
    getMoodRecommendations,
    getTrendingTracks,
    getNewReleases,
    getPersonalizedRecommendations,
    getCollaborativeRecommendations,
    rateRecommendation,
    filterRecommendations,
    sortRecommendations,
    RecommendationTypes,
  };
};

/**
 * Hook for handling discovery features
 */
export const useDiscovery = (options = {}) => {
  const recommendations = useRecommendations({
    type: RecommendationTypes.PERSONALIZED,
    diversity: 0.7,
    ...options,
  });

  // Get weekly discovery playlist
  const getWeeklyDiscovery = useCallback(async () => {
    return recommendations.getRecommendations({
      type: 'weekly_discovery',
      limit: 30,
    });
  }, [recommendations]);

  // Get daily mix
  const getDailyMix = useCallback(async (mixNumber = 1) => {
    return recommendations.getRecommendations({
      type: 'daily_mix',
      mix_number: mixNumber,
      limit: 50,
    });
  }, [recommendations]);

  return {
    ...recommendations,
    getWeeklyDiscovery,
    getDailyMix,
  };
};

export default useRecommendations;
