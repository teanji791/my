import { useState, useEffect, useCallback, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { showErrorSnackbar } from '../store/slices/uiSlice';

const useInfiniteScroll = ({
  fetchData,
  initialData = [],
  pageSize = 20,
  threshold = 200,
  dependencies = [],
}) => {
  const dispatch = useDispatch();
  const [data, setData] = useState(initialData);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(1);
  const observer = useRef(null);
  const lastElementRef = useRef(null);

  // Reset state when dependencies change
  useEffect(() => {
    setData(initialData);
    setPage(1);
    setHasMore(true);
    setError(null);
  }, dependencies);

  // Fetch data function
  const loadMore = useCallback(async () => {
    if (loading || !hasMore) return;

    try {
      setLoading(true);
      setError(null);

      const response = await fetchData({
        page,
        limit: pageSize,
      });

      // Handle response data
      if (response.data) {
        if (page === 1) {
          setData(response.data);
        } else {
          setData((prevData) => [...prevData, ...response.data]);
        }

        // Check if there's more data to load
        setHasMore(
          response.data.length === pageSize && 
          (!response.pagination || page < response.pagination.totalPages)
        );

        // Increment page number
        setPage((prevPage) => prevPage + 1);
      } else {
        setHasMore(false);
      }
    } catch (error) {
      setError(error.message || 'Error loading data');
      dispatch(showErrorSnackbar('Error loading more items'));
    } finally {
      setLoading(false);
    }
  }, [fetchData, page, pageSize, loading, hasMore, dispatch]);

  // Set up intersection observer
  useEffect(() => {
    if (!hasMore || loading) return;

    const options = {
      root: null,
      rootMargin: `${threshold}px`,
      threshold: 0.1,
    };

    const handleObserver = (entries) => {
      const [target] = entries;
      if (target.isIntersecting && hasMore && !loading) {
        loadMore();
      }
    };

    observer.current = new IntersectionObserver(handleObserver, options);

    if (lastElementRef.current) {
      observer.current.observe(lastElementRef.current);
    }

    return () => {
      if (observer.current) {
        observer.current.disconnect();
      }
    };
  }, [hasMore, loading, loadMore, threshold]);

  // Refresh data
  const refresh = useCallback(async () => {
    setPage(1);
    setHasMore(true);
    setError(null);
    
    try {
      setLoading(true);
      const response = await fetchData({
        page: 1,
        limit: pageSize,
      });

      setData(response.data);
      setHasMore(
        response.data.length === pageSize && 
        (!response.pagination || 1 < response.pagination.totalPages)
      );
      setPage(2);
    } catch (error) {
      setError(error.message || 'Error refreshing data');
      dispatch(showErrorSnackbar('Error refreshing data'));
    } finally {
      setLoading(false);
    }
  }, [fetchData, pageSize, dispatch]);

  // Update data locally
  const updateItem = useCallback((id, updatedData) => {
    setData((prevData) =>
      prevData.map((item) =>
        item.id === id ? { ...item, ...updatedData } : item
      )
    );
  }, []);

  // Remove item locally
  const removeItem = useCallback((id) => {
    setData((prevData) => prevData.filter((item) => item.id !== id));
  }, []);

  // Add item locally
  const addItem = useCallback((newItem) => {
    setData((prevData) => [newItem, ...prevData]);
  }, []);

  // Get last element ref callback
  const getLastElementRef = useCallback(
    (node) => {
      if (loading) return;

      if (lastElementRef.current) {
        observer.current?.unobserve(lastElementRef.current);
      }

      lastElementRef.current = node;

      if (node && hasMore) {
        observer.current?.observe(node);
      }
    },
    [loading, hasMore]
  );

  return {
    data,
    loading,
    error,
    hasMore,
    refresh,
    updateItem,
    removeItem,
    addItem,
    getLastElementRef,
  };
};

// Helper component for rendering the last element
export const LastElementRef = ({ callback, style = {}, className = '' }) => (
  <div
    ref={callback}
    style={{
      height: '20px',
      margin: '10px 0',
      ...style,
    }}
    className={className}
  />
);

// Example usage with virtualization for better performance
export const useVirtualizedInfiniteScroll = ({
  fetchData,
  initialData = [],
  pageSize = 20,
  itemHeight = 50,
  overscan = 5,
  ...rest
}) => {
  const [virtualizedData, setVirtualizedData] = useState([]);
  const containerRef = useRef(null);
  const scrollPositionRef = useRef(0);

  const {
    data,
    loading,
    error,
    hasMore,
    refresh,
    updateItem,
    removeItem,
    addItem,
    getLastElementRef,
  } = useInfiniteScroll({
    fetchData,
    initialData,
    pageSize,
    ...rest,
  });

  // Calculate visible items based on scroll position
  useEffect(() => {
    if (!containerRef.current) return;

    const calculateVisibleItems = () => {
      const container = containerRef.current;
      const scrollTop = container.scrollTop;
      scrollPositionRef.current = scrollTop;

      const containerHeight = container.clientHeight;
      const startIndex = Math.max(
        0,
        Math.floor(scrollTop / itemHeight) - overscan
      );
      const endIndex = Math.min(
        data.length,
        Math.ceil((scrollTop + containerHeight) / itemHeight) + overscan
      );

      setVirtualizedData(
        data.slice(startIndex, endIndex).map((item, index) => ({
          ...item,
          virtualIndex: startIndex + index,
        }))
      );
    };

    const handleScroll = () => {
      requestAnimationFrame(calculateVisibleItems);
    };

    calculateVisibleItems();
    containerRef.current.addEventListener('scroll', handleScroll);

    return () => {
      containerRef.current?.removeEventListener('scroll', handleScroll);
    };
  }, [data, itemHeight, overscan]);

  return {
    containerRef,
    virtualizedData,
    totalHeight: data.length * itemHeight,
    itemHeight,
    loading,
    error,
    hasMore,
    refresh,
    updateItem,
    removeItem,
    addItem,
    getLastElementRef,
  };
};

export default useInfiniteScroll;
