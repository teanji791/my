import { useState, useEffect, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { showSnackbar } from '../store/slices/uiSlice';
import { useSocket } from '../contexts/SocketContext';

/**
 * Hook for handling notifications
 * @param {Object} options - Notification options
 * @returns {Object} - Notification state and functions
 */
const useNotification = (options = {}) => {
  const dispatch = useDispatch();
  const socket = useSocket();
  const [permission, setPermission] = useState('default');
  const [notifications, setNotifications] = useState([]);
  const [supported, setSupported] = useState(false);

  const {
    requestPermissionOnMount = false,
    showNotificationInApp = true,
    notificationDuration = 5000,
    playSound = true,
    soundUrl = '/notification.mp3',
    icon = '/logo192.png',
    badge = '/badge.png',
  } = options;

  // Check if notifications are supported
  useEffect(() => {
    setSupported('Notification' in window);
  }, []);

  // Request permission on mount if enabled
  useEffect(() => {
    if (supported && requestPermissionOnMount) {
      requestPermission();
    }
  }, [supported, requestPermissionOnMount]);

  // Update permission state when it changes
  useEffect(() => {
    if (supported) {
      setPermission(Notification.permission);
    }
  }, [supported]);

  // Request notification permission
  const requestPermission = useCallback(async () => {
    if (!supported) {
      throw new Error('Notifications not supported');
    }

    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      return result;
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      throw error;
    }
  }, [supported]);

  // Play notification sound
  const playNotificationSound = useCallback(() => {
    if (!playSound) return;

    try {
      const audio = new Audio(soundUrl);
      audio.play().catch(error => {
        console.error('Error playing notification sound:', error);
      });
    } catch (error) {
      console.error('Error creating audio element:', error);
    }
  }, [playSound, soundUrl]);

  // Show system notification
  const showSystemNotification = useCallback(
    async ({ title, body, data = {}, actions = [] }) => {
      if (!supported) {
        throw new Error('Notifications not supported');
      }

      if (permission !== 'granted') {
        const newPermission = await requestPermission();
        if (newPermission !== 'granted') {
          throw new Error('Notification permission denied');
        }
      }

      try {
        const notification = new Notification(title, {
          body,
          icon,
          badge,
          data,
          actions,
          requireInteraction: data.requireInteraction || false,
          silent: !playSound,
        });

        // Handle notification click
        notification.onclick = (event) => {
          event.preventDefault();
          if (data.url) {
            window.open(data.url, '_blank');
          }
          notification.close();
        };

        // Handle notification close
        notification.onclose = () => {
          setNotifications((prev) =>
            prev.filter((n) => n.timestamp !== data.timestamp)
          );
        };

        // Add to notifications list
        setNotifications((prev) => [
          { title, body, timestamp: Date.now(), ...data },
          ...prev,
        ]);

        // Play sound
        playNotificationSound();

        return notification;
      } catch (error) {
        console.error('Error showing notification:', error);
        throw error;
      }
    },
    [supported, permission, requestPermission, icon, badge, playSound, playNotificationSound]
  );

  // Show in-app notification
  const showInAppNotification = useCallback(
    ({ message, severity = 'info', duration = notificationDuration }) => {
      dispatch(
        showSnackbar({
          message,
          severity,
          duration,
        })
      );
    },
    [dispatch, notificationDuration]
  );

  // Show notification (both system and in-app if enabled)
  const notify = useCallback(
    async (options) => {
      const {
        title,
        body,
        message = body,
        severity = 'info',
        data = {},
        actions = [],
        showInApp = showNotificationInApp,
      } = options;

      try {
        // Show system notification
        if (supported && permission === 'granted') {
          await showSystemNotification({ title, body, data, actions });
        }

        // Show in-app notification
        if (showInApp) {
          showInAppNotification({ message, severity });
        }
      } catch (error) {
        console.error('Error showing notification:', error);
        // Fallback to in-app notification
        if (showInApp) {
          showInAppNotification({ message, severity: 'error' });
        }
      }
    },
    [
      supported,
      permission,
      showNotificationInApp,
      showSystemNotification,
      showInAppNotification,
    ]
  );

  // Clear all notifications
  const clearNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  // Remove specific notification
  const removeNotification = useCallback((timestamp) => {
    setNotifications((prev) =>
      prev.filter((notification) => notification.timestamp !== timestamp)
    );
  }, []);

  // Handle real-time notifications
  useEffect(() => {
    if (!socket) return;

    socket.on('notification', async (data) => {
      await notify(data);
    });

    return () => {
      socket.off('notification');
    };
  }, [socket, notify]);

  return {
    supported,
    permission,
    notifications,
    requestPermission,
    notify,
    showSystemNotification,
    showInAppNotification,
    clearNotifications,
    removeNotification,
  };
};

/**
 * Hook for handling music-related notifications
 */
export const useMusicNotifications = (options = {}) => {
  const notification = useNotification({
    icon: '/music-icon.png',
    ...options,
  });

  const notifyNowPlaying = useCallback(
    ({ title, artist, album }) => {
      notification.notify({
        title: 'Now Playing',
        body: `${title} - ${artist}`,
        message: `Now playing: ${title} by ${artist}`,
        severity: 'info',
        data: {
          type: 'now_playing',
          title,
          artist,
          album,
        },
      });
    },
    [notification]
  );

  const notifyPlaylistUpdate = useCallback(
    ({ playlistName, action }) => {
      notification.notify({
        title: 'Playlist Updated',
        body: `${playlistName} was ${action}`,
        message: `Playlist ${playlistName} was ${action}`,
        severity: 'info',
        data: {
          type: 'playlist_update',
          playlistName,
          action,
        },
      });
    },
    [notification]
  );

  return {
    ...notification,
    notifyNowPlaying,
    notifyPlaylistUpdate,
  };
};

export default useNotification;
