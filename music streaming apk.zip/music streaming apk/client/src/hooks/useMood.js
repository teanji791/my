import { useState, useCallback, useEffect } from 'react';
import { useRecommendations } from './useRecommendations';
import { useAnalytics } from './useAnalytics';
import { useCache } from './useCache';
import api from '../utils/api';

/**
 * Mood categories configuration
 */
const MoodCategories = {
  HAPPY: 'happy',
  ENERGETIC: 'energetic',
  CALM: 'calm',
  MELANCHOLIC: 'melancholic',
  ROMANTIC: 'romantic',
  FOCUSED: 'focused',
  PARTY: 'party',
  CHILL: 'chill',
};

/**
 * Mood analysis parameters
 */
const MoodParameters = {
  VALENCE: 'valence', // Musical positiveness
  ENERGY: 'energy', // Intensity and activity
  DANCEABILITY: 'danceability',
  TEMPO: 'tempo',
  INSTRUMENTALNESS: 'instrumentalness',
  ACOUSTICNESS: 'acousticness',
};

/**
 * Hook for handling mood-based music features
 * @param {Object} options - Mood options
 * @returns {Object} - Mood state and functions
 */
const useMood = (options = {}) => {
  const recommendations = useRecommendations();
  const analytics = useAnalytics();
  const cache = useCache({
    persistKey: 'mood_cache',
    ttl: 12 * 60 * 60 * 1000, // 12 hours
  });

  const {
    defaultMood = MoodCategories.HAPPY,
    tracksPerMood = 20,
    cacheMoodPlaylists = true,
    analyzeMoodChanges = true,
    moodChangeThreshold = 0.3,
  } = options;

  const [currentMood, setCurrentMood] = useState(defaultMood);
  const [moodHistory, setMoodHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Get mood parameters for category
  const getMoodParameters = useCallback((mood) => {
    switch (mood) {
      case MoodCategories.HAPPY:
        return {
          [MoodParameters.VALENCE]: 0.8,
          [MoodParameters.ENERGY]: 0.7,
          [MoodParameters.DANCEABILITY]: 0.7,
        };
      case MoodCategories.ENERGETIC:
        return {
          [MoodParameters.ENERGY]: 0.9,
          [MoodParameters.TEMPO]: 130,
          [MoodParameters.DANCEABILITY]: 0.8,
        };
      case MoodCategories.CALM:
        return {
          [MoodParameters.VALENCE]: 0.5,
          [MoodParameters.ENERGY]: 0.3,
          [MoodParameters.INSTRUMENTALNESS]: 0.5,
        };
      case MoodCategories.MELANCHOLIC:
        return {
          [MoodParameters.VALENCE]: 0.2,
          [MoodParameters.ENERGY]: 0.4,
          [MoodParameters.ACOUSTICNESS]: 0.6,
        };
      case MoodCategories.ROMANTIC:
        return {
          [MoodParameters.VALENCE]: 0.6,
          [MoodParameters.ENERGY]: 0.4,
          [MoodParameters.ACOUSTICNESS]: 0.5,
        };
      case MoodCategories.FOCUSED:
        return {
          [MoodParameters.ENERGY]: 0.4,
          [MoodParameters.INSTRUMENTALNESS]: 0.7,
          [MoodParameters.VALENCE]: 0.5,
        };
      case MoodCategories.PARTY:
        return {
          [MoodParameters.ENERGY]: 0.9,
          [MoodParameters.DANCEABILITY]: 0.9,
          [MoodParameters.VALENCE]: 0.8,
        };
      case MoodCategories.CHILL:
        return {
          [MoodParameters.ENERGY]: 0.3,
          [MoodParameters.VALENCE]: 0.5,
          [MoodParameters.ACOUSTICNESS]: 0.7,
        };
      default:
        return {};
    }
  }, []);

  // Get tracks for mood
  const getMoodTracks = useCallback(async (mood = currentMood) => {
    try {
      setLoading(true);
      setError(null);

      // Check cache first
      if (cacheMoodPlaylists) {
        const cachedTracks = cache.get(`mood_${mood}`);
        if (cachedTracks) {
          return cachedTracks;
        }
      }

      const moodParams = getMoodParameters(mood);
      const tracks = await recommendations.getRecommendations({
        limit: tracksPerMood,
        ...moodParams,
      });

      // Cache tracks
      if (cacheMoodPlaylists) {
        cache.set(`mood_${mood}`, tracks);
      }

      // Track analytics
      analytics.trackEvent('mood_tracks_fetched', {
        mood,
        tracksCount: tracks.length,
        parameters: moodParams,
      });

      return tracks;
    } catch (error) {
      console.error('Mood tracks error:', error);
      setError(error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  }, [
    currentMood,
    tracksPerMood,
    cacheMoodPlaylists,
    cache,
    getMoodParameters,
    recommendations,
    analytics,
  ]);

  // Analyze track mood
  const analyzeTrackMood = useCallback(async (trackId) => {
    try {
      const response = await api.get(`/tracks/${trackId}/audio-features`);
      const features = response.data;

      // Calculate mood scores
      const moodScores = Object.values(MoodCategories).reduce((scores, mood) => {
        const parameters = getMoodParameters(mood);
        let score = 0;
        let weightSum = 0;

        Object.entries(parameters).forEach(([param, target]) => {
          const weight = 1; // Could be adjusted per parameter
          const actual = features[param];
          const difference = Math.abs(target - actual);
          score += (1 - difference) * weight;
          weightSum += weight;
        });

        scores[mood] = score / weightSum;
        return scores;
      }, {});

      // Get dominant mood
      const dominantMood = Object.entries(moodScores)
        .reduce((a, b) => a[1] > b[1] ? a : b)[0];

      return {
        dominantMood,
        scores: moodScores,
        features,
      };
    } catch (error) {
      console.error('Track analysis error:', error);
      throw error;
    }
  }, [getMoodParameters]);

  // Change current mood
  const changeMood = useCallback(async (newMood) => {
    try {
      const tracks = await getMoodTracks(newMood);
      setCurrentMood(newMood);
      
      // Update mood history
      setMoodHistory(prev => [
        { mood: newMood, timestamp: Date.now() },
        ...prev.slice(0, 9), // Keep last 10 moods
      ]);

      return tracks;
    } catch (error) {
      console.error('Mood change error:', error);
      throw error;
    }
  }, [getMoodTracks]);

  // Get mood suggestions
  const getMoodSuggestions = useCallback(async () => {
    try {
      const response = await api.get('/moods/suggestions', {
        params: {
          current_mood: currentMood,
          history: moodHistory,
        },
      });
      return response.data.suggestions;
    } catch (error) {
      console.error('Mood suggestions error:', error);
      throw error;
    }
  }, [currentMood, moodHistory]);

  // Create mood playlist
  const createMoodPlaylist = useCallback(async (mood = currentMood, name) => {
    try {
      const tracks = await getMoodTracks(mood);
      const response = await api.post('/playlists', {
        name: name || `${mood.charAt(0).toUpperCase() + mood.slice(1)} Mood`,
        tracks: tracks.map(track => track.id),
        mood,
      });

      analytics.trackEvent('mood_playlist_created', {
        mood,
        trackCount: tracks.length,
      });

      return response.data;
    } catch (error) {
      console.error('Create mood playlist error:', error);
      throw error;
    }
  }, [currentMood, getMoodTracks, analytics]);

  // Monitor mood changes
  useEffect(() => {
    if (!analyzeMoodChanges) return;

    const checkMoodChange = async (track) => {
      const analysis = await analyzeTrackMood(track.id);
      const moodDifference = Math.abs(
        getMoodParameters(currentMood)[MoodParameters.VALENCE] -
        analysis.features[MoodParameters.VALENCE]
      );

      if (moodDifference > moodChangeThreshold) {
        const suggestedMood = analysis.dominantMood;
        // Could trigger mood change suggestion here
        analytics.trackEvent('mood_change_detected', {
          fromMood: currentMood,
          toMood: suggestedMood,
          difference: moodDifference,
        });
      }
    };

    // Could subscribe to player events here to analyze each track
  }, [
    analyzeMoodChanges,
    currentMood,
    moodChangeThreshold,
    analyzeTrackMood,
    getMoodParameters,
    analytics,
  ]);

  return {
    currentMood,
    moodHistory,
    loading,
    error,
    getMoodTracks,
    analyzeTrackMood,
    changeMood,
    getMoodSuggestions,
    createMoodPlaylist,
    MoodCategories,
    MoodParameters,
  };
};

/**
 * Hook for handling time-based moods
 */
export const useTimeMood = (options = {}) => {
  const mood = useMood(options);

  // Get mood for time of day
  const getMoodForTime = useCallback((date = new Date()) => {
    const hour = date.getHours();
    
    if (hour >= 5 && hour < 9) return MoodCategories.ENERGETIC; // Morning
    if (hour >= 9 && hour < 12) return MoodCategories.FOCUSED; // Late morning
    if (hour >= 12 && hour < 15) return MoodCategories.HAPPY; // Afternoon
    if (hour >= 15 && hour < 19) return MoodCategories.CHILL; // Late afternoon
    if (hour >= 19 && hour < 23) return MoodCategories.ROMANTIC; // Evening
    return MoodCategories.CALM; // Night
  }, []);

  // Auto-update mood based on time
  useEffect(() => {
    const updateMood = () => {
      const suggestedMood = getMoodForTime();
      if (suggestedMood !== mood.currentMood) {
        mood.changeMood(suggestedMood);
      }
    };

    const interval = setInterval(updateMood, 60 * 60 * 1000); // Check every hour
    updateMood(); // Initial check

    return () => clearInterval(interval);
  }, [mood, getMoodForTime]);

  return {
    ...mood,
    getMoodForTime,
  };
};

export default useMood;
