import { useState, useCallback, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { showErrorSnackbar } from '../store/slices/uiSlice';

const useForm = (initialValues = {}, validationSchema = null, onSubmit = null) => {
  const dispatch = useDispatch();
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDirty, setIsDirty] = useState(false);

  // Reset form to initial values
  const resetForm = useCallback(() => {
    setValues(initialValues);
    setErrors({});
    setTouched({});
    setIsSubmitting(false);
    setIsDirty(false);
  }, [initialValues]);

  // Update form when initial values change
  useEffect(() => {
    setValues(initialValues);
  }, [initialValues]);

  // Validate a single field
  const validateField = useCallback(
    async (name, value) => {
      if (!validationSchema) return '';

      try {
        await validationSchema.validateAt(name, { [name]: value });
        return '';
      } catch (error) {
        return error.message;
      }
    },
    [validationSchema]
  );

  // Validate all fields
  const validateForm = useCallback(
    async (formValues = values) => {
      if (!validationSchema) return {};

      try {
        await validationSchema.validate(formValues, { abortEarly: false });
        return {};
      } catch (error) {
        const validationErrors = {};
        error.inner.forEach((err) => {
          validationErrors[err.path] = err.message;
        });
        return validationErrors;
      }
    },
    [validationSchema, values]
  );

  // Handle field change
  const handleChange = useCallback(
    async (event) => {
      const { name, value, type, checked } = event.target;
      const newValue = type === 'checkbox' ? checked : value;

      setValues((prev) => ({
        ...prev,
        [name]: newValue,
      }));

      setIsDirty(true);

      if (touched[name]) {
        const fieldError = await validateField(name, newValue);
        setErrors((prev) => ({
          ...prev,
          [name]: fieldError,
        }));
      }
    },
    [touched, validateField]
  );

  // Handle field blur
  const handleBlur = useCallback(
    async (event) => {
      const { name, value } = event.target;

      setTouched((prev) => ({
        ...prev,
        [name]: true,
      }));

      const fieldError = await validateField(name, value);
      setErrors((prev) => ({
        ...prev,
        [name]: fieldError,
      }));
    },
    [validateField]
  );

  // Set field value programmatically
  const setFieldValue = useCallback(
    async (name, value, shouldValidate = true) => {
      setValues((prev) => ({
        ...prev,
        [name]: value,
      }));

      setIsDirty(true);

      if (shouldValidate && touched[name]) {
        const fieldError = await validateField(name, value);
        setErrors((prev) => ({
          ...prev,
          [name]: fieldError,
        }));
      }
    },
    [touched, validateField]
  );

  // Set field touched state
  const setFieldTouched = useCallback((name, isTouched = true) => {
    setTouched((prev) => ({
      ...prev,
      [name]: isTouched,
    }));
  }, []);

  // Handle form submission
  const handleSubmit = useCallback(
    async (event) => {
      if (event) {
        event.preventDefault();
      }

      setIsSubmitting(true);
      const validationErrors = await validateForm();
      setErrors(validationErrors);

      // Check if there are any errors
      if (Object.keys(validationErrors).length === 0) {
        try {
          if (onSubmit) {
            await onSubmit(values);
          }
        } catch (error) {
          dispatch(showErrorSnackbar(error.message || 'Form submission failed'));
        }
      } else {
        // Show error for first invalid field
        const firstError = Object.values(validationErrors)[0];
        dispatch(showErrorSnackbar(firstError));
      }

      setIsSubmitting(false);
    },
    [values, validateForm, onSubmit, dispatch]
  );

  // Check if form is valid
  const isValid = useCallback(
    async () => {
      const validationErrors = await validateForm();
      return Object.keys(validationErrors).length === 0;
    },
    [validateForm]
  );

  // Get field props
  const getFieldProps = useCallback(
    (name) => ({
      name,
      value: values[name] || '',
      onChange: handleChange,
      onBlur: handleBlur,
      error: !!errors[name],
      helperText: errors[name],
    }),
    [values, errors, handleChange, handleBlur]
  );

  return {
    values,
    errors,
    touched,
    isSubmitting,
    isDirty,
    handleChange,
    handleBlur,
    handleSubmit,
    setFieldValue,
    setFieldTouched,
    resetForm,
    isValid,
    getFieldProps,
  };
};

// Helper function to create form field validation rules
export const createValidationRule = (type, options = {}) => {
  switch (type) {
    case 'required':
      return { required: true, message: options.message || 'This field is required' };
    case 'email':
      return {
        pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        message: options.message || 'Invalid email address',
      };
    case 'minLength':
      return {
        minLength: options.length,
        message: options.message || `Minimum ${options.length} characters required`,
      };
    case 'maxLength':
      return {
        maxLength: options.length,
        message: options.message || `Maximum ${options.length} characters allowed`,
      };
    case 'pattern':
      return {
        pattern: options.pattern,
        message: options.message || 'Invalid format',
      };
    case 'custom':
      return {
        validator: options.validator,
        message: options.message || 'Invalid value',
      };
    default:
      return {};
  }
};

export default useForm;
