import { useEffect, useCallback, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { usePlayer } from '../contexts/PlayerContext';
import { showSnackbar } from '../store/slices/uiSlice';

/**
 * Default keyboard shortcuts configuration
 */
const defaultShortcuts = {
  player: {
    togglePlay: ['Space'],
    nextTrack: ['MediaTrackNext', 'ArrowRight'],
    previousTrack: ['MediaTrackPrevious', 'ArrowLeft'],
    volumeUp: ['ArrowUp'],
    volumeDown: ['ArrowDown'],
    toggleMute: ['m', 'M'],
    toggleShuffle: ['s', 'S'],
    toggleRepeat: ['r', 'R'],
    like: ['l', 'L'],
  },
  playlist: {
    createPlaylist: ['Control+n', 'Meta+n'],
    deletePlaylist: ['Delete', 'Backspace'],
    renamePlaylist: ['F2'],
  },
  navigation: {
    search: ['Control+f', 'Meta+f'],
    home: ['Control+h', 'Meta+h'],
    library: ['Control+l', 'Meta+l'],
    profile: ['Control+p', 'Meta+p'],
  },
  general: {
    help: ['?'],
    toggleTheme: ['Control+t', 'Meta+t'],
  },
};

/**
 * Hook for handling keyboard shortcuts
 * @param {Object} options - Keyboard options
 * @returns {Object} - Keyboard state and functions
 */
const useKeyboard = (options = {}) => {
  const dispatch = useDispatch();
  const player = usePlayer();
  const {
    shortcuts = defaultShortcuts,
    enabled = true,
    showHints = true,
    ignoreInputs = true,
    ignoreModals = true,
  } = options;

  // Track pressed keys
  const pressedKeys = useRef(new Set());
  const lastKeyPressTime = useRef(0);
  const multiKeyTimeout = useRef(null);

  // Convert shortcut string to array of keys
  const parseShortcut = useCallback((shortcut) => {
    return shortcut.split('+').map((key) => key.trim().toLowerCase());
  }, []);

  // Check if event matches shortcut
  const matchesShortcut = useCallback((event, shortcut) => {
    const keys = parseShortcut(shortcut);
    const eventKey = event.key.toLowerCase();

    // Check modifiers
    const hasCtrl = keys.includes('control') === event.ctrlKey;
    const hasAlt = keys.includes('alt') === event.altKey;
    const hasShift = keys.includes('shift') === event.shiftKey;
    const hasMeta = keys.includes('meta') === event.metaKey;

    // Check main key
    const mainKey = keys.find(
      (key) => !['control', 'alt', 'shift', 'meta'].includes(key)
    );
    const hasMainKey = mainKey === eventKey;

    return hasCtrl && hasAlt && hasShift && hasMeta && hasMainKey;
  }, [parseShortcut]);

  // Handle key combinations
  const handleKeyCombination = useCallback(() => {
    const pressedKeysArray = Array.from(pressedKeys.current);
    const combination = pressedKeysArray.sort().join('+').toLowerCase();

    // Find matching shortcuts
    Object.entries(shortcuts).forEach(([category, categoryShortcuts]) => {
      Object.entries(categoryShortcuts).forEach(([action, actionShortcuts]) => {
        const matches = actionShortcuts.some((shortcut) =>
          combination === parseShortcut(shortcut).sort().join('+')
        );

        if (matches) {
          handleAction(category, action);
        }
      });
    });
  }, [shortcuts, parseShortcut]);

  // Handle keyboard actions
  const handleAction = useCallback((category, action) => {
    switch (category) {
      case 'player':
        switch (action) {
          case 'togglePlay':
            player.togglePlay();
            break;
          case 'nextTrack':
            player.next();
            break;
          case 'previousTrack':
            player.previous();
            break;
          case 'volumeUp':
            player.setVolume(Math.min(1, player.volume + 0.1));
            break;
          case 'volumeDown':
            player.setVolume(Math.max(0, player.volume - 0.1));
            break;
          case 'toggleMute':
            player.toggleMute();
            break;
          case 'toggleShuffle':
            player.toggleShuffle();
            break;
          case 'toggleRepeat':
            player.toggleRepeat();
            break;
          default:
            break;
        }
        break;

      case 'general':
        switch (action) {
          case 'help':
            showShortcutsHint();
            break;
          default:
            break;
        }
        break;

      default:
        break;
    }
  }, [player]);

  // Show keyboard shortcuts hint
  const showShortcutsHint = useCallback(() => {
    if (!showHints) return;

    const formatShortcuts = (shortcuts) => {
      return Object.entries(shortcuts).map(([category, categoryShortcuts]) => {
        const formattedShortcuts = Object.entries(categoryShortcuts)
          .map(([action, keys]) => `${action}: ${keys.join(' or ')}`)
          .join('\n');
        return `${category}:\n${formattedShortcuts}`;
      }).join('\n\n');
    };

    dispatch(
      showSnackbar({
        message: 'Keyboard shortcuts shown in console',
        severity: 'info',
      })
    );
    console.group('Keyboard Shortcuts');
    console.log(formatShortcuts(shortcuts));
    console.groupEnd();
  }, [shortcuts, showHints, dispatch]);

  // Handle keydown event
  const handleKeyDown = useCallback((event) => {
    if (!enabled) return;

    // Ignore if target is input or modal is open
    if (
      (ignoreInputs &&
        ['input', 'textarea', 'select'].includes(event.target.tagName.toLowerCase())) ||
      (ignoreModals && document.querySelector('.MuiDialog-root'))
    ) {
      return;
    }

    const key = event.key.toLowerCase();
    pressedKeys.current.add(key);

    // Handle single key shortcuts immediately
    if (pressedKeys.current.size === 1) {
      handleKeyCombination();
    }

    // Handle multi-key shortcuts with a small delay
    clearTimeout(multiKeyTimeout.current);
    multiKeyTimeout.current = setTimeout(() => {
      if (pressedKeys.current.size > 1) {
        handleKeyCombination();
      }
    }, 200);

    lastKeyPressTime.current = Date.now();
  }, [enabled, ignoreInputs, ignoreModals, handleKeyCombination]);

  // Handle keyup event
  const handleKeyUp = useCallback((event) => {
    const key = event.key.toLowerCase();
    pressedKeys.current.delete(key);

    // Clear timeout if all keys are released
    if (pressedKeys.current.size === 0) {
      clearTimeout(multiKeyTimeout.current);
    }
  }, []);

  // Add event listeners
  useEffect(() => {
    if (enabled) {
      window.addEventListener('keydown', handleKeyDown);
      window.addEventListener('keyup', handleKeyUp);

      return () => {
        window.removeEventListener('keydown', handleKeyDown);
        window.removeEventListener('keyup', handleKeyUp);
      };
    }
  }, [enabled, handleKeyDown, handleKeyUp]);

  // Clear pressed keys when window loses focus
  useEffect(() => {
    const handleBlur = () => {
      pressedKeys.current.clear();
      clearTimeout(multiKeyTimeout.current);
    };

    window.addEventListener('blur', handleBlur);
    return () => window.removeEventListener('blur', handleBlur);
  }, []);

  return {
    shortcuts,
    showShortcutsHint,
    enabled,
  };
};

export default useKeyboard;
