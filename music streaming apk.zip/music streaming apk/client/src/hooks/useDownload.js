import { useState, useCallback, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { usePermissions } from './usePermissions';
import { useAnalytics } from './useAnalytics';
import { showErrorSnackbar, showSuccessSnackbar } from '../store/slices/uiSlice';
import api from '../utils/api';

/**
 * Download status types
 */
const DownloadStatus = {
  IDLE: 'idle',
  QUEUED: 'queued',
  DOWNLOADING: 'downloading',
  COMPLETED: 'completed',
  ERROR: 'error',
  CANCELLED: 'cancelled',
};

/**
 * Download quality options
 */
const DownloadQuality = {
  LOW: { bitrate: 128, label: 'Low' },
  MEDIUM: { bitrate: 256, label: 'Medium' },
  HIGH: { bitrate: 320, label: 'High' },
  LOSSLESS: { bitrate: null, label: 'Lossless' },
};

/**
 * Hook for handling music downloads
 * @param {Object} options - Download options
 * @returns {Object} - Download state and functions
 */
const useDownload = (options = {}) => {
  const dispatch = useDispatch();
  const { hasPremiumAccess } = usePermissions();
  const analytics = useAnalytics();

  const {
    defaultQuality = DownloadQuality.HIGH,
    maxConcurrentDownloads = 3,
    maxStorageSize = 10 * 1024 * 1024 * 1024, // 10GB
    autoDownloadPlaylists = false,
    checkStorageQuota = true,
  } = options;

  const [downloads, setDownloads] = useState(new Map());
  const [downloadQueue, setDownloadQueue] = useState([]);
  const [activeDownloads, setActiveDownloads] = useState(0);
  const [totalStorage, setTotalStorage] = useState(0);

  // Check storage availability
  const checkStorage = useCallback(async (size) => {
    if (!checkStorageQuota) return true;

    try {
      if ('storage' in navigator && 'estimate' in navigator.storage) {
        const { quota, usage } = await navigator.storage.estimate();
        const available = quota - usage;
        return available >= size;
      }
      return true;
    } catch (error) {
      console.error('Storage check error:', error);
      return true;
    }
  }, [checkStorageQuota]);

  // Start download
  const startDownload = useCallback(async (track, quality = defaultQuality) => {
    try {
      // Check premium access for high quality
      if (quality.bitrate >= DownloadQuality.HIGH.bitrate && !hasPremiumAccess) {
        throw new Error('Premium subscription required for high quality downloads');
      }

      // Check if already downloaded or downloading
      if (downloads.has(track.id)) {
        const status = downloads.get(track.id).status;
        if (status === DownloadStatus.COMPLETED) {
          dispatch(showErrorSnackbar('Track already downloaded'));
          return false;
        }
        if (status === DownloadStatus.DOWNLOADING) {
          dispatch(showErrorSnackbar('Track already downloading'));
          return false;
        }
      }

      // Add to queue if max concurrent downloads reached
      if (activeDownloads >= maxConcurrentDownloads) {
        setDownloadQueue(prev => [...prev, { track, quality }]);
        setDownloads(prev => new Map(prev).set(track.id, {
          track,
          quality,
          progress: 0,
          status: DownloadStatus.QUEUED,
        }));
        return true;
      }

      // Start download
      setActiveDownloads(prev => prev + 1);
      setDownloads(prev => new Map(prev).set(track.id, {
        track,
        quality,
        progress: 0,
        status: DownloadStatus.DOWNLOADING,
      }));

      // Get download URL
      const response = await api.get(`/tracks/${track.id}/download`, {
        params: { quality: quality.bitrate },
      });

      // Check storage
      const size = response.headers['content-length'];
      if (!await checkStorage(size)) {
        throw new Error('Insufficient storage space');
      }

      // Download file
      const downloadResponse = await fetch(response.data.url);
      const blob = await downloadResponse.blob();

      // Save file
      const fileName = `${track.artist} - ${track.title}.${response.data.format}`;
      await saveFile(blob, fileName);

      // Update state
      setDownloads(prev => new Map(prev).set(track.id, {
        track,
        quality,
        progress: 100,
        status: DownloadStatus.COMPLETED,
        path: fileName,
      }));
      setTotalStorage(prev => prev + size);

      // Track analytics
      analytics.trackEvent('track_downloaded', {
        trackId: track.id,
        quality: quality.label,
        size,
      });

      dispatch(showSuccessSnackbar('Download completed'));
      return true;
    } catch (error) {
      console.error('Download error:', error);
      setDownloads(prev => new Map(prev).set(track.id, {
        track,
        quality,
        progress: 0,
        status: DownloadStatus.ERROR,
        error: error.message,
      }));
      dispatch(showErrorSnackbar(error.message || 'Download failed'));
      return false;
    } finally {
      setActiveDownloads(prev => prev - 1);
    }
  }, [
    downloads,
    activeDownloads,
    maxConcurrentDownloads,
    hasPremiumAccess,
    defaultQuality,
    checkStorage,
    analytics,
    dispatch,
  ]);

  // Cancel download
  const cancelDownload = useCallback((trackId) => {
    const download = downloads.get(trackId);
    if (!download) return false;

    if (download.status === DownloadStatus.QUEUED) {
      setDownloadQueue(prev => prev.filter(item => item.track.id !== trackId));
    }

    setDownloads(prev => new Map(prev).set(trackId, {
      ...download,
      status: DownloadStatus.CANCELLED,
    }));

    analytics.trackEvent('download_cancelled', {
      trackId,
      status: download.status,
    });

    return true;
  }, [downloads, analytics]);

  // Remove download
  const removeDownload = useCallback(async (trackId) => {
    const download = downloads.get(trackId);
    if (!download || download.status !== DownloadStatus.COMPLETED) return false;

    try {
      await deleteFile(download.path);
      setDownloads(prev => {
        const next = new Map(prev);
        next.delete(trackId);
        return next;
      });

      analytics.trackEvent('download_removed', { trackId });
      return true;
    } catch (error) {
      console.error('Remove download error:', error);
      dispatch(showErrorSnackbar('Error removing download'));
      return false;
    }
  }, [downloads, analytics, dispatch]);

  // Download playlist
  const downloadPlaylist = useCallback(async (playlist, quality = defaultQuality) => {
    try {
      const results = await Promise.all(
        playlist.tracks.map(track => startDownload(track, quality))
      );
      
      const successCount = results.filter(Boolean).length;
      dispatch(showSuccessSnackbar(
        `Downloaded ${successCount} of ${playlist.tracks.length} tracks`
      ));

      analytics.trackEvent('playlist_downloaded', {
        playlistId: playlist.id,
        trackCount: playlist.tracks.length,
        successCount,
        quality: quality.label,
      });

      return successCount === playlist.tracks.length;
    } catch (error) {
      console.error('Playlist download error:', error);
      dispatch(showErrorSnackbar('Error downloading playlist'));
      return false;
    }
  }, [startDownload, analytics, dispatch]);

  // Process download queue
  useEffect(() => {
    if (activeDownloads < maxConcurrentDownloads && downloadQueue.length > 0) {
      const next = downloadQueue[0];
      setDownloadQueue(prev => prev.slice(1));
      startDownload(next.track, next.quality);
    }
  }, [activeDownloads, downloadQueue, maxConcurrentDownloads, startDownload]);

  // Auto-download playlists
  useEffect(() => {
    if (!autoDownloadPlaylists) return;

    const handlePlaylistUpdate = async (playlist) => {
      const downloadedTracks = new Set(
        Array.from(downloads.entries())
          .filter(([, download]) => download.status === DownloadStatus.COMPLETED)
          .map(([trackId]) => trackId)
      );

      const newTracks = playlist.tracks.filter(
        track => !downloadedTracks.has(track.id)
      );

      if (newTracks.length > 0) {
        await Promise.all(
          newTracks.map(track => startDownload(track, defaultQuality))
        );
      }
    };

    // Subscribe to playlist updates
    // Implementation depends on your event system
  }, [
    autoDownloadPlaylists,
    downloads,
    startDownload,
    defaultQuality,
  ]);

  return {
    downloads,
    downloadQueue,
    activeDownloads,
    totalStorage,
    startDownload,
    cancelDownload,
    removeDownload,
    downloadPlaylist,
    DownloadStatus,
    DownloadQuality,
  };
};

// Helper functions for file operations
const saveFile = async (blob, fileName) => {
  // Implementation depends on your storage strategy
  // Could use IndexedDB, File System API, or other storage methods
};

const deleteFile = async (path) => {
  // Implementation depends on your storage strategy
};

export default useDownload;
