import { useState, useCallback, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { showSnackbar } from '../store/slices/uiSlice';
import { useAnalytics } from './useAnalytics';

/**
 * Error types configuration
 */
const ErrorTypes = {
  NETWORK: 'network',
  API: 'api',
  AUTH: 'auth',
  VALIDATION: 'validation',
  PLAYBACK: 'playback',
  UPLOAD: 'upload',
  UNKNOWN: 'unknown',
};

/**
 * Error severity levels
 */
const ErrorSeverity = {
  INFO: 'info',
  WARNING: 'warning',
  ERROR: 'error',
  CRITICAL: 'critical',
};

/**
 * Hook for handling errors
 * @param {Object} options - Error handling options
 * @returns {Object} - Error handling functions and state
 */
const useError = (options = {}) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const analytics = useAnalytics();
  
  const {
    trackErrors = true,
    showNotifications = true,
    autoRetry = true,
    maxRetries = 3,
    retryDelay = 1000,
    onError = null,
  } = options;

  const [errors, setErrors] = useState([]);
  const [retryCount, setRetryCount] = useState(0);

  // Clear errors
  const clearErrors = useCallback(() => {
    setErrors([]);
    setRetryCount(0);
  }, []);

  // Handle error
  const handleError = useCallback((error, type = ErrorTypes.UNKNOWN, severity = ErrorSeverity.ERROR) => {
    const errorObject = {
      message: error.message || 'An error occurred',
      type,
      severity,
      timestamp: Date.now(),
      stack: error.stack,
      metadata: {
        url: window.location.href,
        userAgent: navigator.userAgent,
      },
    };

    // Add error to state
    setErrors(prev => [errorObject, ...prev]);

    // Track error
    if (trackErrors) {
      analytics.trackEvent('error', {
        type,
        severity,
        message: errorObject.message,
      });
    }

    // Show notification
    if (showNotifications) {
      dispatch(showSnackbar({
        message: errorObject.message,
        severity: severity === ErrorSeverity.CRITICAL ? 'error' : severity,
      }));
    }

    // Handle critical errors
    if (severity === ErrorSeverity.CRITICAL) {
      history.push('/error', { state: { error: errorObject } });
    }

    // Custom error handler
    if (onError) {
      onError(errorObject);
    }

    return errorObject;
  }, [trackErrors, showNotifications, analytics, dispatch, history, onError]);

  // Handle API errors
  const handleApiError = useCallback((error) => {
    const status = error.response?.status;
    let type = ErrorTypes.API;
    let severity = ErrorSeverity.ERROR;

    // Determine error type and severity
    if (!error.response) {
      type = ErrorTypes.NETWORK;
    } else if (status === 401 || status === 403) {
      type = ErrorTypes.AUTH;
      severity = ErrorSeverity.WARNING;
    } else if (status === 422) {
      type = ErrorTypes.VALIDATION;
      severity = ErrorSeverity.WARNING;
    } else if (status >= 500) {
      severity = ErrorSeverity.CRITICAL;
    }

    return handleError(error, type, severity);
  }, [handleError]);

  // Retry failed operation
  const retry = useCallback(async (operation, type) => {
    if (retryCount >= maxRetries) {
      return handleError(
        new Error(`Maximum retry attempts (${maxRetries}) exceeded`),
        type,
        ErrorSeverity.ERROR
      );
    }

    try {
      setRetryCount(prev => prev + 1);
      await new Promise(resolve => setTimeout(resolve, retryDelay * retryCount));
      const result = await operation();
      clearErrors();
      return result;
    } catch (error) {
      return handleError(error, type);
    }
  }, [retryCount, maxRetries, retryDelay, handleError, clearErrors]);

  // Auto retry failed operations
  useEffect(() => {
    if (autoRetry && errors.length > 0 && retryCount < maxRetries) {
      const lastError = errors[0];
      if (lastError.type === ErrorTypes.NETWORK || lastError.type === ErrorTypes.API) {
        retry(() => {
          // Implement retry logic based on error type
          return Promise.reject(new Error('Retry not implemented'));
        }, lastError.type);
      }
    }
  }, [autoRetry, errors, retryCount, maxRetries, retry]);

  // Error boundary methods
  const getDerivedStateFromError = useCallback((error) => {
    return {
      error: handleError(error, ErrorTypes.UNKNOWN, ErrorSeverity.CRITICAL),
    };
  }, [handleError]);

  const componentDidCatch = useCallback((error, errorInfo) => {
    handleError(error, ErrorTypes.UNKNOWN, ErrorSeverity.CRITICAL);
    if (trackErrors) {
      analytics.trackEvent('error_boundary', {
        error,
        errorInfo,
      });
    }
  }, [handleError, trackErrors, analytics]);

  return {
    errors,
    hasErrors: errors.length > 0,
    retryCount,
    clearErrors,
    handleError,
    handleApiError,
    retry,
    ErrorTypes,
    ErrorSeverity,
    getDerivedStateFromError,
    componentDidCatch,
  };
};

/**
 * Error boundary component
 */
export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
    this.errorHook = useError(props.options);
  }

  static getDerivedStateFromError(error) {
    return this.errorHook.getDerivedStateFromError(error);
  }

  componentDidCatch(error, errorInfo) {
    this.errorHook.componentDidCatch(error, errorInfo);
  }

  render() {
    if (this.state.error) {
      return this.props.fallback ? (
        this.props.fallback(this.state.error)
      ) : (
        <div>
          <h1>Something went wrong</h1>
          <p>{this.state.error.message}</p>
        </div>
      );
    }

    return this.props.children;
  }
}

/**
 * HOC to wrap components with error boundary
 */
export const withErrorBoundary = (WrappedComponent, options = {}) => {
  return function WithErrorBoundary(props) {
    return (
      <ErrorBoundary options={options} fallback={options.fallback}>
        <WrappedComponent {...props} />
      </ErrorBoundary>
    );
  };
};

export default useError;
