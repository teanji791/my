import { useState, useCallback } from 'react';
import axios from 'axios';

export const useSpotify = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [spotifyPlaylists, setSpotifyPlaylists] = useState([]);

  const connectToSpotify = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await axios.get('http://localhost:3000/api/spotify/auth', {
        withCredentials: true
      });
      window.location.href = response.data.url;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to connect to Spotify');
      console.error('Spotify connection error:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const fetchSpotifyPlaylists = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await axios.get('http://localhost:3000/api/spotify/playlists', {
        withCredentials: true
      });
      setSpotifyPlaylists(response.data.data.items);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch Spotify playlists');
      console.error('Error fetching Spotify playlists:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const importSpotifyPlaylist = useCallback(async (playlistId) => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await axios.post(
        `http://localhost:3000/api/spotify/playlists/${playlistId}/import`,
        {},
        { withCredentials: true }
      );
      return response.data.data;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to import playlist');
      console.error('Error importing playlist:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    isLoading,
    error,
    spotifyPlaylists,
    connectToSpotify,
    fetchSpotifyPlaylists,
    importSpotifyPlaylist
  };
};
