import { useState, useEffect, useCallback, useRef } from 'react';

/**
 * Hook to manage state in localStorage
 * @param {string} key - The localStorage key
 * @param {*} initialValue - The initial value
 * @param {Object} options - Additional options
 * @returns {[*, Function]} - The stored value and setter function
 */
const useLocalStorage = (key, initialValue = null, options = {}) => {
  const {
    serialize = JSON.stringify,
    deserialize = JSON.parse,
    encrypt = false,
    prefix = 'app_',
    ttl = null, // Time to live in milliseconds
  } = options;

  // Prefix the key
  const storageKey = `${prefix}${key}`;

  // Create a ref to track component mount status
  const isMounted = useRef(false);

  // Function to encrypt data
  const encryptData = useCallback((data) => {
    if (!encrypt) return data;
    try {
      // Simple encryption for demo purposes
      // In production, use a proper encryption library
      return btoa(data);
    } catch (error) {
      console.error('Encryption error:', error);
      return data;
    }
  }, [encrypt]);

  // Function to decrypt data
  const decryptData = useCallback((data) => {
    if (!encrypt) return data;
    try {
      return atob(data);
    } catch (error) {
      console.error('Decryption error:', error);
      return data;
    }
  }, [encrypt]);

  // Function to get stored value
  const getStoredValue = useCallback(() => {
    try {
      const item = localStorage.getItem(storageKey);
      if (item === null) {
        return typeof initialValue === 'function' ? initialValue() : initialValue;
      }

      const decrypted = decryptData(item);
      const { value, timestamp } = deserialize(decrypted);

      // Check if value has expired
      if (ttl && timestamp && Date.now() - timestamp > ttl) {
        localStorage.removeItem(storageKey);
        return typeof initialValue === 'function' ? initialValue() : initialValue;
      }

      return value;
    } catch (error) {
      console.error('Error reading from localStorage:', error);
      return typeof initialValue === 'function' ? initialValue() : initialValue;
    }
  }, [storageKey, initialValue, deserialize, decryptData, ttl]);

  // Initialize state
  const [storedValue, setStoredValue] = useState(getStoredValue);

  // Function to update stored value
  const setValue = useCallback((value) => {
    try {
      // Allow value to be a function
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      
      // Save to state
      setStoredValue(valueToStore);

      // Save to localStorage
      const toStore = {
        value: valueToStore,
        timestamp: Date.now(),
      };

      const serialized = serialize(toStore);
      const encrypted = encryptData(serialized);
      localStorage.setItem(storageKey, encrypted);

      // Dispatch storage event for cross-tab communication
      window.dispatchEvent(new StorageEvent('storage', {
        key: storageKey,
        newValue: encrypted,
        storageArea: localStorage,
      }));
    } catch (error) {
      console.error('Error saving to localStorage:', error);
    }
  }, [storageKey, storedValue, serialize, encryptData]);

  // Remove value from localStorage
  const removeValue = useCallback(() => {
    try {
      localStorage.removeItem(storageKey);
      setStoredValue(null);
    } catch (error) {
      console.error('Error removing from localStorage:', error);
    }
  }, [storageKey]);

  // Listen for changes in other tabs/windows
  useEffect(() => {
    const handleStorageChange = (e) => {
      if (e.key === storageKey && e.newValue !== null) {
        try {
          const decrypted = decryptData(e.newValue);
          const { value } = deserialize(decrypted);
          setStoredValue(value);
        } catch (error) {
          console.error('Error handling storage change:', error);
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [storageKey, deserialize, decryptData]);

  // Update localStorage when ttl expires
  useEffect(() => {
    if (!ttl) return;

    const checkExpiry = () => {
      const item = localStorage.getItem(storageKey);
      if (item === null) return;

      try {
        const decrypted = decryptData(item);
        const { timestamp } = deserialize(decrypted);

        if (timestamp && Date.now() - timestamp > ttl) {
          removeValue();
        }
      } catch (error) {
        console.error('Error checking expiry:', error);
      }
    };

    const interval = setInterval(checkExpiry, Math.min(ttl, 60000));
    return () => clearInterval(interval);
  }, [ttl, storageKey, decryptData, deserialize, removeValue]);

  // Set isMounted ref
  useEffect(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
    };
  }, []);

  return [storedValue, setValue, removeValue];
};

/**
 * Hook to manage multiple localStorage values
 * @param {Object} keys - Object with key-value pairs
 * @param {Object} options - Additional options
 * @returns {Object} - Object with stored values and setters
 */
export const useLocalStorageMulti = (keys, options = {}) => {
  const result = {};

  Object.entries(keys).forEach(([key, initialValue]) => {
    const [value, setValue, removeValue] = useLocalStorage(key, initialValue, options);
    result[key] = {
      value,
      setValue,
      removeValue,
    };
  });

  return result;
};

/**
 * Hook to manage localStorage with versioning
 * @param {string} key - The localStorage key
 * @param {*} initialValue - The initial value
 * @param {string} version - The version string
 * @param {Object} options - Additional options
 * @returns {[*, Function]} - The stored value and setter function
 */
export const useVersionedLocalStorage = (key, initialValue, version, options = {}) => {
  const versionedKey = `${key}_v${version}`;
  const [value, setValue, removeValue] = useLocalStorage(versionedKey, initialValue, options);

  // Clear old versions
  useEffect(() => {
    const keys = Object.keys(localStorage);
    keys.forEach((k) => {
      if (k.startsWith(`${options.prefix || 'app_'}${key}_v`) && k !== `${options.prefix || 'app_'}${versionedKey}`) {
        localStorage.removeItem(k);
      }
    });
  }, [key, versionedKey, options.prefix]);

  return [value, setValue, removeValue];
};

export default useLocalStorage;
