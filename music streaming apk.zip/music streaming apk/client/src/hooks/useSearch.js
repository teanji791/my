import { useState, useEffect } from 'react';
import axios from 'axios';

export const useSearch = (searchTerm) => {
  const [searchResults, setSearchResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const searchMusic = async () => {
      if (!searchTerm) {
        setSearchResults([]);
        return;
      }

      setIsLoading(true);
      setError(null);

      try {
        const response = await axios.get(`http://localhost:3000/api/music/search?q=${encodeURIComponent(searchTerm)}`, {
          withCredentials: true
        });
        
        if (response.data.success) {
          setSearchResults(response.data.data || []);
        } else {
          setError(response.data.message || 'Error searching music');
          setSearchResults([]);
        }
      } catch (err) {
        console.error('Search error:', err);
        setError(err.response?.data?.message || 'Error searching music');
        setSearchResults([]);
      } finally {
        setIsLoading(false);
      }
    };

    if (searchTerm) {
      searchMusic();
    }
  }, [searchTerm]);

  return { searchResults, isLoading, error };
};
