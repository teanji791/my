import { useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';

/**
 * Permission types
 */
const Permissions = {
  // Music permissions
  CREATE_MUSIC: 'create:music',
  EDIT_MUSIC: 'edit:music',
  DELETE_MUSIC: 'delete:music',
  UPLOAD_MUSIC: 'upload:music',
  DOWNLOAD_MUSIC: 'download:music',

  // Playlist permissions
  CREATE_PLAYLIST: 'create:playlist',
  EDIT_PLAYLIST: 'edit:playlist',
  DELETE_PLAYLIST: 'delete:playlist',
  SHARE_PLAYLIST: 'share:playlist',
  COLLABORATE_PLAYLIST: 'collaborate:playlist',

  // User permissions
  EDIT_PROFILE: 'edit:profile',
  DELETE_ACCOUNT: 'delete:account',
  FOLLOW_USER: 'follow:user',
  MESSAGE_USER: 'message:user',

  // Admin permissions
  MANAGE_USERS: 'manage:users',
  MANAGE_CONTENT: 'manage:content',
  VIEW_ANALYTICS: 'view:analytics',
  MANAGE_SETTINGS: 'manage:settings',
};

/**
 * Role-based permissions configuration
 */
const RolePermissions = {
  admin: [
    ...Object.values(Permissions),
  ],
  artist: [
    Permissions.CREATE_MUSIC,
    Permissions.EDIT_MUSIC,
    Permissions.DELETE_MUSIC,
    Permissions.UPLOAD_MUSIC,
    Permissions.DOWNLOAD_MUSIC,
    Permissions.CREATE_PLAYLIST,
    Permissions.EDIT_PLAYLIST,
    Permissions.DELETE_PLAYLIST,
    Permissions.SHARE_PLAYLIST,
    Permissions.COLLABORATE_PLAYLIST,
    Permissions.EDIT_PROFILE,
    Permissions.DELETE_ACCOUNT,
    Permissions.FOLLOW_USER,
    Permissions.MESSAGE_USER,
  ],
  premium: [
    Permissions.DOWNLOAD_MUSIC,
    Permissions.CREATE_PLAYLIST,
    Permissions.EDIT_PLAYLIST,
    Permissions.DELETE_PLAYLIST,
    Permissions.SHARE_PLAYLIST,
    Permissions.COLLABORATE_PLAYLIST,
    Permissions.EDIT_PROFILE,
    Permissions.DELETE_ACCOUNT,
    Permissions.FOLLOW_USER,
    Permissions.MESSAGE_USER,
  ],
  user: [
    Permissions.CREATE_PLAYLIST,
    Permissions.EDIT_PLAYLIST,
    Permissions.DELETE_PLAYLIST,
    Permissions.SHARE_PLAYLIST,
    Permissions.EDIT_PROFILE,
    Permissions.DELETE_ACCOUNT,
    Permissions.FOLLOW_USER,
    Permissions.MESSAGE_USER,
  ],
};

/**
 * Hook for handling permissions
 * @param {Object} options - Permission options
 * @returns {Object} - Permission checking functions
 */
const usePermissions = (options = {}) => {
  const { user } = useAuth();
  const {
    strictMode = true, // If true, undefined permissions are denied
    customPermissions = {}, // Additional custom permissions
  } = options;

  // Get user's role
  const getRole = useCallback(() => {
    return user?.role || 'user';
  }, [user]);

  // Get user's permissions
  const getUserPermissions = useCallback(() => {
    const role = getRole();
    return [
      ...(RolePermissions[role] || []),
      ...(customPermissions[role] || []),
    ];
  }, [getRole, customPermissions]);

  // Check if user has specific permission
  const hasPermission = useCallback((permission) => {
    if (!user) return false;
    
    const userPermissions = getUserPermissions();
    if (strictMode && !userPermissions.includes(permission)) {
      return false;
    }
    
    return userPermissions.includes(permission);
  }, [user, getUserPermissions, strictMode]);

  // Check if user has any of the permissions
  const hasAnyPermission = useCallback((permissions) => {
    return permissions.some(permission => hasPermission(permission));
  }, [hasPermission]);

  // Check if user has all permissions
  const hasAllPermissions = useCallback((permissions) => {
    return permissions.every(permission => hasPermission(permission));
  }, [hasPermission]);

  // Check if user has permission to manage resource
  const canManageResource = useCallback((resource, action) => {
    if (!user || !resource) return false;

    // Admins can manage all resources
    if (getRole() === 'admin') return true;

    // Check resource ownership
    if (resource.userId === user.id || resource.ownerId === user.id) {
      return hasPermission(`${action}:${resource.type}`);
    }

    // Check collaborative permissions for playlists
    if (resource.type === 'playlist' && resource.collaborators) {
      const isCollaborator = resource.collaborators.some(
        collab => collab.userId === user.id && collab.role === 'editor'
      );
      if (isCollaborator) {
        return hasPermission(`${action}:playlist`);
      }
    }

    return false;
  }, [user, getRole, hasPermission]);

  // Check if user can access premium features
  const hasPremiumAccess = useCallback(() => {
    const role = getRole();
    return ['admin', 'premium', 'artist'].includes(role);
  }, [getRole]);

  // Get all available permissions for current user
  const getAllPermissions = useCallback(() => {
    return {
      available: getUserPermissions(),
      all: Object.values(Permissions),
    };
  }, [getUserPermissions]);

  return {
    Permissions,
    RolePermissions,
    getRole,
    getUserPermissions,
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    canManageResource,
    hasPremiumAccess,
    getAllPermissions,
  };
};

/**
 * HOC to protect components with permissions
 * @param {Component} WrappedComponent - Component to protect
 * @param {string|string[]} requiredPermissions - Required permissions
 * @param {Object} options - Additional options
 * @returns {Component} - Protected component
 */
export const withPermissions = (WrappedComponent, requiredPermissions, options = {}) => {
  const {
    requireAll = false,
    fallback = null,
  } = options;

  return function PermissionWrapper(props) {
    const { hasAllPermissions, hasAnyPermission } = usePermissions();
    const permissions = Array.isArray(requiredPermissions) 
      ? requiredPermissions 
      : [requiredPermissions];

    const hasAccess = requireAll
      ? hasAllPermissions(permissions)
      : hasAnyPermission(permissions);

    if (!hasAccess) {
      return fallback;
    }

    return <WrappedComponent {...props} />;
  };
};

/**
 * Hook for checking premium features access
 */
export const usePremiumAccess = () => {
  const { hasPremiumAccess } = usePermissions();
  return hasPremiumAccess();
};

/**
 * Hook for checking artist features access
 */
export const useArtistAccess = () => {
  const { getRole } = usePermissions();
  return ['admin', 'artist'].includes(getRole());
};

export default usePermissions;
