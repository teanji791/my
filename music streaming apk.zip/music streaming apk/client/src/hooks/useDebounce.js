import { useState, useEffect, useCallback, useRef } from 'react';

/**
 * A hook that returns a debounced value and a function to update it
 * @param {*} initialValue - The initial value
 * @param {number} delay - The delay in milliseconds
 * @param {Object} options - Additional options
 * @returns {[*, Function]} - The debounced value and setter function
 */
export const useDebounce = (initialValue, delay = 500, options = {}) => {
  const [value, setValue] = useState(initialValue);
  const [debouncedValue, setDebouncedValue] = useState(initialValue);
  const timeoutRef = useRef(null);
  const { leading = false, maxWait = null } = options;
  const maxWaitRef = useRef(null);

  useEffect(() => {
    // Clear timeout on unmount
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      if (maxWaitRef.current) {
        clearTimeout(maxWaitRef.current);
      }
    };
  }, []);

  const updateValue = useCallback(
    (newValue) => {
      setValue(newValue);

      // Handle leading edge
      if (leading && !timeoutRef.current) {
        setDebouncedValue(newValue);
      }

      // Clear existing timeout
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }

      // Set new timeout
      timeoutRef.current = setTimeout(() => {
        setDebouncedValue(newValue);
        timeoutRef.current = null;
      }, delay);

      // Handle maxWait
      if (maxWait && !maxWaitRef.current) {
        maxWaitRef.current = setTimeout(() => {
          setDebouncedValue(newValue);
          maxWaitRef.current = null;
        }, maxWait);
      }
    },
    [delay, leading, maxWait]
  );

  return [debouncedValue, updateValue, value];
};

/**
 * A hook that returns a debounced callback function
 * @param {Function} callback - The callback function to debounce
 * @param {number} delay - The delay in milliseconds
 * @param {Object} options - Additional options
 * @returns {Function} - The debounced callback function
 */
export const useDebouncedCallback = (callback, delay = 500, options = {}) => {
  const timeoutRef = useRef(null);
  const callbackRef = useRef(callback);
  const { leading = false, maxWait = null } = options;
  const maxWaitRef = useRef(null);

  // Update callback ref when callback changes
  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);

  // Clear timeouts on unmount
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      if (maxWaitRef.current) {
        clearTimeout(maxWaitRef.current);
      }
    };
  }, []);

  return useCallback(
    (...args) => {
      // Handle leading edge
      if (leading && !timeoutRef.current) {
        callbackRef.current(...args);
      }

      // Clear existing timeout
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }

      // Set new timeout
      timeoutRef.current = setTimeout(() => {
        callbackRef.current(...args);
        timeoutRef.current = null;
      }, delay);

      // Handle maxWait
      if (maxWait && !maxWaitRef.current) {
        maxWaitRef.current = setTimeout(() => {
          callbackRef.current(...args);
          maxWaitRef.current = null;
        }, maxWait);
      }
    },
    [delay, leading, maxWait]
  );
};

/**
 * A hook that returns a debounced search function and results
 * @param {Function} searchFunction - The search function to debounce
 * @param {number} delay - The delay in milliseconds
 * @param {Object} options - Additional options
 * @returns {Object} - The search state and functions
 */
export const useDebouncedSearch = (searchFunction, delay = 500, options = {}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { minLength = 2 } = options;

  const debouncedSearch = useDebouncedCallback(
    async (term) => {
      if (term.length < minLength) {
        setResults([]);
        return;
      }

      try {
        setLoading(true);
        setError(null);
        const searchResults = await searchFunction(term);
        setResults(searchResults);
      } catch (err) {
        setError(err.message || 'Search failed');
        setResults([]);
      } finally {
        setLoading(false);
      }
    },
    delay,
    options
  );

  const handleSearch = useCallback(
    (term) => {
      setSearchTerm(term);
      debouncedSearch(term);
    },
    [debouncedSearch]
  );

  const clearSearch = useCallback(() => {
    setSearchTerm('');
    setResults([]);
    setError(null);
  }, []);

  return {
    searchTerm,
    results,
    loading,
    error,
    handleSearch,
    clearSearch,
  };
};

/**
 * A hook that returns a debounced value for form inputs
 * @param {*} value - The value to debounce
 * @param {number} delay - The delay in milliseconds
 * @returns {*} - The debounced value
 */
export const useDebouncedInput = (value, delay = 500) => {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const timeout = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(timeout);
    };
  }, [value, delay]);

  return debouncedValue;
};

export default useDebounce;
