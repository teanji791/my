import { useState, useCallback, useRef, useEffect } from 'react';
import { usePlayer } from '../contexts/PlayerContext';
import { useLocalStorage } from './useLocalStorage';

/**
 * Effect types configuration
 */
const EffectTypes = {
  EQUALIZER: 'equalizer',
  REVERB: 'reverb',
  DELAY: 'delay',
  COMPRESSOR: 'compressor',
  DISTORTION: 'distortion',
  FILTER: 'filter',
};

/**
 * Default equalizer bands configuration
 */
const DEFAULT_EQ_BANDS = [
  { frequency: 32, gain: 0, Q: 1.0 },
  { frequency: 64, gain: 0, Q: 1.0 },
  { frequency: 125, gain: 0, Q: 1.0 },
  { frequency: 250, gain: 0, Q: 1.0 },
  { frequency: 500, gain: 0, Q: 1.0 },
  { frequency: 1000, gain: 0, Q: 1.0 },
  { frequency: 2000, gain: 0, Q: 1.0 },
  { frequency: 4000, gain: 0, Q: 1.0 },
  { frequency: 8000, gain: 0, Q: 1.0 },
  { frequency: 16000, gain: 0, Q: 1.0 },
];

/**
 * Hook for handling audio effects
 * @param {Object} options - Audio effects options
 * @returns {Object} - Audio effects state and functions
 */
const useAudioEffects = (options = {}) => {
  const { audioRef } = usePlayer();
  const [effectsEnabled, setEffectsEnabled] = useLocalStorage('effects_enabled', true);
  const [activeEffects, setActiveEffects] = useLocalStorage('active_effects', []);
  const [eqSettings, setEqSettings] = useLocalStorage('eq_settings', DEFAULT_EQ_BANDS);

  const audioContextRef = useRef(null);
  const sourceNodeRef = useRef(null);
  const effectNodesRef = useRef({});

  const {
    defaultPresets = {},
    maxEffects = 5,
    sampleRate = 44100,
  } = options;

  // Initialize audio context and nodes
  const initializeAudioContext = useCallback(() => {
    if (!audioContextRef.current && audioRef.current) {
      try {
        audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)({
          sampleRate,
        });
        sourceNodeRef.current = audioContextRef.current.createMediaElementSource(audioRef.current);
        return true;
      } catch (error) {
        console.error('Audio context initialization error:', error);
        return false;
      }
    }
    return !!audioContextRef.current;
  }, [audioRef, sampleRate]);

  // Create equalizer
  const createEqualizer = useCallback(() => {
    if (!audioContextRef.current) return null;

    const eqNodes = eqSettings.map(band => {
      const filter = audioContextRef.current.createBiquadFilter();
      filter.type = 'peaking';
      filter.frequency.value = band.frequency;
      filter.gain.value = band.gain;
      filter.Q.value = band.Q;
      return filter;
    });

    // Connect nodes in series
    eqNodes.reduce((prev, curr) => {
      prev.connect(curr);
      return curr;
    });

    return {
      input: eqNodes[0],
      output: eqNodes[eqNodes.length - 1],
      nodes: eqNodes,
    };
  }, [eqSettings]);

  // Create reverb effect
  const createReverb = useCallback(async (options = {}) => {
    if (!audioContextRef.current) return null;

    const { impulseResponse, duration = 2, decay = 2 } = options;
    const convolver = audioContextRef.current.createConvolver();

    if (impulseResponse) {
      convolver.buffer = impulseResponse;
    } else {
      // Create synthetic impulse response
      const rate = audioContextRef.current.sampleRate;
      const length = rate * duration;
      const impulse = audioContextRef.current.createBuffer(2, length, rate);

      for (let channel = 0; channel < 2; channel++) {
        const channelData = impulse.getChannelData(channel);
        for (let i = 0; i < length; i++) {
          channelData[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
        }
      }

      convolver.buffer = impulse;
    }

    return {
      input: convolver,
      output: convolver,
    };
  }, []);

  // Create delay effect
  const createDelay = useCallback((options = {}) => {
    if (!audioContextRef.current) return null;

    const { delayTime = 0.5, feedback = 0.5 } = options;
    const delay = audioContextRef.current.createDelay();
    const feedback_node = audioContextRef.current.createGain();

    delay.delayTime.value = delayTime;
    feedback_node.gain.value = feedback;

    delay.connect(feedback_node);
    feedback_node.connect(delay);

    return {
      input: delay,
      output: delay,
      controls: {
        delayTime: delay.delayTime,
        feedback: feedback_node.gain,
      },
    };
  }, []);

  // Create compressor effect
  const createCompressor = useCallback((options = {}) => {
    if (!audioContextRef.current) return null;

    const {
      threshold = -24,
      knee = 30,
      ratio = 12,
      attack = 0.003,
      release = 0.25,
    } = options;

    const compressor = audioContextRef.current.createDynamicsCompressor();
    compressor.threshold.value = threshold;
    compressor.knee.value = knee;
    compressor.ratio.value = ratio;
    compressor.attack.value = attack;
    compressor.release.value = release;

    return {
      input: compressor,
      output: compressor,
      controls: {
        threshold: compressor.threshold,
        knee: compressor.knee,
        ratio: compressor.ratio,
        attack: compressor.attack,
        release: compressor.release,
      },
    };
  }, []);

  // Add effect
  const addEffect = useCallback(async (type, options = {}) => {
    if (!effectsEnabled || activeEffects.length >= maxEffects) return false;

    try {
      if (!audioContextRef.current && !initializeAudioContext()) {
        return false;
      }

      let effect;
      switch (type) {
        case EffectTypes.EQUALIZER:
          effect = createEqualizer();
          break;
        case EffectTypes.REVERB:
          effect = await createReverb(options);
          break;
        case EffectTypes.DELAY:
          effect = createDelay(options);
          break;
        case EffectTypes.COMPRESSOR:
          effect = createCompressor(options);
          break;
        default:
          return false;
      }

      if (effect) {
        effectNodesRef.current[type] = effect;
        setActiveEffects(prev => [...prev, type]);
        reconnectEffectChain();
        return true;
      }

      return false;
    } catch (error) {
      console.error('Add effect error:', error);
      return false;
    }
  }, [
    effectsEnabled,
    activeEffects,
    maxEffects,
    initializeAudioContext,
    createEqualizer,
    createReverb,
    createDelay,
    createCompressor,
  ]);

  // Remove effect
  const removeEffect = useCallback((type) => {
    if (effectNodesRef.current[type]) {
      effectNodesRef.current[type].input.disconnect();
      effectNodesRef.current[type].output.disconnect();
      delete effectNodesRef.current[type];
      setActiveEffects(prev => prev.filter(t => t !== type));
      reconnectEffectChain();
      return true;
    }
    return false;
  }, []);

  // Reconnect effect chain
  const reconnectEffectChain = useCallback(() => {
    if (!sourceNodeRef.current || !audioContextRef.current) return;

    let lastNode = sourceNodeRef.current;

    activeEffects.forEach(type => {
      const effect = effectNodesRef.current[type];
      if (effect) {
        lastNode.connect(effect.input);
        lastNode = effect.output;
      }
    });

    lastNode.connect(audioContextRef.current.destination);
  }, [activeEffects]);

  // Update effect parameters
  const updateEffect = useCallback((type, parameters) => {
    const effect = effectNodesRef.current[type];
    if (!effect) return false;

    try {
      Object.entries(parameters).forEach(([param, value]) => {
        if (effect.controls && effect.controls[param]) {
          effect.controls[param].value = value;
        }
      });
      return true;
    } catch (error) {
      console.error('Update effect error:', error);
      return false;
    }
  }, []);

  // Toggle effects
  const toggleEffects = useCallback(() => {
    setEffectsEnabled(prev => !prev);
  }, [setEffectsEnabled]);

  // Update equalizer settings
  const updateEqualizer = useCallback((bandIndex, gain) => {
    setEqSettings(prev => {
      const newSettings = [...prev];
      newSettings[bandIndex] = { ...newSettings[bandIndex], gain };
      return newSettings;
    });

    const eq = effectNodesRef.current[EffectTypes.EQUALIZER];
    if (eq && eq.nodes[bandIndex]) {
      eq.nodes[bandIndex].gain.value = gain;
    }
  }, [setEqSettings]);

  // Reset effects
  const resetEffects = useCallback(() => {
    Object.keys(effectNodesRef.current).forEach(removeEffect);
    setEqSettings(DEFAULT_EQ_BANDS);
  }, [removeEffect, setEqSettings]);

  // Cleanup
  useEffect(() => {
    return () => {
      Object.keys(effectNodesRef.current).forEach(removeEffect);
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, [removeEffect]);

  return {
    effectsEnabled,
    activeEffects,
    eqSettings,
    addEffect,
    removeEffect,
    updateEffect,
    toggleEffects,
    updateEqualizer,
    resetEffects,
    EffectTypes,
  };
};

export default useAudioEffects;
