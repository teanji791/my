import { useState, useCallback, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useAnalytics } from './useAnalytics';
import { useCache } from './useCache';
import api from '../utils/api';

/**
 * Stats types configuration
 */
const StatsTypes = {
  PLAYS: 'plays',
  FAVORITES: 'favorites',
  SKIPS: 'skips',
  LISTENING_TIME: 'listening_time',
  GENRES: 'genres',
  ARTISTS: 'artists',
  TIME_OF_DAY: 'time_of_day',
  DAYS_OF_WEEK: 'days_of_week',
};

/**
 * Time periods configuration
 */
const TimePeriods = {
  DAY: 'day',
  WEEK: 'week',
  MONTH: 'month',
  YEAR: 'year',
  ALL_TIME: 'all_time',
};

/**
 * Hook for handling music statistics
 * @param {Object} options - Stats options
 * @returns {Object} - Stats state and functions
 */
const useStats = (options = {}) => {
  const user = useSelector(state => state.auth.user);
  const analytics = useAnalytics();
  const cache = useCache({
    persistKey: 'stats_cache',
    ttl: 60 * 60 * 1000, // 1 hour
  });

  const {
    autoRefresh = true,
    refreshInterval = 5 * 60 * 1000, // 5 minutes
    cacheStats = true,
    defaultPeriod = TimePeriods.WEEK,
    includeOffline = true,
  } = options;

  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  // Get stats for specific type and period
  const getStats = useCallback(async (type, period = defaultPeriod) => {
    if (!user) return null;

    try {
      // Check cache first
      if (cacheStats) {
        const cacheKey = `${type}_${period}`;
        const cachedStats = cache.get(cacheKey);
        if (cachedStats) {
          return cachedStats;
        }
      }

      const response = await api.get('/stats', {
        params: { type, period, include_offline: includeOffline },
      });

      const statsData = response.data;

      // Cache stats
      if (cacheStats) {
        cache.set(`${type}_${period}`, statsData);
      }

      return statsData;
    } catch (error) {
      console.error('Stats error:', error);
      throw error;
    }
  }, [user, defaultPeriod, includeOffline, cacheStats, cache]);

  // Get all stats
  const getAllStats = useCallback(async (period = defaultPeriod) => {
    try {
      setLoading(true);
      setError(null);

      const statsData = {};
      await Promise.all(
        Object.values(StatsTypes).map(async (type) => {
          try {
            statsData[type] = await getStats(type, period);
          } catch (error) {
            console.error(`Error getting ${type} stats:`, error);
          }
        })
      );

      setStats(statsData);
      setLastUpdated(Date.now());

      analytics.trackEvent('stats_fetched', {
        period,
        types: Object.keys(statsData),
      });

      return statsData;
    } catch (error) {
      console.error('Get all stats error:', error);
      setError(error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  }, [defaultPeriod, getStats, analytics]);

  // Track play
  const trackPlay = useCallback(async (track) => {
    try {
      await api.post('/stats/plays', {
        trackId: track.id,
        timestamp: Date.now(),
      });

      analytics.trackEvent('track_played', {
        trackId: track.id,
        artist: track.artist,
        genre: track.genre,
      });
    } catch (error) {
      console.error('Track play error:', error);
    }
  }, [analytics]);

  // Track skip
  const trackSkip = useCallback(async (track, playTime) => {
    try {
      await api.post('/stats/skips', {
        trackId: track.id,
        playTime,
        timestamp: Date.now(),
      });

      analytics.trackEvent('track_skipped', {
        trackId: track.id,
        playTime,
      });
    } catch (error) {
      console.error('Track skip error:', error);
    }
  }, [analytics]);

  // Get listening time
  const getListeningTime = useCallback(async (period = defaultPeriod) => {
    try {
      const stats = await getStats(StatsTypes.LISTENING_TIME, period);
      return {
        total: stats.total,
        average: stats.average,
        byDay: stats.byDay,
        byGenre: stats.byGenre,
      };
    } catch (error) {
      console.error('Listening time error:', error);
      return null;
    }
  }, [defaultPeriod, getStats]);

  // Get top items
  const getTopItems = useCallback(async (type, period = defaultPeriod, limit = 10) => {
    try {
      const response = await api.get('/stats/top', {
        params: { type, period, limit },
      });
      return response.data;
    } catch (error) {
      console.error('Top items error:', error);
      return [];
    }
  }, [defaultPeriod]);

  // Get recommendations based on stats
  const getRecommendationsFromStats = useCallback(async () => {
    try {
      const response = await api.get('/stats/recommendations');
      return response.data;
    } catch (error) {
      console.error('Stats recommendations error:', error);
      return [];
    }
  }, []);

  // Export stats
  const exportStats = useCallback(async (format = 'json') => {
    try {
      const response = await api.get('/stats/export', {
        params: { format },
        responseType: 'blob',
      });

      const url = window.URL.createObjectURL(response.data);
      const link = document.createElement('a');
      link.href = url;
      link.download = `music-stats.${format}`;
      link.click();

      analytics.trackEvent('stats_exported', { format });
    } catch (error) {
      console.error('Stats export error:', error);
      throw error;
    }
  }, [analytics]);

  // Auto refresh stats
  useEffect(() => {
    if (!autoRefresh || !user) return;

    const shouldRefresh = !lastUpdated || 
      (Date.now() - lastUpdated) >= refreshInterval;

    if (shouldRefresh) {
      getAllStats();
    }

    const interval = setInterval(getAllStats, refreshInterval);
    return () => clearInterval(interval);
  }, [autoRefresh, user, lastUpdated, refreshInterval, getAllStats]);

  return {
    stats,
    loading,
    error,
    lastUpdated,
    getStats,
    getAllStats,
    trackPlay,
    trackSkip,
    getListeningTime,
    getTopItems,
    getRecommendationsFromStats,
    exportStats,
    StatsTypes,
    TimePeriods,
  };
};

/**
 * Hook for handling genre statistics
 */
export const useGenreStats = (options = {}) => {
  const stats = useStats(options);

  const getGenreBreakdown = useCallback(async (period = TimePeriods.MONTH) => {
    return stats.getStats(StatsTypes.GENRES, period);
  }, [stats]);

  const getTopGenres = useCallback(async (period = TimePeriods.MONTH, limit = 5) => {
    return stats.getTopItems('genres', period, limit);
  }, [stats]);

  return {
    ...stats,
    getGenreBreakdown,
    getTopGenres,
  };
};

/**
 * Hook for handling artist statistics
 */
export const useArtistStats = (options = {}) => {
  const stats = useStats(options);

  const getArtistBreakdown = useCallback(async (period = TimePeriods.MONTH) => {
    return stats.getStats(StatsTypes.ARTISTS, period);
  }, [stats]);

  const getTopArtists = useCallback(async (period = TimePeriods.MONTH, limit = 5) => {
    return stats.getTopItems('artists', period, limit);
  }, [stats]);

  return {
    ...stats,
    getArtistBreakdown,
    getTopArtists,
  };
};

export default useStats;
