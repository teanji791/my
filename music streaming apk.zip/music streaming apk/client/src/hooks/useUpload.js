import { useState, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import axios from 'axios';
import { showErrorSnackbar, showSuccessSnackbar } from '../store/slices/uiSlice';

/**
 * Hook for handling file uploads
 * @param {Object} options - Upload options
 * @returns {Object} - Upload state and functions
 */
const useUpload = (options = {}) => {
  const dispatch = useDispatch();
  const {
    endpoint = '/api/upload',
    maxSize = 20 * 1024 * 1024, // 20MB
    allowedTypes = [],
    useS3 = false,
    s3Config = {},
    onProgress = () => {},
    onSuccess = () => {},
    onError = () => {},
  } = options;

  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState(null);

  // Validate file
  const validateFile = useCallback((file) => {
    if (!file) {
      throw new Error('No file provided');
    }

    // Check file size
    if (file.size > maxSize) {
      throw new Error(`File size exceeds ${maxSize / (1024 * 1024)}MB limit`);
    }

    // Check file type
    if (allowedTypes.length > 0 && !allowedTypes.includes(file.type)) {
      throw new Error(`File type ${file.type} not allowed`);
    }

    return true;
  }, [maxSize, allowedTypes]);

  // Upload to S3
  const uploadToS3 = useCallback(async (file) => {
    const { getSignedUrl } = s3Config;

    try {
      // Get signed URL
      const { data: { url, fields } } = await axios.get(getSignedUrl, {
        params: {
          fileName: file.name,
          fileType: file.type,
        },
      });

      // Prepare form data
      const formData = new FormData();
      Object.entries(fields).forEach(([key, value]) => {
        formData.append(key, value);
      });
      formData.append('file', file);

      // Upload to S3
      await axios.post(url, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const percentage = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
          setProgress(percentage);
          onProgress(percentage);
        },
      });

      return `${url}/${fields.key}`;
    } catch (error) {
      console.error('S3 upload error:', error);
      throw new Error('Failed to upload to S3');
    }
  }, [s3Config, onProgress]);

  // Upload to server
  const uploadToServer = useCallback(async (file, additionalData = {}) => {
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      // Append additional data
      Object.entries(additionalData).forEach(([key, value]) => {
        formData.append(key, JSON.stringify(value));
      });

      const { data } = await axios.post(endpoint, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const percentage = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
          setProgress(percentage);
          onProgress(percentage);
        },
      });

      return data;
    } catch (error) {
      console.error('Server upload error:', error);
      throw new Error('Failed to upload to server');
    }
  }, [endpoint, onProgress]);

  // Main upload function
  const upload = useCallback(async (file, additionalData = {}) => {
    try {
      setUploading(true);
      setProgress(0);
      setError(null);

      // Validate file
      validateFile(file);

      // Upload file
      const result = useS3
        ? await uploadToS3(file)
        : await uploadToServer(file, additionalData);

      dispatch(showSuccessSnackbar('File uploaded successfully'));
      onSuccess(result);
      return result;
    } catch (error) {
      setError(error.message);
      dispatch(showErrorSnackbar(error.message));
      onError(error);
      throw error;
    } finally {
      setUploading(false);
    }
  }, [
    validateFile,
    useS3,
    uploadToS3,
    uploadToServer,
    dispatch,
    onSuccess,
    onError,
  ]);

  // Upload multiple files
  const uploadMultiple = useCallback(async (files, additionalData = {}) => {
    try {
      setUploading(true);
      setProgress(0);
      setError(null);

      const results = [];
      let totalProgress = 0;

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        try {
          validateFile(file);
          const result = useS3
            ? await uploadToS3(file)
            : await uploadToServer(file, additionalData);
          results.push(result);
          totalProgress = ((i + 1) / files.length) * 100;
          setProgress(totalProgress);
          onProgress(totalProgress);
        } catch (error) {
          console.error(`Error uploading file ${file.name}:`, error);
          results.push({ file: file.name, error: error.message });
        }
      }

      const successCount = results.filter(r => !r.error).length;
      dispatch(showSuccessSnackbar(
        `Successfully uploaded ${successCount} of ${files.length} files`
      ));
      onSuccess(results);
      return results;
    } catch (error) {
      setError(error.message);
      dispatch(showErrorSnackbar(error.message));
      onError(error);
      throw error;
    } finally {
      setUploading(false);
    }
  }, [
    validateFile,
    useS3,
    uploadToS3,
    uploadToServer,
    dispatch,
    onProgress,
    onSuccess,
    onError,
  ]);

  // Cancel upload
  const cancelUpload = useCallback(() => {
    // TODO: Implement upload cancellation
    console.warn('Upload cancellation not implemented');
  }, []);

  return {
    upload,
    uploadMultiple,
    cancelUpload,
    uploading,
    progress,
    error,
    validateFile,
  };
};

/**
 * Hook for handling music file uploads
 */
export const useMusicUpload = (options = {}) => {
  return useUpload({
    endpoint: '/api/music/upload',
    allowedTypes: ['audio/mpeg', 'audio/wav', 'audio/ogg'],
    maxSize: 50 * 1024 * 1024, // 50MB
    ...options,
  });
};

/**
 * Hook for handling image uploads
 */
export const useImageUpload = (options = {}) => {
  return useUpload({
    endpoint: '/api/images/upload',
    allowedTypes: ['image/jpeg', 'image/png', 'image/webp'],
    maxSize: 5 * 1024 * 1024, // 5MB
    ...options,
  });
};

/**
 * Hook for handling avatar uploads
 */
export const useAvatarUpload = (options = {}) => {
  return useUpload({
    endpoint: '/api/auth/avatar',
    allowedTypes: ['image/jpeg', 'image/png', 'image/webp'],
    maxSize: 2 * 1024 * 1024, // 2MB
    ...options,
  });
};

export default useUpload;
