import { useEffect, useCallback, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { usePlayer } from '../contexts/PlayerContext';
import api from '../utils/api';

/**
 * Analytics event types
 */
const EventTypes = {
  PAGE_VIEW: 'page_view',
  TRACK_PLAY: 'track_play',
  TRACK_PAUSE: 'track_pause',
  TRACK_COMPLETE: 'track_complete',
  TRACK_SKIP: 'track_skip',
  TRACK_SEEK: 'track_seek',
  PLAYLIST_CREATE: 'playlist_create',
  PLAYLIST_DELETE: 'playlist_delete',
  PLAYLIST_EDIT: 'playlist_edit',
  TRACK_LIKE: 'track_like',
  TRACK_UNLIKE: 'track_unlike',
  SEARCH: 'search',
  ERROR: 'error',
  USER_LOGIN: 'user_login',
  USER_LOGOUT: 'user_logout',
  USER_REGISTER: 'user_register',
  SHARE: 'share',
};

/**
 * Hook for tracking analytics
 * @param {Object} options - Analytics options
 * @returns {Object} - Analytics functions
 */
const useAnalytics = (options = {}) => {
  const location = useLocation();
  const { user } = useAuth();
  const player = usePlayer();
  const sessionId = useRef(Date.now().toString(36));
  const lastTrackProgress = useRef(0);
  const trackStartTime = useRef(null);

  const {
    enabled = true,
    sampleRate = 1, // 1 = track everything, 0.5 = track 50% of events
    batchSize = 10,
    batchInterval = 5000, // 5 seconds
    trackPageViews = true,
    trackPlayback = true,
    trackErrors = true,
    enableSearchTracking = true,
    trackUserActions = true,
  } = options;

  // Queue for batching events
  const eventQueue = useRef([]);
  const batchTimeout = useRef(null);

  // Track page views
  useEffect(() => {
    if (!enabled || !trackPageViews) return;

    trackEvent(EventTypes.PAGE_VIEW, {
      path: location.pathname,
      query: location.search,
    });
  }, [enabled, trackPageViews, location]);

  // Track playback events
  useEffect(() => {
    if (!enabled || !trackPlayback || !player.currentTrack) return;

    if (player.isPlaying) {
      trackStartTime.current = Date.now();
      trackEvent(EventTypes.TRACK_PLAY, {
        trackId: player.currentTrack.id,
        position: player.currentTime,
      });
    } else {
      trackEvent(EventTypes.TRACK_PAUSE, {
        trackId: player.currentTrack.id,
        position: player.currentTime,
        duration: trackStartTime.current
          ? (Date.now() - trackStartTime.current) / 1000
          : 0,
      });
    }

    // Track progress
    const progressInterval = setInterval(() => {
      if (player.isPlaying) {
        const progress = (player.currentTime / player.duration) * 100;
        if (Math.abs(progress - lastTrackProgress.current) > 5) {
          // Only track significant progress changes (>5%)
          lastTrackProgress.current = progress;
          trackEvent(EventTypes.TRACK_PROGRESS, {
            trackId: player.currentTrack.id,
            progress,
            position: player.currentTime,
          });
        }
      }
    }, 5000);

    return () => clearInterval(progressInterval);
  }, [enabled, trackPlayback, player.isPlaying, player.currentTrack]);

  // Function to track events
  const trackEvent = useCallback(
    (type, data = {}) => {
      if (!enabled || Math.random() > sampleRate) return;

      const event = {
        type,
        timestamp: Date.now(),
        sessionId: sessionId.current,
        userId: user?.id,
        data: {
          ...data,
          url: window.location.href,
          referrer: document.referrer,
          userAgent: navigator.userAgent,
        },
      };

      // Add to queue
      eventQueue.current.push(event);

      // Send batch if queue is full
      if (eventQueue.current.length >= batchSize) {
        sendBatch();
      }

      // Set timeout for next batch
      if (!batchTimeout.current) {
        batchTimeout.current = setTimeout(sendBatch, batchInterval);
      }
    },
    [enabled, sampleRate, user, batchSize, batchInterval]
  );

  // Function to send batch of events
  const sendBatch = useCallback(async () => {
    if (eventQueue.current.length === 0) return;

    try {
      const events = [...eventQueue.current];
      eventQueue.current = [];
      clearTimeout(batchTimeout.current);
      batchTimeout.current = null;

      await api.post('/analytics/events', { events });
    } catch (error) {
      console.error('Error sending analytics batch:', error);
      // Put events back in queue
      eventQueue.current = [...eventQueue.current, ...events];
    }
  }, []);

  // Send remaining events on unmount
  useEffect(() => {
    return () => {
      if (eventQueue.current.length > 0) {
        sendBatch();
      }
    };
  }, [sendBatch]);

  // Track errors
  useEffect(() => {
    if (!enabled || !trackErrors) return;

    const handleError = (error) => {
      trackEvent(EventTypes.ERROR, {
        message: error.message,
        stack: error.stack,
        type: error.name,
      });
    };

    window.addEventListener('error', handleError);
    window.addEventListener('unhandledrejection', handleError);

    return () => {
      window.removeEventListener('error', handleError);
      window.removeEventListener('unhandledrejection', handleError);
    };
  }, [enabled, trackErrors, trackEvent]);

  // Utility functions for common events
  const trackSearchQuery = useCallback(
    (query, results) => {
      if (!enabled || !enableSearchTracking) return;
      trackEvent(EventTypes.SEARCH, {
        query,
        resultCount: results.length,
      });
    },
    [enabled, enableSearchTracking, trackEvent]
  );

  const trackShare = useCallback(
    (contentType, contentId, platform) => {
      trackEvent(EventTypes.SHARE, {
        contentType,
        contentId,
        platform,
      });
    },
    [trackEvent]
  );

  const trackUserAction = useCallback(
    (action, data) => {
      if (!enabled || !trackUserActions) return;
      trackEvent(action, data);
    },
    [enabled, trackUserActions, trackEvent]
  );

  // Analytics data
  const getSessionDuration = useCallback(() => {
    return Date.now() - parseInt(sessionId.current, 36);
  }, []);

  return {
    trackEvent,
    trackSearchQuery,
    trackShare,
    trackUserAction,
    getSessionDuration,
    EventTypes,
  };
};

/**
 * Hook for tracking component-specific analytics
 */
export const useComponentAnalytics = (componentName, options = {}) => {
  const analytics = useAnalytics(options);
  const mountTime = useRef(Date.now());

  // Track mount/unmount
  useEffect(() => {
    analytics.trackEvent('component_mount', {
      component: componentName,
    });

    return () => {
      const duration = Date.now() - mountTime.current;
      analytics.trackEvent('component_unmount', {
        component: componentName,
        duration,
      });
    };
  }, [componentName, analytics]);

  // Track render time
  useEffect(() => {
    const renderTime = Date.now() - mountTime.current;
    analytics.trackEvent('component_render', {
      component: componentName,
      renderTime,
    });
  });

  return {
    ...analytics,
    trackComponentEvent: (eventName, data = {}) =>
      analytics.trackEvent(`component_${eventName}`, {
        ...data,
        component: componentName,
      }),
  };
};

export default useAnalytics;
