import { useState, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { showErrorSnackbar } from '../store/slices/uiSlice';
import { useCache } from './useCache';
import api from '../utils/api';

/**
 * Metadata types configuration
 */
const MetadataTypes = {
  ID3: 'id3',
  VORBIS: 'vorbis',
  MP4: 'mp4',
};

/**
 * Hook for handling music metadata
 * @param {Object} options - Metadata options
 * @returns {Object} - Metadata functions and state
 */
const useMetadata = (options = {}) => {
  const dispatch = useDispatch();
  const cache = useCache({
    persistKey: 'metadata_cache',
    ttl: 24 * 60 * 60 * 1000, // 24 hours
  });

  const {
    cacheMetadata = true,
    validateMetadata = true,
    autoExtract = true,
  } = options;

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Extract metadata from file
  const extractMetadata = useCallback(async (file) => {
    try {
      setLoading(true);
      setError(null);

      // Check cache first
      if (cacheMetadata) {
        const cachedMetadata = cache.get(file.name);
        if (cachedMetadata) {
          return cachedMetadata;
        }
      }

      // Create file reader
      const reader = new FileReader();
      const arrayBuffer = await new Promise((resolve, reject) => {
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(reader.error);
        reader.readAsArrayBuffer(file);
      });

      // Extract metadata based on file type
      let metadata;
      if (file.type.includes('mp3')) {
        metadata = await extractID3(arrayBuffer);
      } else if (file.type.includes('ogg')) {
        metadata = await extractVorbis(arrayBuffer);
      } else if (file.type.includes('m4a')) {
        metadata = await extractMP4(arrayBuffer);
      } else {
        throw new Error('Unsupported file type');
      }

      // Validate metadata
      if (validateMetadata) {
        validateMetadataFields(metadata);
      }

      // Cache metadata
      if (cacheMetadata) {
        cache.set(file.name, metadata);
      }

      return metadata;
    } catch (error) {
      console.error('Metadata extraction error:', error);
      setError(error.message);
      dispatch(showErrorSnackbar('Error extracting metadata'));
      throw error;
    } finally {
      setLoading(false);
    }
  }, [cacheMetadata, validateMetadata, cache, dispatch]);

  // Extract ID3 metadata
  const extractID3 = async (arrayBuffer) => {
    // Implementation would use a library like 'music-metadata-browser'
    return {
      type: MetadataTypes.ID3,
      // ... extracted metadata
    };
  };

  // Extract Vorbis metadata
  const extractVorbis = async (arrayBuffer) => {
    return {
      type: MetadataTypes.VORBIS,
      // ... extracted metadata
    };
  };

  // Extract MP4 metadata
  const extractMP4 = async (arrayBuffer) => {
    return {
      type: MetadataTypes.MP4,
      // ... extracted metadata
    };
  };

  // Validate metadata fields
  const validateMetadataFields = (metadata) => {
    const requiredFields = ['title', 'artist'];
    const missingFields = requiredFields.filter(field => !metadata[field]);
    
    if (missingFields.length > 0) {
      throw new Error(`Missing required metadata fields: ${missingFields.join(', ')}`);
    }
  };

  // Update metadata
  const updateMetadata = useCallback(async (trackId, metadata) => {
    try {
      setLoading(true);
      setError(null);

      const response = await api.put(`/tracks/${trackId}/metadata`, metadata);

      // Update cache
      if (cacheMetadata) {
        cache.set(`track_${trackId}`, response.data.metadata);
      }

      return response.data.metadata;
    } catch (error) {
      console.error('Metadata update error:', error);
      setError(error.message);
      dispatch(showErrorSnackbar('Error updating metadata'));
      throw error;
    } finally {
      setLoading(false);
    }
  }, [cacheMetadata, cache, dispatch]);

  // Get metadata for track
  const getMetadata = useCallback(async (trackId) => {
    try {
      setLoading(true);
      setError(null);

      // Check cache first
      if (cacheMetadata) {
        const cachedMetadata = cache.get(`track_${trackId}`);
        if (cachedMetadata) {
          return cachedMetadata;
        }
      }

      const response = await api.get(`/tracks/${trackId}/metadata`);

      // Cache metadata
      if (cacheMetadata) {
        cache.set(`track_${trackId}`, response.data.metadata);
      }

      return response.data.metadata;
    } catch (error) {
      console.error('Metadata fetch error:', error);
      setError(error.message);
      dispatch(showErrorSnackbar('Error fetching metadata'));
      throw error;
    } finally {
      setLoading(false);
    }
  }, [cacheMetadata, cache, dispatch]);

  // Format metadata for display
  const formatMetadata = useCallback((metadata) => {
    return {
      title: metadata.title || 'Unknown Title',
      artist: metadata.artist || 'Unknown Artist',
      album: metadata.album || 'Unknown Album',
      year: metadata.year || '',
      genre: metadata.genre || 'Unknown Genre',
      duration: metadata.duration ? formatDuration(metadata.duration) : '0:00',
      bitrate: metadata.bitrate ? `${Math.round(metadata.bitrate / 1000)} kbps` : '',
      format: metadata.format || '',
    };
  }, []);

  // Format duration helper
  const formatDuration = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return {
    loading,
    error,
    extractMetadata,
    updateMetadata,
    getMetadata,
    formatMetadata,
    MetadataTypes,
  };
};

/**
 * Hook for handling album artwork
 */
export const useArtwork = (options = {}) => {
  const metadata = useMetadata(options);

  const extractArtwork = useCallback(async (file) => {
    try {
      const metadataResult = await metadata.extractMetadata(file);
      return metadataResult.picture?.[0] || null;
    } catch (error) {
      console.error('Artwork extraction error:', error);
      return null;
    }
  }, [metadata]);

  return {
    ...metadata,
    extractArtwork,
  };
};

/**
 * Hook for handling lyrics
 */
export const useLyrics = (options = {}) => {
  const metadata = useMetadata(options);

  const extractLyrics = useCallback(async (file) => {
    try {
      const metadataResult = await metadata.extractMetadata(file);
      return metadataResult.lyrics || null;
    } catch (error) {
      console.error('Lyrics extraction error:', error);
      return null;
    }
  }, [metadata]);

  return {
    ...metadata,
    extractLyrics,
  };
};

export default useMetadata;
