import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { io } from 'socket.io-client';
import { showErrorSnackbar } from '../store/slices/uiSlice';
import { updatePlaylist } from '../store/slices/playlistSlice';
import { updateMusic } from '../store/slices/musicSlice';

const SocketContext = createContext(null);

export const SocketProvider = ({ children }) => {
  const dispatch = useDispatch();
  const auth = useSelector(state => state.auth || {});
  const { isAuthenticated, user } = auth;
  const [socket, setSocket] = useState(null);
  const [isConnected, setIsConnected] = useState(false);

  // Initialize socket connection
  useEffect(() => {
    if (isAuthenticated && user) {
      const newSocket = io(process.env.REACT_APP_SOCKET_URL || 'http://localhost:5000', {
        auth: {
          token: localStorage.getItem('jwtToken'),
        },
        transports: ['websocket'],
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000,
      });

      setSocket(newSocket);

      return () => {
        newSocket.close();
      };
    }
  }, [isAuthenticated, user]);

  // Socket event listeners
  useEffect(() => {
    if (!socket) return;

    // Connection events
    socket.on('connect', () => {
      setIsConnected(true);
      console.log('Socket connected');
    });

    socket.on('disconnect', () => {
      setIsConnected(false);
      console.log('Socket disconnected');
    });

    socket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
      dispatch(showErrorSnackbar('Error connecting to real-time updates'));
    });

    // Playlist events
    socket.on('playlistUpdated', (data) => {
      dispatch(updatePlaylist(data));
    });

    socket.on('trackAdded', (data) => {
      dispatch(updatePlaylist(data));
    });

    socket.on('trackRemoved', (data) => {
      dispatch(updatePlaylist(data));
    });

    socket.on('trackReordered', (data) => {
      dispatch(updatePlaylist(data));
    });

    // Music events
    socket.on('musicUpdated', (data) => {
      dispatch(updateMusic(data));
    });

    // User presence events
    socket.on('userOnline', (data) => {
      console.log('User online:', data);
      // Handle user online status
    });

    socket.on('userOffline', (data) => {
      console.log('User offline:', data);
      // Handle user offline status
    });

    // Cleanup
    return () => {
      socket.off('connect');
      socket.off('disconnect');
      socket.off('connect_error');
      socket.off('playlistUpdated');
      socket.off('trackAdded');
      socket.off('trackRemoved');
      socket.off('trackReordered');
      socket.off('musicUpdated');
      socket.off('userOnline');
      socket.off('userOffline');
    };
  }, [socket, dispatch]);

  // Join room (e.g., for playlist collaboration)
  const joinRoom = useCallback((roomId) => {
    if (socket && isConnected) {
      socket.emit('joinRoom', roomId);
    }
  }, [socket, isConnected]);

  // Leave room
  const leaveRoom = useCallback((roomId) => {
    if (socket && isConnected) {
      socket.emit('leaveRoom', roomId);
    }
  }, [socket, isConnected]);

  // Send playlist update
  const emitPlaylistUpdate = useCallback((playlistId, action, data) => {
    if (socket && isConnected) {
      socket.emit('playlistUpdate', {
        playlistId,
        action,
        data,
        userId: user?.id,
      });
    }
  }, [socket, isConnected, user]);

  // Send track play event
  const emitTrackPlay = useCallback((trackId, playlistId = null) => {
    if (socket && isConnected) {
      socket.emit('trackPlay', {
        trackId,
        playlistId,
        userId: user?.id,
      });
    }
  }, [socket, isConnected, user]);

  // Send user status update
  const updateUserStatus = useCallback((status) => {
    if (socket && isConnected) {
      socket.emit('userStatus', status);
    }
  }, [socket, isConnected]);

  // Send typing indicator for chat
  const emitTyping = useCallback((roomId) => {
    if (socket && isConnected) {
      socket.emit('typing', {
        roomId,
        username: user?.username,
      });
    }
  }, [socket, isConnected, user]);

  // Send chat message
  const sendMessage = useCallback((roomId, message) => {
    if (socket && isConnected) {
      socket.emit('chatMessage', {
        roomId,
        message,
        userId: user?.id,
        username: user?.username,
      });
    }
  }, [socket, isConnected, user]);

  const value = {
    socket,
    isConnected,
    joinRoom,
    leaveRoom,
    emitPlaylistUpdate,
    emitTrackPlay,
    updateUserStatus,
    emitTyping,
    sendMessage,
  };

  return (
    <SocketContext.Provider value={value}>
      {children}
    </SocketContext.Provider>
  );
};

// Custom hook to use socket context
export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
};

// HOC to inject socket functionality
export const withSocket = (WrappedComponent) => {
  return function WithSocketComponent(props) {
    const socket = useSocket();
    return <WrappedComponent {...props} socket={socket} />;
  };
};

// Custom hook for real-time collaboration
export const useCollaboration = (roomId) => {
  const { joinRoom, leaveRoom, emitPlaylistUpdate, socket } = useSocket();
  const [collaborators, setCollaborators] = useState([]);
  const [typingUsers, setTypingUsers] = useState([]);

  useEffect(() => {
    if (roomId) {
      joinRoom(roomId);

      if (socket) {
        socket.on('collaboratorJoined', (user) => {
          setCollaborators((prev) => [...prev, user]);
        });

        socket.on('collaboratorLeft', (userId) => {
          setCollaborators((prev) => prev.filter((u) => u.id !== userId));
        });

        socket.on('userTyping', (username) => {
          setTypingUsers((prev) => [...prev, username]);
          setTimeout(() => {
            setTypingUsers((prev) => prev.filter((u) => u !== username));
          }, 2000);
        });
      }

      return () => {
        leaveRoom(roomId);
        if (socket) {
          socket.off('collaboratorJoined');
          socket.off('collaboratorLeft');
          socket.off('userTyping');
        }
      };
    }
  }, [roomId, joinRoom, leaveRoom, socket]);

  return {
    collaborators,
    typingUsers,
    updatePlaylist: (action, data) => emitPlaylistUpdate(roomId, action, data),
  };
};

export default SocketContext;
