import React, { createContext, useContext, useEffect, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { 
  login, 
  register, 
  logout, 
  updateProfile, 
  updatePassword,
  checkAuthToken 
} from '../store/slices/authSlice';
import { showSuccessSnackbar, showErrorSnackbar } from '../store/slices/uiSlice';
import { isValidEmail, checkPasswordStrength } from '../utils/auth';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { user, isAuthenticated, loading, error } = useSelector((state) => state.auth);

  // Initialize authentication state
  useEffect(() => {
    dispatch(checkAuthToken());
  }, [dispatch]);

  // Handle user registration
  const handleRegister = useCallback(async (userData) => {
    try {
      // Validate email
      if (!isValidEmail(userData.email)) {
        dispatch(showErrorSnackbar('Please enter a valid email address'));
        return false;
      }

      // Check password strength
      const passwordCheck = checkPasswordStrength(userData.password);
      if (!passwordCheck.isStrong) {
        dispatch(showErrorSnackbar(passwordCheck.message));
        return false;
      }

      const result = await dispatch(register(userData)).unwrap();
      dispatch(showSuccessSnackbar('Registration successful! Welcome!'));
      history.push('/');
      return true;
    } catch (error) {
      dispatch(showErrorSnackbar(error.message || 'Registration failed'));
      return false;
    }
  }, [dispatch, history]);

  // Handle user login
  const handleLogin = useCallback(async (credentials) => {
    try {
      await dispatch(login(credentials)).unwrap();
      dispatch(showSuccessSnackbar('Welcome back!'));
      history.push('/');
      return true;
    } catch (error) {
      dispatch(showErrorSnackbar(error.message || 'Login failed'));
      return false;
    }
  }, [dispatch, history]);

  // Handle user logout
  const handleLogout = useCallback(async () => {
    try {
      await dispatch(logout()).unwrap();
      dispatch(showSuccessSnackbar('Logged out successfully'));
      history.push('/login');
    } catch (error) {
      dispatch(showErrorSnackbar('Error logging out'));
    }
  }, [dispatch, history]);

  // Handle profile update
  const handleUpdateProfile = useCallback(async (profileData) => {
    try {
      await dispatch(updateProfile(profileData)).unwrap();
      dispatch(showSuccessSnackbar('Profile updated successfully'));
      return true;
    } catch (error) {
      dispatch(showErrorSnackbar(error.message || 'Failed to update profile'));
      return false;
    }
  }, [dispatch]);

  // Handle password update
  const handleUpdatePassword = useCallback(async (passwordData) => {
    try {
      // Validate new password
      const passwordCheck = checkPasswordStrength(passwordData.newPassword);
      if (!passwordCheck.isStrong) {
        dispatch(showErrorSnackbar(passwordCheck.message));
        return false;
      }

      await dispatch(updatePassword(passwordData)).unwrap();
      dispatch(showSuccessSnackbar('Password updated successfully'));
      return true;
    } catch (error) {
      dispatch(showErrorSnackbar(error.message || 'Failed to update password'));
      return false;
    }
  }, [dispatch]);

  // Check if user has specific role
  const hasRole = useCallback((role) => {
    return user?.role === role;
  }, [user]);

  // Check if user can perform specific action
  const canPerformAction = useCallback((action) => {
    switch (action) {
      case 'upload_music':
        return isAuthenticated && (user?.role === 'admin' || user?.role === 'artist');
      case 'create_playlist':
        return isAuthenticated;
      case 'manage_users':
        return isAuthenticated && user?.role === 'admin';
      default:
        return false;
    }
  }, [isAuthenticated, user]);

  const value = {
    user,
    isAuthenticated,
    loading,
    error,
    register: handleRegister,
    login: handleLogin,
    logout: handleLogout,
    updateProfile: handleUpdateProfile,
    updatePassword: handleUpdatePassword,
    hasRole,
    canPerformAction,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// HOC to protect routes
export const withAuth = (WrappedComponent, requiredRole = null) => {
  return function WithAuthComponent(props) {
    const { isAuthenticated, hasRole, loading } = useAuth();
    const history = useHistory();

    useEffect(() => {
      if (!loading && !isAuthenticated) {
        history.push('/login');
      }
      if (!loading && requiredRole && !hasRole(requiredRole)) {
        history.push('/');
      }
    }, [loading, isAuthenticated, hasRole, history]);

    if (loading) {
      return <div>Loading...</div>; // Replace with your loading component
    }

    if (!isAuthenticated || (requiredRole && !hasRole(requiredRole))) {
      return null;
    }

    return <WrappedComponent {...props} />;
  };
};

export default AuthContext;
