import React, { createContext, useContext, useEffect, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ThemeProvider as MuiThemeProvider, createTheme } from '@mui/material/styles';
import { setThemeMode, setPrimaryColor } from '../store/slices/uiSlice';

const ThemeContext = createContext(null);

// Default theme options
const defaultTheme = {
  light: {
    primary: '#1DB954', // Spotify green
    secondary: '#191414', // Spotify black
    background: {
      default: '#FFFFFF',
      paper: '#F5F5F5',
    },
    text: {
      primary: '#191414',
      secondary: '#666666',
    },
  },
  dark: {
    primary: '#1DB954',
    secondary: '#191414',
    background: {
      default: '#121212',
      paper: '#282828',
    },
    text: {
      primary: '#FFFFFF',
      secondary: '#B3B3B3',
    },
  },
};

export const ThemeProvider = ({ children }) => {
  const dispatch = useDispatch();
  const { mode, primaryColor } = useSelector((state) => state.ui.theme);

  // Initialize theme from localStorage
  useEffect(() => {
    const savedMode = localStorage.getItem('themeMode');
    const savedColor = localStorage.getItem('primaryColor');

    if (savedMode) {
      dispatch(setThemeMode(savedMode));
    }
    if (savedColor) {
      dispatch(setPrimaryColor(savedColor));
    }
  }, [dispatch]);

  // Create theme object
  const theme = useMemo(() => {
    return createTheme({
      palette: {
        mode,
        primary: {
          main: primaryColor || defaultTheme[mode].primary,
          contrastText: '#FFFFFF',
        },
        secondary: {
          main: defaultTheme[mode].secondary,
        },
        background: defaultTheme[mode].background,
        text: defaultTheme[mode].text,
      },
      typography: {
        fontFamily: [
          '-apple-system',
          'BlinkMacSystemFont',
          '"Segoe UI"',
          'Roboto',
          '"Helvetica Neue"',
          'Arial',
          'sans-serif',
        ].join(','),
        h1: {
          fontSize: '2rem',
          fontWeight: 700,
        },
        h2: {
          fontSize: '1.75rem',
          fontWeight: 600,
        },
        h3: {
          fontSize: '1.5rem',
          fontWeight: 600,
        },
        h4: {
          fontSize: '1.25rem',
          fontWeight: 600,
        },
        h5: {
          fontSize: '1.1rem',
          fontWeight: 500,
        },
        h6: {
          fontSize: '1rem',
          fontWeight: 500,
        },
        body1: {
          fontSize: '1rem',
          lineHeight: 1.5,
        },
        body2: {
          fontSize: '0.875rem',
          lineHeight: 1.43,
        },
      },
      shape: {
        borderRadius: 8,
      },
      components: {
        MuiButton: {
          styleOverrides: {
            root: {
              borderRadius: 500,
              textTransform: 'none',
              fontWeight: 600,
              padding: '8px 24px',
            },
            contained: {
              boxShadow: 'none',
              '&:hover': {
                boxShadow: 'none',
              },
            },
          },
        },
        MuiCard: {
          styleOverrides: {
            root: {
              backgroundColor: defaultTheme[mode].background.paper,
              borderRadius: 8,
            },
          },
        },
        MuiTextField: {
          styleOverrides: {
            root: {
              '& .MuiOutlinedInput-root': {
                borderRadius: 8,
              },
            },
          },
        },
        MuiDrawer: {
          styleOverrides: {
            paper: {
              backgroundColor: defaultTheme[mode].background.default,
            },
          },
        },
        MuiAppBar: {
          styleOverrides: {
            root: {
              backgroundColor: defaultTheme[mode].background.paper,
              boxShadow: 'none',
              borderBottom: `1px solid ${mode === 'light' ? '#E0E0E0' : '#404040'}`,
            },
          },
        },
      },
      transitions: {
        duration: {
          shortest: 150,
          shorter: 200,
          short: 250,
          standard: 300,
          complex: 375,
          enteringScreen: 225,
          leavingScreen: 195,
        },
      },
    });
  }, [mode, primaryColor]);

  // Theme toggle function
  const toggleTheme = () => {
    const newMode = mode === 'light' ? 'dark' : 'light';
    dispatch(setThemeMode(newMode));
    localStorage.setItem('themeMode', newMode);
  };

  // Change primary color
  const changePrimaryColor = (color) => {
    dispatch(setPrimaryColor(color));
    localStorage.setItem('primaryColor', color);
  };

  const value = {
    mode,
    primaryColor,
    toggleTheme,
    changePrimaryColor,
    isDark: mode === 'dark',
  };

  return (
    <ThemeContext.Provider value={value}>
      <MuiThemeProvider theme={theme}>
        {children}
      </MuiThemeProvider>
    </ThemeContext.Provider>
  );
};

// Custom hook to use theme context
export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

// HOC to inject theme functionality
export const withTheme = (WrappedComponent) => {
  return function WithThemeComponent(props) {
    const theme = useTheme();
    return <WrappedComponent {...props} theme={theme} />;
  };
};

// Predefined color schemes
export const colorSchemes = {
  spotify: '#1DB954',
  blue: '#2196F3',
  purple: '#9C27B0',
  pink: '#E91E63',
  orange: '#FF5722',
  red: '#F44336',
  teal: '#009688',
  indigo: '#3F51B5',
};

export default ThemeContext;
