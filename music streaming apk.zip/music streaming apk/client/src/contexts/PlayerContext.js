import React, { createContext, useContext, useEffect, useRef, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  play,
  pause,
  setCurrentTrack,
  setQueue,
  nextTrack,
  previousTrack,
  setVolume,
  toggleMute,
  toggleRepeat,
  toggleShuffle,
  setCurrentTime,
  setDuration,
  setAudioElement,
} from '../store/slices/playerSlice';
import { showErrorSnackbar } from '../store/slices/uiSlice';

const PlayerContext = createContext(null);

export const PlayerProvider = ({ children }) => {
  const dispatch = useDispatch();
  const audioRef = useRef(null);
  const {
    currentTrack,
    queue,
    isPlaying,
    volume,
    muted,
    repeat,
    shuffle,
    currentTime,
  } = useSelector((state) => state.player);

  // Initialize audio element
  useEffect(() => {
    if (audioRef.current) {
      dispatch(setAudioElement(audioRef.current));
    }
  }, [dispatch]);

  // Handle track changes
  useEffect(() => {
    if (currentTrack && audioRef.current) {
      audioRef.current.src = currentTrack.audioFile.url;
      if (isPlaying) {
        audioRef.current.play().catch((error) => {
          console.error('Playback error:', error);
          dispatch(showErrorSnackbar('Error playing track'));
        });
      }
    }
  }, [currentTrack, isPlaying, dispatch]);

  // Audio event listeners
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      dispatch(setCurrentTime(audio.currentTime));
    };

    const handleDurationChange = () => {
      dispatch(setDuration(audio.duration));
    };

    const handleEnded = () => {
      dispatch(nextTrack());
    };

    const handleError = (error) => {
      console.error('Audio error:', error);
      dispatch(showErrorSnackbar('Error playing track'));
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('durationchange', handleDurationChange);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('durationchange', handleDurationChange);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
    };
  }, [dispatch]);

  // Player controls
  const handlePlay = useCallback(() => {
    if (!currentTrack) return;
    dispatch(play());
  }, [currentTrack, dispatch]);

  const handlePause = useCallback(() => {
    dispatch(pause());
  }, [dispatch]);

  const handleTogglePlay = useCallback(() => {
    if (isPlaying) {
      handlePause();
    } else {
      handlePlay();
    }
  }, [isPlaying, handlePlay, handlePause]);

  const handleNext = useCallback(() => {
    dispatch(nextTrack());
  }, [dispatch]);

  const handlePrevious = useCallback(() => {
    dispatch(previousTrack());
  }, [dispatch]);

  const handleSeek = useCallback((time) => {
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      dispatch(setCurrentTime(time));
    }
  }, [dispatch]);

  const handleVolumeChange = useCallback((newVolume) => {
    dispatch(setVolume(newVolume));
  }, [dispatch]);

  const handleToggleMute = useCallback(() => {
    dispatch(toggleMute());
  }, [dispatch]);

  const handleToggleRepeat = useCallback(() => {
    dispatch(toggleRepeat());
  }, [dispatch]);

  const handleToggleShuffle = useCallback(() => {
    dispatch(toggleShuffle());
  }, [dispatch]);

  // Queue management
  const playTrack = useCallback((track, newQueue = null) => {
    if (newQueue) {
      dispatch(setQueue(newQueue));
    }
    dispatch(setCurrentTrack(track));
    dispatch(play());
  }, [dispatch]);

  const addToQueue = useCallback((track) => {
    dispatch(setQueue([...queue, track]));
  }, [queue, dispatch]);

  const clearQueue = useCallback(() => {
    dispatch(setQueue([]));
  }, [dispatch]);

  // Format time helper
  const formatTime = useCallback((timeInSeconds) => {
    if (!timeInSeconds) return '0:00';
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }, []);

  const value = {
    // Player state
    currentTrack,
    queue,
    isPlaying,
    volume,
    muted,
    repeat,
    shuffle,
    currentTime,
    duration: audioRef.current?.duration || 0,

    // Player controls
    play: handlePlay,
    pause: handlePause,
    togglePlay: handleTogglePlay,
    next: handleNext,
    previous: handlePrevious,
    seek: handleSeek,
    setVolume: handleVolumeChange,
    toggleMute: handleToggleMute,
    toggleRepeat: handleToggleRepeat,
    toggleShuffle: handleToggleShuffle,

    // Queue management
    playTrack,
    addToQueue,
    clearQueue,

    // Utilities
    formatTime,
  };

  return (
    <PlayerContext.Provider value={value}>
      <audio ref={audioRef} preload="metadata" />
      {children}
    </PlayerContext.Provider>
  );
};

// Custom hook to use player context
export const usePlayer = () => {
  const context = useContext(PlayerContext);
  if (!context) {
    throw new Error('usePlayer must be used within a PlayerProvider');
  }
  return context;
};

// HOC to inject player functionality
export const withPlayer = (WrappedComponent) => {
  return function WithPlayerComponent(props) {
    const playerContext = usePlayer();
    return <WrappedComponent {...props} player={playerContext} />;
  };
};

export default PlayerContext;
