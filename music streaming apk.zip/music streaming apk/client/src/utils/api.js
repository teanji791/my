import axios from 'axios';
import store from '../store';
import { logout } from '../store/slices/authSlice';
import { showErrorSnackbar } from '../store/slices/uiSlice';

// Create axios instance with default config
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:3000/api',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true,
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      // Handle 401 Unauthorized errors
      if (error.response.status === 401) {
        store.dispatch(logout());
      }

      // Show error message
      const errorMessage = error.response.data.message || 'An error occurred';
      store.dispatch(showErrorSnackbar(errorMessage));
    } else if (error.request) {
      // Network error
      store.dispatch(showErrorSnackbar('Network error. Please check your connection.'));
    } else {
      // Other errors
      store.dispatch(showErrorSnackbar('An unexpected error occurred.'));
    }
    return Promise.reject(error);
  }
);

// Auth API calls
export const authAPI = {
  register: (userData) => api.post('/auth/register', userData),
  login: (credentials) => api.post('/auth/login', credentials),
  logout: () => api.get('/auth/logout'),
  getProfile: () => api.get('/auth/me'),
  updateProfile: (data) => api.put('/auth/updatedetails', data),
  updatePassword: (data) => api.put('/auth/updatepassword', data),
  uploadAvatar: (formData) => api.put('/auth/uploadavatar', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  }),
};

// Music API calls
export const musicAPI = {
  getAllMusic: (params) => api.get('/music', { params }),
  getMusic: (id) => api.get(`/music/${id}`),
  searchMusic: (query) => api.get(`/music/search?q=${query}`),
  uploadMusic: (formData) => api.post('/music', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: (progressEvent) => {
      const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
      // You can dispatch an action here to update upload progress
      // store.dispatch(setUploadProgress(percentCompleted));
    },
  }),
  updateMusic: (id, data) => api.put(`/music/${id}`, data),
  deleteMusic: (id) => api.delete(`/music/${id}`),
  toggleLike: (id) => api.put(`/music/${id}/like`),
  streamMusic: (id) => api.get(`/music/${id}/stream`),
};

// Playlist API calls
export const playlistAPI = {
  getAllPlaylists: () => api.get('/playlists'),
  getUserPlaylists: () => api.get('/playlists/me'),
  getPlaylist: (id) => api.get(`/playlists/${id}`),
  createPlaylist: (data) => api.post('/playlists', data),
  updatePlaylist: (id, data) => api.put(`/playlists/${id}`, data),
  deletePlaylist: (id) => api.delete(`/playlists/${id}`),
  addTrack: (playlistId, trackId) => api.post(`/playlists/${playlistId}/tracks`, { musicId: trackId }),
  removeTrack: (playlistId, trackId) => api.delete(`/playlists/${playlistId}/tracks/${trackId}`),
  reorderTracks: (playlistId, data) => api.put(`/playlists/${playlistId}/tracks/reorder`, data),
  toggleFollow: (id) => api.put(`/playlists/${id}/follow`),
  addCollaborator: (playlistId, userId, role) => 
    api.post(`/playlists/${playlistId}/collaborators`, { userId, role }),
  removeCollaborator: (playlistId, userId) => 
    api.delete(`/playlists/${playlistId}/collaborators/${userId}`),
};

// Upload helpers
export const uploadHelpers = {
  validateAudioFile: (file) => {
    const validTypes = ['audio/mpeg', 'audio/wav', 'audio/ogg'];
    const maxSize = 20 * 1024 * 1024; // 20MB

    if (!validTypes.includes(file.type)) {
      throw new Error('Invalid file type. Please upload MP3, WAV, or OGG files.');
    }

    if (file.size > maxSize) {
      throw new Error('File size too large. Maximum size is 20MB.');
    }

    return true;
  },

  validateImageFile: (file) => {
    const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    const maxSize = 2 * 1024 * 1024; // 2MB

    if (!validTypes.includes(file.type)) {
      throw new Error('Invalid file type. Please upload JPEG, PNG, or WebP images.');
    }

    if (file.size > maxSize) {
      throw new Error('File size too large. Maximum size is 2MB.');
    }

    return true;
  },
};

// Error handler helper
export const handleApiError = (error) => {
  if (error.response) {
    // Server responded with error
    return {
      message: error.response.data.message || 'Server error occurred',
      status: error.response.status,
      data: error.response.data,
    };
  } else if (error.request) {
    // Request made but no response
    return {
      message: 'No response from server',
      status: 0,
      data: null,
    };
  } else {
    // Error setting up request
    return {
      message: error.message || 'Error occurred',
      status: 0,
      data: null,
    };
  }
};

// Utility function to format query parameters
export const formatQueryParams = (params) => {
  const queryParams = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== '') {
      queryParams.append(key, value);
    }
  });
  return queryParams.toString();
};

// Export the axios instance for direct use if needed
export default api;
