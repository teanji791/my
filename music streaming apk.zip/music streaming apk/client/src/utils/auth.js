import { jwtDecode } from 'jwt-decode';
import store from '../store';
import { logout, setUser } from '../store/slices/authSlice';
import { showErrorSnackbar } from '../store/slices/uiSlice';
import api from './api';

/**
 * Set authentication token in localStorage and axios headers
 * @param {string} token - JWT token
 */
export const setAuthToken = (token) => {
  if (token) {
    localStorage.setItem('jwtToken', token);
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  } else {
    localStorage.removeItem('jwtToken');
    delete api.defaults.headers.common['Authorization'];
  }
};

/**
 * Check if the current token is valid
 * @returns {boolean} - Token validity status
 */
export const isTokenValid = () => {
  const token = localStorage.getItem('jwtToken');
  if (!token) return false;

  try {
    const decoded = jwtDecode(token);
    const currentTime = Date.now() / 1000;

    if (decoded.exp < currentTime) {
      store.dispatch(logout());
      return false;
    }

    return true;
  } catch (error) {
    console.error('Token validation error:', error);
    store.dispatch(logout());
    return false;
  }
};

/**
 * Initialize authentication state from token
 */
export const initializeAuth = () => {
  try {
    const token = localStorage.getItem('jwtToken');
    if (token) {
      const decoded = jwtDecode(token);
      const currentTime = Date.now() / 1000;

      if (decoded.exp < currentTime) {
        store.dispatch(logout());
        store.dispatch(showErrorSnackbar('Session expired. Please login again.'));
      } else {
        setAuthToken(token);
        store.dispatch(setUser(decoded));
      }
    }
  } catch (error) {
    console.error('Auth initialization error:', error);
    store.dispatch(logout());
  }
};

/**
 * Get user role from token
 * @returns {string|null} - User role or null if not authenticated
 */
export const getUserRole = () => {
  try {
    const token = localStorage.getItem('jwtToken');
    if (!token) return null;

    const decoded = jwtDecode(token);
    return decoded.role;
  } catch (error) {
    console.error('Get user role error:', error);
    return null;
  }
};

/**
 * Check if user has required role
 * @param {string|string[]} requiredRoles - Required role(s)
 * @returns {boolean} - Authorization status
 */
export const hasRole = (requiredRoles) => {
  const userRole = getUserRole();
  if (!userRole) return false;

  if (Array.isArray(requiredRoles)) {
    return requiredRoles.includes(userRole);
  }
  return requiredRoles === userRole;
};

/**
 * Get user ID from token
 * @returns {string|null} - User ID or null if not authenticated
 */
export const getUserId = () => {
  try {
    const token = localStorage.getItem('jwtToken');
    if (!token) return null;

    const decoded = jwtDecode(token);
    return decoded.id;
  } catch (error) {
    console.error('Get user ID error:', error);
    return null;
  }
};

/**
 * Check if user owns a resource
 * @param {string} resourceUserId - User ID of the resource owner
 * @returns {boolean} - Ownership status
 */
export const isResourceOwner = (resourceUserId) => {
  const userId = getUserId();
  return userId === resourceUserId;
};

/**
 * Check if user can edit a resource
 * @param {Object} resource - Resource object with owner and collaborators
 * @returns {boolean} - Edit permission status
 */
export const canEditResource = (resource) => {
  const userId = getUserId();
  if (!userId) return false;

  // Check if user is admin
  if (hasRole('admin')) return true;

  // Check if user is owner
  if (resource.owner === userId) return true;

  // Check if user is collaborator with edit rights
  if (resource.collaborators) {
    return resource.collaborators.some(
      (collab) => collab.user === userId && collab.role === 'editor'
    );
  }

  return false;
};

/**
 * Parse error message from API response
 * @param {Error} error - Error object
 * @returns {string} - Formatted error message
 */
export const parseAuthError = (error) => {
  if (error.response) {
    return error.response.data.message || 'Authentication failed';
  }
  return error.message || 'An error occurred during authentication';
};

/**
 * Format validation errors
 * @param {Object} errors - Validation errors object
 * @returns {Object} - Formatted errors object
 */
export const formatValidationErrors = (errors) => {
  const formattedErrors = {};
  Object.keys(errors).forEach((key) => {
    formattedErrors[key] = errors[key].message;
  });
  return formattedErrors;
};

/**
 * Check password strength
 * @param {string} password - Password to check
 * @returns {Object} - Password strength status and message
 */
export const checkPasswordStrength = (password) => {
  const result = {
    isStrong: false,
    message: '',
  };

  if (password.length < 8) {
    result.message = 'Password must be at least 8 characters long';
    return result;
  }

  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumbers = /\d/.test(password);
  const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

  const strength = [hasUpperCase, hasLowerCase, hasNumbers, hasSpecialChar]
    .filter(Boolean).length;

  if (strength < 3) {
    result.message = 'Password must contain at least 3 of the following: uppercase letters, lowercase letters, numbers, special characters';
    return result;
  }

  result.isStrong = true;
  result.message = 'Password is strong';
  return result;
};

/**
 * Validate email format
 * @param {string} email - Email to validate
 * @returns {boolean} - Email validity status
 */
export const isValidEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Clean up auth state on logout
 */
export const cleanupAuth = () => {
  setAuthToken(null);
};

export default {
  setAuthToken,
  isTokenValid,
  initializeAuth,
  getUserRole,
  hasRole,
  getUserId,
  isResourceOwner,
  canEditResource,
  parseAuthError,
  formatValidationErrors,
  checkPasswordStrength,
  isValidEmail,
  cleanupAuth,
};
