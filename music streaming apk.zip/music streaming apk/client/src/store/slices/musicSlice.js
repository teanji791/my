import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Async thunks
export const fetchAllMusic = createAsyncThunk(
  'music/fetchAllMusic',
  async ({ page = 1, limit = 20, filters = {} }, { rejectWithValue }) => {
    try {
      const queryParams = new URLSearchParams({
        page,
        limit,
        ...filters,
      });
      const response = await axios.get(`/api/music?${queryParams}`);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const searchMusic = createAsyncThunk(
  'music/searchMusic',
  async (searchQuery, { rejectWithValue }) => {
    try {
      const response = await axios.get(`/api/music/search?q=${searchQuery}`);
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const uploadMusic = createAsyncThunk(
  'music/uploadMusic',
  async (musicData, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      Object.keys(musicData).forEach(key => {
        if (key === 'audioFile' || key === 'coverImage') {
          formData.append(key, musicData[key]);
        } else {
          formData.append(key, JSON.stringify(musicData[key]));
        }
      });

      const response = await axios.post('/api/music', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const updateMusic = createAsyncThunk(
  'music/updateMusic',
  async ({ musicId, updateData }, { rejectWithValue }) => {
    try {
      const response = await axios.put(`/api/music/${musicId}`, updateData);
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const deleteMusic = createAsyncThunk(
  'music/deleteMusic',
  async (musicId, { rejectWithValue }) => {
    try {
      await axios.delete(`/api/music/${musicId}`);
      return musicId;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const toggleLike = createAsyncThunk(
  'music/toggleLike',
  async (musicId, { rejectWithValue }) => {
    try {
      const response = await axios.put(`/api/music/${musicId}/like`);
      return {
        musicId,
        liked: response.data.liked,
      };
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const initialState = {
  music: [],
  searchResults: [],
  currentPage: 1,
  totalPages: 1,
  totalItems: 0,
  loading: false,
  error: null,
  filters: {
    genre: null,
    artist: null,
    year: null,
  },
  uploadProgress: 0,
  genres: [
    'Pop',
    'Rock',
    'Hip Hop',
    'Jazz',
    'Classical',
    'Electronic',
    'R&B',
    'Country',
    'Folk',
    'Blues',
  ],
};

const musicSlice = createSlice({
  name: 'music',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    setFilters: (state, action) => {
      state.filters = {
        ...state.filters,
        ...action.payload,
      };
    },
    clearFilters: (state) => {
      state.filters = initialState.filters;
    },
    setUploadProgress: (state, action) => {
      state.uploadProgress = action.payload;
    },
    clearSearchResults: (state) => {
      state.searchResults = [];
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch all music
      .addCase(fetchAllMusic.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAllMusic.fulfilled, (state, action) => {
        state.loading = false;
        state.music = action.payload.data;
        state.currentPage = action.payload.currentPage;
        state.totalPages = action.payload.totalPages;
        state.totalItems = action.payload.totalItems;
      })
      .addCase(fetchAllMusic.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || 'Failed to fetch music';
      })

      // Search music
      .addCase(searchMusic.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(searchMusic.fulfilled, (state, action) => {
        state.loading = false;
        state.searchResults = action.payload;
      })
      .addCase(searchMusic.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || 'Search failed';
      })

      // Upload music
      .addCase(uploadMusic.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.uploadProgress = 0;
      })
      .addCase(uploadMusic.fulfilled, (state, action) => {
        state.loading = false;
        state.music.unshift(action.payload);
        state.uploadProgress = 100;
      })
      .addCase(uploadMusic.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || 'Upload failed';
        state.uploadProgress = 0;
      })

      // Update music
      .addCase(updateMusic.fulfilled, (state, action) => {
        const updatedMusic = action.payload;
        state.music = state.music.map((track) =>
          track._id === updatedMusic._id ? updatedMusic : track
        );
      })

      // Delete music
      .addCase(deleteMusic.fulfilled, (state, action) => {
        const musicId = action.payload;
        state.music = state.music.filter((track) => track._id !== musicId);
      })

      // Toggle like
      .addCase(toggleLike.fulfilled, (state, action) => {
        const { musicId, liked } = action.payload;
        state.music = state.music.map((track) =>
          track._id === musicId
            ? {
                ...track,
                isLiked: liked,
                stats: {
                  ...track.stats,
                  likes: liked
                    ? track.stats.likes + 1
                    : track.stats.likes - 1,
                },
              }
            : track
        );
      });
  },
});

// Selectors
export const selectAllMusic = (state) => state.music.music;
export const selectSearchResults = (state) => state.music.searchResults;
export const selectMusicLoading = (state) => state.music.loading;
export const selectMusicError = (state) => state.music.error;
export const selectMusicFilters = (state) => state.music.filters;
export const selectUploadProgress = (state) => state.music.uploadProgress;
export const selectGenres = (state) => state.music.genres;
export const selectPagination = (state) => ({
  currentPage: state.music.currentPage,
  totalPages: state.music.totalPages,
  totalItems: state.music.totalItems,
});

export const {
  clearError,
  setFilters,
  clearFilters,
  setUploadProgress,
  clearSearchResults,
} = musicSlice.actions;

export default musicSlice.reducer;
