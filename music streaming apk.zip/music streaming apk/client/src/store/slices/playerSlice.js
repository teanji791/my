import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Async thunks
export const fetchTrackData = createAsyncThunk(
  'player/fetchTrackData',
  async (trackId, { rejectWithValue }) => {
    try {
      const response = await axios.get(`/api/music/${trackId}`);
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const updatePlayCount = createAsyncThunk(
  'player/updatePlayCount',
  async (trackId, { rejectWithValue }) => {
    try {
      await axios.post(`/api/music/${trackId}/play`);
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const initialState = {
  currentTrack: null,
  queue: [],
  queueIndex: 0,
  isPlaying: false,
  volume: 1,
  muted: false,
  repeat: 'none', // none, one, all
  shuffle: false,
  shuffledQueue: [],
  duration: 0,
  currentTime: 0,
  loading: false,
  error: null,
};

const playerSlice = createSlice({
  name: 'player',
  initialState,
  reducers: {
    setCurrentTrack: (state, action) => {
      state.currentTrack = action.payload;
      state.currentTime = 0;
    },
    play: (state) => {
      state.isPlaying = true;
    },
    pause: (state) => {
      state.isPlaying = false;
    },
    nextTrack: (state) => {
      const queue = state.shuffle ? state.shuffledQueue : state.queue;
      if (state.repeat === 'one') {
        state.currentTime = 0;
        return;
      }
      if (state.queueIndex < queue.length - 1) {
        state.queueIndex++;
        state.currentTrack = queue[state.queueIndex];
        state.currentTime = 0;
      } else if (state.repeat === 'all') {
        state.queueIndex = 0;
        state.currentTrack = queue[0];
        state.currentTime = 0;
      }
    },
    previousTrack: (state) => {
      const queue = state.shuffle ? state.shuffledQueue : state.queue;
      if (state.queueIndex > 0) {
        state.queueIndex--;
        state.currentTrack = queue[state.queueIndex];
        state.currentTime = 0;
      }
    },
    // Other reducers...
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTrackData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTrackData.fulfilled, (state, action) => {
        state.loading = false;
        state.currentTrack = action.payload;
      })
      .addCase(fetchTrackData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || 'Failed to fetch track data';
      });
  },
});

// Selectors remain unchanged

export const {
  setCurrentTrack,
  play,
  pause,
  nextTrack,
  previousTrack,
  // Other actions...
} = playerSlice.actions;

export default playerSlice.reducer;
