import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  snackbar: {
    open: false,
    message: '',
    severity: 'info', // 'error', 'warning', 'info', 'success'
  },
  loading: false,
  theme: 'dark',
};

const uiSlice = createSlice({
  name: 'ui',
  initialState,
  reducers: {
    showSnackbar: (state, action) => {
      state.snackbar = {
        open: true,
        message: action.payload.message,
        severity: action.payload.severity || 'info',
      };
    },
    hideSnackbar: (state) => {
      state.snackbar.open = false;
    },
    showErrorSnackbar: (state, action) => {
      state.snackbar = {
        open: true,
        message: action.payload,
        severity: 'error',
      };
    },
    showSuccessSnackbar: (state, action) => {
      state.snackbar = {
        open: true,
        message: action.payload,
        severity: 'success',
      };
    },
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    toggleTheme: (state) => {
      state.theme = state.theme === 'light' ? 'dark' : 'light';
    },
  },
});

export const {
  showSnackbar,
  hideSnackbar,
  showErrorSnackbar,
  showSuccessSnackbar,
  setLoading,
  toggleTheme,
} = uiSlice.actions;

export default uiSlice.reducer;
