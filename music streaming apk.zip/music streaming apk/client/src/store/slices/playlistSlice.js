import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { playlistAPI } from '../../utils/api';

// Async thunks
export const fetchUserPlaylists = createAsyncThunk(
  'playlists/fetchUserPlaylists',
  async (_, { rejectWithValue }) => {
    try {
      const response = await playlistAPI.getUserPlaylists();
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || { message: 'Failed to fetch playlists' });
    }
  }
);

export const fetchPlaylistDetails = createAsyncThunk(
  'playlists/fetchPlaylistDetails',
  async (playlistId, { rejectWithValue }) => {
    try {
      const response = await playlistAPI.getPlaylist(playlistId);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || { message: 'Failed to fetch playlist details' });
    }
  }
);

export const updatePlaylist = createAsyncThunk(
  'playlists/updatePlaylist',
  async ({ playlistId, updateData }, { rejectWithValue }) => {
    try {
      const response = await playlistAPI.updatePlaylist(playlistId, updateData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || { message: 'Failed to update playlist' });
    }
  }
);

const initialState = {
  publicPlaylists: [],
  userPlaylists: [],
  currentPlaylist: null,
  loading: false,
  error: null,
  lastFetched: null,
};

const playlistSlice = createSlice({
  name: 'playlists',
  initialState,
  reducers: {
    setPublicPlaylists: (state, action) => {
      state.publicPlaylists = action.payload;
    },
    setUserPlaylists: (state, action) => {
      state.userPlaylists = action.payload;
    },
    setCurrentPlaylist: (state, action) => {
      state.currentPlaylist = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch user playlists
      .addCase(fetchUserPlaylists.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUserPlaylists.fulfilled, (state, action) => {
        state.loading = false;
        state.userPlaylists = action.payload;
        state.lastFetched = Date.now();
      })
      .addCase(fetchUserPlaylists.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || 'Failed to fetch playlists';
      })
      // Fetch playlist details
      .addCase(fetchPlaylistDetails.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchPlaylistDetails.fulfilled, (state, action) => {
        state.loading = false;
        state.currentPlaylist = action.payload;
      })
      .addCase(fetchPlaylistDetails.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || 'Failed to fetch playlist details';
      })
      // Update playlist
      .addCase(updatePlaylist.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updatePlaylist.fulfilled, (state, action) => {
        state.loading = false;
        const updatedPlaylist = action.payload;
        state.userPlaylists = state.userPlaylists.map(playlist =>
          playlist.id === updatedPlaylist.id ? updatedPlaylist : playlist
        );
        if (state.currentPlaylist?.id === updatedPlaylist.id) {
          state.currentPlaylist = updatedPlaylist;
        }
      })
      .addCase(updatePlaylist.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || 'Failed to update playlist';
      });
  },
});

export const {
  setPublicPlaylists,
  setUserPlaylists,
  setCurrentPlaylist,
  clearError,
} = playlistSlice.actions;

// Selectors
export const selectPublicPlaylists = (state) => state.playlists.publicPlaylists;
export const selectUserPlaylists = (state) => state.playlists.userPlaylists;
export const selectCurrentPlaylist = (state) => state.playlists.currentPlaylist;
export const selectPlaylistsLoading = (state) => state.playlists.loading;
export const selectPlaylistsError = (state) => state.playlists.error;

export default playlistSlice.reducer;
