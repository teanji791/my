import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import playerReducer from './slices/playerSlice';
import playlistReducer from './slices/playlistSlice';
import musicReducer from './slices/musicSlice';
import uiReducer from './slices/uiSlice';

// Create store with reducers
const store = configureStore({
  reducer: {
    auth: authReducer,
    player: playerReducer,
    playlists: playlistReducer, // Ensure this key matches the slice name
    music: musicReducer,
    ui: uiReducer,
  },
});

export default store;
