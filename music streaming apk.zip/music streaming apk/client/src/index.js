import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import './styles/index.css';
import App from './App';
import store from './store';
import { checkAuthToken } from './store/slices/authSlice';

// Initialize authentication state before rendering
store.dispatch(checkAuthToken());

ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);
