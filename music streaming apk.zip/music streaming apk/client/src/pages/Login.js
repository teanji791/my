import React from 'react';
import { Container, Paper, Typography, Box } from '@mui/material';
import LoginForm from '../components/LoginForm';
import { Redirect } from 'react-router-dom';
import { useSelector } from 'react-redux';

const Login = () => {
  const isAuthenticated = useSelector(state => state.auth.isAuthenticated);

  if (isAuthenticated) {
    return <Redirect to="/" />;
  }

  return (
    <Container maxWidth="sm">
      <Box
        sx={{
          marginTop: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Paper
          elevation={3}
          sx={{
            padding: 4,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            width: '100%',
          }}
        >
          <Typography component="h1" variant="h5" gutterBottom>
            Sign In
          </Typography>
          <LoginForm />
        </Paper>
      </Box>
    </Container>
  );
};

export default Login;
