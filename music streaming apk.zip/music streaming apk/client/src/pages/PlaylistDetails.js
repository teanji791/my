import React, { useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  List, 
  ListItem, 
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Paper,
  Button
} from '@mui/material';
import { useParams } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';

const PlaylistDetails = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const playlist = useSelector(state => state.playlists.items.find(p => p.id === id));
  const isLoading = useSelector(state => state.playlists.isLoading);
  const error = useSelector(state => state.playlists.error);

  useEffect(() => {
    if (id) {
      // TODO: Dispatch action to fetch playlist details
    }
  }, [id, dispatch]);

  if (isLoading) {
    return (
      <Container>
        <Box sx={{ mt: 4, textAlign: 'center' }}>
          <Typography>Loading playlist...</Typography>
        </Box>
      </Container>
    );
  }

  if (error) {
    return (
      <Container>
        <Box sx={{ mt: 4, textAlign: 'center' }}>
          <Typography color="error">Error: {error}</Typography>
        </Box>
      </Container>
    );
  }

  if (!playlist) {
    return (
      <Container>
        <Box sx={{ mt: 4, textAlign: 'center' }}>
          <Typography>Playlist not found</Typography>
        </Box>
      </Container>
    );
  }

  return (
    <Container>
      <Box sx={{ mt: 4 }}>
        <Paper sx={{ p: 3, mb: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <div>
              <Typography variant="h4" gutterBottom>
                {playlist.name}
              </Typography>
              <Typography variant="subtitle1" color="textSecondary">
                Created by {playlist.creator}
              </Typography>
              <Typography variant="body2" color="textSecondary">
                {playlist.tracks?.length || 0} songs • {playlist.duration || '0:00'}
              </Typography>
            </div>
            <Button
              variant="contained"
              color="primary"
              startIcon={<PlayArrowIcon />}
            >
              Play All
            </Button>
          </Box>
        </Paper>

        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
          <Button
            variant="outlined"
            startIcon={<AddIcon />}
          >
            Add Songs
          </Button>
        </Box>

        <List>
          {playlist.tracks?.map((track, index) => (
            <ListItem
              key={track.id}
              sx={{
                '&:hover': {
                  backgroundColor: 'action.hover',
                },
              }}
            >
              <Typography sx={{ mr: 2, color: 'text.secondary' }}>
                {index + 1}
              </Typography>
              <ListItemText
                primary={track.title}
                secondary={track.artist}
              />
              <ListItemSecondaryAction>
                <IconButton edge="end" aria-label="play">
                  <PlayArrowIcon />
                </IconButton>
                <IconButton edge="end" aria-label="delete">
                  <DeleteIcon />
                </IconButton>
              </ListItemSecondaryAction>
            </ListItem>
          ))}
        </List>

        {(!playlist.tracks || playlist.tracks.length === 0) && (
          <Box sx={{ textAlign: 'center', mt: 4 }}>
            <Typography color="textSecondary">
              This playlist is empty. Add some songs to get started!
            </Typography>
          </Box>
        )}
      </Box>
    </Container>
  );
};

export default PlaylistDetails;
