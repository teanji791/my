import React from 'react';
import { Container, Typography, Box, Tabs, Tab } from '@mui/material';
import SpotifyImport from '../components/SpotifyImport';

const ImportPlaylist = () => {
  const [tabValue, setTabValue] = React.useState(0);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <Container>
      <Box sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Import Playlists
        </Typography>
        
        <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
          <Tabs 
            value={tabValue} 
            onChange={handleTabChange}
            aria-label="playlist import options"
          >
            <Tab label="From Spotify" />
            {/* Add more import options here */}
          </Tabs>
        </Box>

        {tabValue === 0 && <SpotifyImport />}
        {/* Add more tab panels here */}
      </Box>
    </Container>
  );
};

export default ImportPlaylist;
