import React, { useState } from 'react';
import { Container, Typography, Grid, Box, Card, CardContent, CardMedia, IconButton } from '@mui/material';
import { PlayArrow, Pause } from '@mui/icons-material';
import SearchBar from '../components/SearchBar';
import { useSearch } from '../hooks/useSearch';
import { useDebounce } from '../hooks/useDebounce';
import { useDispatch, useSelector } from 'react-redux';
import { setCurrentTrack, play, pause, selectCurrentTrack, selectIsPlaying } from '../store/slices/playerSlice';

const Search = () => {
  const dispatch = useDispatch();
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 500);
  const { searchResults, isLoading, error } = useSearch(debouncedSearchTerm);
  const currentTrack = useSelector(selectCurrentTrack);
  const isPlaying = useSelector(selectIsPlaying);

  const handleSearch = (term) => {
    setSearchTerm(term);
  };

  const handlePlayPause = (track) => {
    if (currentTrack?._id === track._id) {
      if (isPlaying) {
        dispatch(pause());
      } else {
        dispatch(play());
      }
    } else {
      dispatch(setCurrentTrack(track));
      dispatch(play());
    }
  };

  if (error) {
    return (
      <Container>
        <Box sx={{ mt: 4 }}>
          <SearchBar onSearch={handleSearch} />
          <Box sx={{ mt: 2, textAlign: 'center' }}>
            <Typography color="error">Error: {error}</Typography>
          </Box>
        </Box>
      </Container>
    );
  }

  return (
    <Container>
      <Box sx={{ mt: 4 }}>
        <Typography variant="h4" gutterBottom>
          Search Music
        </Typography>
        
        <SearchBar onSearch={handleSearch} value={searchTerm} />

        <Box sx={{ mt: 4 }}>
          {isLoading ? (
            <Typography>Searching...</Typography>
          ) : searchResults.length > 0 ? (
            <Grid container spacing={3}>
              {searchResults.map(track => (
                <Grid item xs={12} sm={6} md={4} key={track._id}>
                  <Card 
                    sx={{ 
                      display: 'flex',
                      height: '100%',
                      bgcolor: 'background.paper',
                      '&:hover': {
                        bgcolor: 'action.hover'
                      }
                    }}
                  >
                    <CardMedia
                      component="img"
                      sx={{ width: 100 }}
                      image={track.coverImage?.url || 'https://picsum.photos/seed/music/100'}
                      alt={track.title}
                    />
                    <Box sx={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
                      <CardContent sx={{ flex: '1 0 auto' }}>
                        <Typography variant="h6" component="div" noWrap>
                          {track.title}
                        </Typography>
                        <Typography variant="subtitle1" color="text.secondary" component="div" noWrap>
                          {track.artist}
                        </Typography>
                      </CardContent>
                      <Box sx={{ display: 'flex', alignItems: 'center', pl: 1, pb: 1 }}>
                        <IconButton 
                          onClick={() => handlePlayPause(track)}
                          sx={{
                            bgcolor: 'primary.main',
                            color: 'white',
                            '&:hover': {
                              bgcolor: 'primary.dark'
                            }
                          }}
                        >
                          {currentTrack?._id === track._id && isPlaying ? <Pause /> : <PlayArrow />}
                        </IconButton>
                      </Box>
                    </Box>
                  </Card>
                </Grid>
              ))}
            </Grid>
          ) : searchTerm ? (
            <Typography>No results found</Typography>
          ) : (
            <Typography>Start typing to search for music</Typography>
          )}
        </Box>
      </Box>
    </Container>
  );
};

export default Search;
