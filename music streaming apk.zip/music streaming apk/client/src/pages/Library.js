import React, { useEffect } from 'react';
import { Container, Typography, Grid, Box } from '@mui/material';
import Playlist from '../components/Playlist';
import { useSelector, useDispatch } from 'react-redux';
import { fetchUserPlaylists } from '../store/slices/playlistSlice';
import { useSocket } from '../contexts/SocketContext';

const Library = () => {
  const dispatch = useDispatch();
  const { isConnected } = useSocket();
  const playlists = useSelector(state => state.playlists.userPlaylists) || [];
  const isLoading = useSelector(state => state.playlists.loading);
  const error = useSelector(state => state.playlists.error);

  useEffect(() => {
    if (isConnected) {
      dispatch(fetchUserPlaylists());
    }
  }, [dispatch, isConnected]);

  if (isLoading) {
    return (
      <Container>
        <Box sx={{ mt: 4, textAlign: 'center' }}>
          <Typography>Loading your library...</Typography>
        </Box>
      </Container>
    );
  }

  if (error) {
    return (
      <Container>
        <Box sx={{ mt: 4, textAlign: 'center' }}>
          <Typography color="error">Error loading your library: {error}</Typography>
        </Box>
      </Container>
    );
  }

  return (
    <Container>
      <Box sx={{ mt: 4 }}>
        <Typography variant="h4" gutterBottom>
          Your Library
        </Typography>
        
        {playlists.length === 0 ? (
          <Typography variant="body1" color="textSecondary">
            You haven't created any playlists yet.
          </Typography>
        ) : (
          <Grid container spacing={3}>
            {playlists.map(playlist => (
              <Grid item xs={12} sm={6} md={4} key={playlist.id}>
                <Playlist playlist={playlist} />
              </Grid>
            ))}
          </Grid>
        )}
      </Box>
    </Container>
  );
};

export default Library;
