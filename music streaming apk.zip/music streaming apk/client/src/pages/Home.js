import React from 'react';
import { Container, Typography, Box, Button } from '@mui/material';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';

const Home = () => {
  const auth = useSelector(state => state.auth || { isAuthenticated: false });
  const { isAuthenticated } = auth;

  return (
    <Container maxWidth="lg">
      <Box
        sx={{
          mt: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          textAlign: 'center'
        }}
      >
        <Typography variant="h2" component="h1" gutterBottom>
          Welcome to Music Streaming App
        </Typography>
        <Typography variant="h5" color="textSecondary" paragraph>
          Discover, stream, and share your favorite music
        </Typography>
        
        {!isAuthenticated && (
          <Box sx={{ mt: 4 }}>
            <Button
              component={Link}
              to="/register"
              variant="contained"
              color="primary"
              size="large"
              sx={{ mr: 2 }}
            >
              Get Started
            </Button>
            <Button
              component={Link}
              to="/login"
              variant="outlined"
              color="primary"
              size="large"
            >
              Sign In
            </Button>
          </Box>
        )}
        
        {isAuthenticated && (
          <Box sx={{ mt: 4 }}>
            <Button
              component={Link}
              to="/library"
              variant="contained"
              color="primary"
              size="large"
              sx={{ mr: 2 }}
            >
              My Library
            </Button>
            <Button
              component={Link}
              to="/search"
              variant="outlined"
              color="primary"
              size="large"
            >
              Explore Music
            </Button>
          </Box>
        )}
      </Box>
    </Container>
  );
};

export default Home;
