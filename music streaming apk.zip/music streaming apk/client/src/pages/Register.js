import React from 'react';
import { Container, Paper, Typography, Box } from '@mui/material';
import SignupForm from '../components/SignupForm';
import { Redirect } from 'react-router-dom';
import { useSelector } from 'react-redux';

const Register = () => {
  const isAuthenticated = useSelector(state => state.auth.isAuthenticated);

  if (isAuthenticated) {
    return <Redirect to="/" />;
  }

  return (
    <Container maxWidth="sm">
      <Box
        sx={{
          marginTop: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Paper
          elevation={3}
          sx={{
            padding: 4,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            width: '100%',
          }}
        >
          <Typography component="h1" variant="h5" gutterBottom>
            Create Account
          </Typography>
          <SignupForm />
        </Paper>
      </Box>
    </Container>
  );
};

export default Register;
