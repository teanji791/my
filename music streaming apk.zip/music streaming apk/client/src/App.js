import React from 'react';
import { BrowserRouter as Router, Switch, Route, Redirect } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import './styles/App.css';
import { useSelector } from 'react-redux';

// Layout Components
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import MusicPlayer from './components/MusicPlayer';
import Snackbar from './components/Snackbar';

// Pages
import Home from './pages/Home';
import Library from './pages/Library';
import Profile from './pages/Profile';
import Admin from './pages/Admin';
import Login from './pages/Login';
import Register from './pages/Register';
import Search from './pages/Search';
import PlaylistDetails from './pages/PlaylistDetails';
import ImportPlaylist from './pages/ImportPlaylist';

// Context Providers
import { PlayerProvider } from './contexts/PlayerContext';
import { SocketProvider } from './contexts/SocketContext';

// Theme configuration
const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#1DB954', // Spotify green
    },
    secondary: {
      main: '#191414', // Spotify black
    },
    background: {
      default: '#121212',
      paper: '#282828',
    },
  },
  typography: {
    fontFamily: [
      '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif',
    ].join(','),
    h1: {
      fontSize: '2rem',
      fontWeight: 700,
    },
    h2: {
      fontSize: '1.75rem',
      fontWeight: 600,
    },
    h3: {
      fontSize: '1.5rem',
      fontWeight: 600,
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 500,
          textTransform: 'none',
          fontWeight: 600,
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          backgroundColor: '#282828',
          borderRadius: 8,
        },
      },
    },
  },
});

// Protected Route Component
const ProtectedRoute = ({ children, ...rest }) => {
  const auth = useSelector((state) => state.auth || { isAuthenticated: false });
  
  return (
    <Route
      {...rest}
      render={({ location }) =>
        auth.isAuthenticated ? (
          children
        ) : (
          <Redirect
            to={{
              pathname: "/login",
              state: { from: location }
            }}
          />
        )
      }
    />
  );
};

// Admin Route Component
const AdminRoute = ({ children, ...rest }) => {
  const auth = useSelector((state) => state.auth || { isAuthenticated: false, user: null });
  
  return (
    <Route
      {...rest}
      render={({ location }) =>
        auth.isAuthenticated && auth.user?.role === 'admin' ? (
          children
        ) : (
          <Redirect
            to={{
              pathname: "/",
              state: { from: location }
            }}
          />
        )
      }
    />
  );
};

function App() {
  const auth = useSelector((state) => state.auth || { isAuthenticated: false });

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <SocketProvider>
          <PlayerProvider>
            <div className="app">
              <Navbar />
              <main className="main-content">
                <Switch>
                  {/* Public Routes */}
                  <Route exact path="/" component={Home} />
                  <Route path="/search" component={Search} />
                  
                  {/* Auth Routes - Redirect to home if already authenticated */}
                  <Route 
                    path="/login" 
                    render={() => 
                      auth.isAuthenticated ? <Redirect to="/" /> : <Login />
                    }
                  />
                  <Route 
                    path="/register" 
                    render={() => 
                      auth.isAuthenticated ? <Redirect to="/" /> : <Register />
                    }
                  />

                  {/* Protected Routes */}
                  <ProtectedRoute path="/library">
                    <Library />
                  </ProtectedRoute>
                  
                  <ProtectedRoute path="/profile">
                    <Profile />
                  </ProtectedRoute>
                  
                  <ProtectedRoute path="/playlist/:id">
                    <PlaylistDetails />
                  </ProtectedRoute>
                  
                  <ProtectedRoute path="/playlists/import">
                    <ImportPlaylist />
                  </ProtectedRoute>

                  {/* Admin Routes */}
                  <AdminRoute path="/admin">
                    <Admin />
                  </AdminRoute>

                  {/* 404 Route */}
                  <Route path="*">
                    <Redirect to="/" />
                  </Route>
                </Switch>
              </main>
              <MusicPlayer />
              <Footer />
              <Snackbar />
            </div>
          </PlayerProvider>
        </SocketProvider>
      </Router>
    </ThemeProvider>
  );
}

export default App;
