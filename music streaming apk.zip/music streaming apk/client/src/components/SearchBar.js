import React from 'react';
import { TextField, Box } from '@mui/material';

const SearchBar = () => {
  return (
    <Box>
      <TextField
        label="Search"
        variant="outlined"
        fullWidth
        margin="normal"
      />
    </Box>
  );
};

export default SearchBar;
