import React, { useState } from 'react';
import { TextField, Button, Typography, Paper } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { register } from '../store/slices/authSlice';

const SignupForm = () => {
  const dispatch = useDispatch();
  const { loading, error } = useSelector((state) => state.auth);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [formError, setFormError] = useState('');

  const isValidEmail = (email) => {
    return email.match(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/);
  };

  const validateForm = () => {
    if (username.length < 3) {
      setFormError('Username must be at least 3 characters long');
      return false;
    }
    if (!isValidEmail(email)) {
      setFormError('Please enter a valid email address');
      return false;
    }
    if (password.length < 6) {
      setFormError('Password must be at least 6 characters long');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError('');

    if (!validateForm()) {
      return;
    }

    try {
      await dispatch(register({ username, email, password })).unwrap();
    } catch (error) {
      setFormError(error.response?.data?.message || 'Registration failed. Please try again.');
    }
  };

  return (
    <Paper elevation={3} style={{ padding: '20px' }}>
      <Typography variant="h5">Sign Up</Typography>
      <form onSubmit={handleSubmit}>
        <TextField
          label="Username"
          variant="outlined"
          fullWidth
          margin="normal"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          helperText="Username must be at least 3 characters long"
          error={username.length > 0 && username.length < 3}
        />
        <TextField
          label="Email"
          variant="outlined"
          fullWidth
          margin="normal"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          helperText="Please enter a valid email address"
          error={email.length > 0 && !email.match(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/)}
          type="email"
        />
        <TextField
          label="Password"
          type="password"
          variant="outlined"
          fullWidth
          margin="normal"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          helperText="Password must be at least 6 characters long"
          error={password.length > 0 && password.length < 6}
        />
        <Button type="submit" variant="contained" color="primary" fullWidth disabled={loading}>
          {loading ? 'Signing up...' : 'Sign Up'}
        </Button>
        {(error || formError) && (
          <Typography color="error" style={{ marginTop: '10px' }}>
            {formError || error}
          </Typography>
        )}
      </form>
    </Paper>
  );
};

export default SignupForm;
