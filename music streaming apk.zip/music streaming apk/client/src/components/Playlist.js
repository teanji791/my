import React from 'react';
import { Card, CardContent, CardMedia, Typography, IconButton, Box } from '@mui/material';
import { PlayArrow, MoreVert } from '@mui/icons-material';
import { useHistory } from 'react-router-dom';

const Playlist = ({ playlist }) => {
  const history = useHistory();

  const handleClick = () => {
    history.push(`/playlist/${playlist._id}`);
  };

  return (
    <Card 
      sx={{ 
        display: 'flex', 
        flexDirection: 'column',
        height: '100%',
        cursor: 'pointer',
        '&:hover': {
          boxShadow: 6
        }
      }}
      onClick={handleClick}
    >
      <CardMedia
        component="img"
        height="160"
        image={playlist.coverImage || '/default-playlist-cover.jpg'}
        alt={playlist.name}
      />
      <CardContent sx={{ flexGrow: 1, pb: 1 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <Box>
            <Typography variant="h6" noWrap>
              {playlist.name}
            </Typography>
            <Typography variant="body2" color="text.secondary" noWrap>
              {playlist.tracks?.length || 0} tracks
            </Typography>
          </Box>
          <Box>
            <IconButton size="small">
              <PlayArrow />
            </IconButton>
            <IconButton size="small">
              <MoreVert />
            </IconButton>
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};

export default Playlist;
