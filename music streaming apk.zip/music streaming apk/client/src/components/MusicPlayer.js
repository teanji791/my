import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box, IconButton, Slider, Typography, Stack } from '@mui/material';
import {
  PlayArrow,
  Pause,
  SkipPrevious,
  SkipNext,
  VolumeUp,
  VolumeOff,
  Repeat,
  Shuffle
} from '@mui/icons-material';
import useAudio from '../hooks/useAudio';
import {
  selectCurrentTrack,
  selectIsPlaying,
  selectVolume,
  selectMuted,
  selectRepeat,
  selectShuffle,
  play,
  pause,
  nextTrack,
  previousTrack,
  setVolume,
  toggleMute,
  toggleRepeat,
  toggleShuffle,
  setCurrentTime
} from '../store/slices/playerSlice';
import '../styles/MusicPlayer.css';

const MusicPlayer = () => {
  const dispatch = useDispatch();
  const currentTrack = useSelector(selectCurrentTrack);
  const isPlaying = useSelector(selectIsPlaying);
  const volume = useSelector(selectVolume);
  const isMuted = useSelector(selectMuted);
  const repeat = useSelector(selectRepeat);
  const shuffle = useSelector(selectShuffle);

  const {
    audioRef,
    currentTime,
    duration,
    formatTime,
    isLoading,
    error,
    seek
  } = useAudio(currentTrack);

  useEffect(() => {
    if (currentTrack) {
      if (isPlaying) {
        audioRef.current.play().catch(err => {
          console.error('Playback failed:', err);
          dispatch(pause());
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [currentTrack, isPlaying, audioRef, dispatch]);

  const handlePlayPause = () => {
    if (!currentTrack) return;
    if (isPlaying) {
      dispatch(pause());
    } else {
      dispatch(play());
    }
  };

  const handleTimeChange = (_, newValue) => {
    if (!currentTrack) return;
    seek(newValue);
    dispatch(setCurrentTime(newValue));
  };

  const handleVolumeChange = (_, newValue) => {
    dispatch(setVolume(newValue));
  };

  if (!currentTrack) {
    return null; // Don't render player if no track is selected
  }

  return (
    <Box className="music-player" sx={{ p: 2 }}>
      <Stack direction="row" spacing={2} alignItems="center">
        {/* Track Info */}
        <Box className="track-info">
          <Typography className="track-title" variant="subtitle1">
            {currentTrack.title}
          </Typography>
          <Typography className="track-artist" variant="caption">
            {currentTrack.artist}
          </Typography>
        </Box>

        {/* Main Controls */}
        <Box sx={{ flex: 1 }}>
          <Stack spacing={1}>
            <Stack direction="row" spacing={1} justifyContent="center" alignItems="center">
              <IconButton 
                onClick={() => dispatch(toggleShuffle())}
                color={shuffle ? "primary" : "default"}
                size="small"
              >
                <Shuffle />
              </IconButton>
              <IconButton onClick={() => dispatch(previousTrack())} size="small">
                <SkipPrevious />
              </IconButton>
              <IconButton 
                className="play-pause-button"
                onClick={handlePlayPause}
                disabled={isLoading}
                sx={{ 
                  width: 45, 
                  height: 45,
                  backgroundColor: 'primary.main',
                  '&:hover': { backgroundColor: 'primary.dark' }
                }}
              >
                {isPlaying ? <Pause /> : <PlayArrow />}
              </IconButton>
              <IconButton onClick={() => dispatch(nextTrack())} size="small">
                <SkipNext />
              </IconButton>
              <IconButton 
                onClick={() => dispatch(toggleRepeat())}
                color={repeat !== 'none' ? "primary" : "default"}
                size="small"
              >
                <Repeat />
              </IconButton>
            </Stack>

            {/* Progress Bar */}
            <div className="progress-bar-container">
              <span className="time-display">{formatTime(currentTime)}</span>
              <Slider
                size="small"
                value={currentTime}
                max={duration || 0}
                onChange={handleTimeChange}
                sx={{ 
                  '& .MuiSlider-thumb': {
                    width: 12,
                    height: 12,
                    '&:hover, &.Mui-focusVisible': {
                      boxShadow: '0px 0px 0px 8px rgba(29, 185, 84, 0.16)'
                    }
                  }
                }}
              />
              <span className="time-display">{formatTime(duration)}</span>
            </div>
          </Stack>
        </Box>

        {/* Volume Control */}
        <Box className="volume-control">
          <Stack direction="row" spacing={2} alignItems="center">
            <IconButton onClick={() => dispatch(toggleMute())} size="small">
              {isMuted ? <VolumeOff /> : <VolumeUp />}
            </IconButton>
            <Slider
              className="volume-slider"
              size="small"
              value={isMuted ? 0 : volume}
              onChange={handleVolumeChange}
              min={0}
              max={1}
              step={0.01}
              sx={{
                width: 100,
                '& .MuiSlider-thumb': {
                  width: 12,
                  height: 12
                }
              }}
            />
          </Stack>
        </Box>
      </Stack>

      {/* Error Message */}
      {error && (
        <Typography 
          color="error" 
          variant="caption" 
          sx={{ 
            mt: 1, 
            display: 'block', 
            textAlign: 'center' 
          }}
        >
          {error}
        </Typography>
      )}
    </Box>
  );
};

export default MusicPlayer;
