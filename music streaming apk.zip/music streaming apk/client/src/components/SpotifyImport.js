import React, { useEffect } from 'react';
import { 
  Box, 
  Button, 
  Typography, 
  List, 
  ListItem, 
  ListItemText, 
  ListItemAvatar, 
  Avatar,
  ListItemSecondaryAction,
  IconButton,
  CircularProgress,
  Alert
} from '@mui/material';
import { Download as DownloadIcon, Refresh as RefreshIcon } from '@mui/icons-material';
import { useSpotify } from '../hooks/useSpotify';
import { useHistory } from 'react-router-dom';

const SpotifyImport = () => {
  const { 
    isLoading, 
    error, 
    spotifyPlaylists, 
    connectToSpotify, 
    fetchSpotifyPlaylists, 
    importSpotifyPlaylist 
  } = useSpotify();
  const history = useHistory();

  useEffect(() => {
    // Check if we're returning from Spotify auth
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    
    if (code) {
      fetchSpotifyPlaylists();
    }
  }, [fetchSpotifyPlaylists]);

  const handleImport = async (playlistId) => {
    try {
      const importedPlaylist = await importSpotifyPlaylist(playlistId);
      history.push(`/playlist/${importedPlaylist._id}`);
    } catch (err) {
      console.error('Failed to import playlist:', err);
    }
  };

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
        <Button 
          variant="contained" 
          onClick={connectToSpotify} 
          sx={{ mt: 2 }}
        >
          Try Again
        </Button>
      </Box>
    );
  }

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!spotifyPlaylists.length) {
    return (
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="h6" gutterBottom>
          Import Your Spotify Playlists
        </Typography>
        <Typography variant="body1" color="text.secondary" paragraph>
          Connect your Spotify account to import your playlists
        </Typography>
        <Button 
          variant="contained" 
          onClick={connectToSpotify}
          startIcon={<RefreshIcon />}
        >
          Connect Spotify
        </Button>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h6">
          Your Spotify Playlists
        </Typography>
        <Button 
          variant="outlined" 
          onClick={fetchSpotifyPlaylists}
          startIcon={<RefreshIcon />}
        >
          Refresh
        </Button>
      </Box>

      <List>
        {spotifyPlaylists.map((playlist) => (
          <ListItem 
            key={playlist.id}
            sx={{
              mb: 1,
              bgcolor: 'background.paper',
              borderRadius: 1,
              '&:hover': {
                bgcolor: 'action.hover'
              }
            }}
          >
            <ListItemAvatar>
              <Avatar
                src={playlist.images[0]?.url}
                alt={playlist.name}
                variant="rounded"
              />
            </ListItemAvatar>
            <ListItemText
              primary={playlist.name}
              secondary={`${playlist.tracks.total} tracks • By ${playlist.owner.display_name}`}
            />
            <ListItemSecondaryAction>
              <IconButton 
                edge="end" 
                onClick={() => handleImport(playlist.id)}
                color="primary"
              >
                <DownloadIcon />
              </IconButton>
            </ListItemSecondaryAction>
          </ListItem>
        ))}
      </List>
    </Box>
  );
};

export default SpotifyImport;
