# Music Streaming App

This is a music streaming application similar to Spotify, built with React.js for the frontend and Node.js with Express for the backend.

## Features
- User Authentication
- Music Library
- Search Functionality
- Playlists Management
- Music Player
- Favorites
- Streaming
- Responsive UI
- Admin Panel

## Setup Instructions
1. Clone the repository.
2. Navigate to the `client` directory and run `npm install` to install frontend dependencies.
3. Navigate to the `server` directory and run `npm install` to install backend dependencies.
4. Set up your MongoDB database and update the `.env` file with your credentials.
5. Run the server using `node src/server.js`.
6. Run the client using `npm start` in the `client` directory.

## Technologies Used
- Frontend: React.js, Material-UI
- Backend: Node.js, Express
- Database: MongoDB
- Authentication: JWT
